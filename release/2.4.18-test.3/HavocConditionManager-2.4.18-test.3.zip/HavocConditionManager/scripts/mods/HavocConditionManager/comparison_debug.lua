-- Temporary, shared comparison instrumentation. No spawn decisions or RNG calls.
-- Identical copies ship in all four test mods; DMF owns just one observer chain.
local dmf=get_mod("DMF")
if not dmf then return {attach=function() end} end
if dmf._solo_comparison_debug_v1 then return dmf._solo_comparison_debug_v1 end
local C={version="20260909.1",clients={},names=setmetatable({},{__mode="k"}),registered=setmetatable({},{__mode="k"}),depth=0,stack={},serial=0}
dmf._solo_comparison_debug_v1=C
local unpack=unpack
local function pack(...) return {n=select("#",...),...} end
local function finite(n) return type(n)=="number" and n==n and n>-math.huge and n<math.huge end
local function sorted(t) local keys={} for key in pairs(t or {}) do keys[#keys+1]=key end table.sort(keys);return keys end
local function clean(value) return tostring(value):gsub("[\r\n;]"," "):sub(1,600) end
local frame_thresholds={33.333,50,100,250}
local function setting(mod,key,default) local value=mod:get(key); if value==nil then return default end;return value end
local function current_state() return Managers and Managers.state end
local function server()
    local state=current_state();local session=state and state.game_session
    return session and session.is_server and session:is_server() or false
end
local function choose_clock()
    local ffi=Mods and Mods.lua and Mods.lua.ffi
    if ffi then
        local ok,timer,frequency=pcall(function()
            if not pcall(ffi.typeof,"SOLO_COMPARE_CLOCK_TICK") then
                ffi.cdef[[typedef long long SOLO_COMPARE_CLOCK_TICK;
                    int __stdcall QueryPerformanceCounter(SOLO_COMPARE_CLOCK_TICK*);
                    int __stdcall QueryPerformanceFrequency(SOLO_COMPARE_CLOCK_TICK*);]]
            end
            local win=ffi.load("kernel32")
            local value,freq=ffi.new("SOLO_COMPARE_CLOCK_TICK[1]"),ffi.new("SOLO_COMPARE_CLOCK_TICK[1]")
            assert(win.QueryPerformanceFrequency(freq)~=0 and tonumber(freq[0])>0)
            local hz=tonumber(freq[0]);assert(win.QueryPerformanceCounter(value)~=0)
            local origin=tonumber(value[0])
            return function() win.QueryPerformanceCounter(value);return (tonumber(value[0])-origin)/hz end,hz
        end)
        if ok then return timer,"QPC",frequency end
    end
    if os and os.clock then return os.clock,"os.clock_quantized",nil end
    return nil,"unavailable",nil
end
C.clock,C.clock_name,C.clock_hz=choose_clock()
local function time() return C.clock and C.clock() or nil end
local function new_hist() return {n=0,sum=0,max=0,bins={}} end
local function observe(h,ms)
    if not finite(ms) or ms<0 then return end
    h.n=h.n+1;h.sum=h.sum+ms;h.max=math.max(h.max,ms)
    local bin=math.min(2001,math.floor(ms)+1);h.bins[bin]=(h.bins[bin] or 0)+1
end
local function percentile(h,p)
    if h.n==0 then return 0 end
    local target,total=math.ceil(h.n*p),0
    for _,bin in ipairs(sorted(h.bins)) do total=total+h.bins[bin];if total>=target then return bin end end
    return 0
end
local function new_window()
    return {counters={},peaks={},scopes={},pop={},pop_n=0,frames=new_hist(),dt=new_hist(),bands={},spikes={},warnings={},events={},buff_templates={},breeds={}}
end
local function count(key,n)
    if not C.collecting or not C.window then return end
    local t=C.window.counters;t[key]=(t[key] or 0)+(n or 1)
end
local function peak(key,n)
    if C.collecting and C.window and finite(n) then C.window.peaks[key]=math.max(C.window.peaks[key] or 0,n) end
end
local function hit(label)
    if not C.session or not C.collecting or not C.window then return end
    local e=C.window.scopes[label]
    if not e then e={calls=0,n=0,total=0,self=0,max=0,self_max=0,zero=0};C.window.scopes[label]=e end
    e.calls=e.calls+1;return e
end
function C.call(label,force,fn,...)
    local e=hit(label)
    if not e or not C.clock or not (force or C.sample_frame or C.depth>0) then return fn(...) end
    local parent=C.stack[C.depth]
    local node={start=time(),child=0}
    C.depth=C.depth+1;C.stack[C.depth]=node
    local result=pack(pcall(fn,...))
    local elapsed=math.max(0,time()-node.start)*1000
    C.stack[C.depth]=nil;C.depth=C.depth-1
    if parent then parent.child=parent.child+elapsed end
    e.n=e.n+1;e.total=e.total+elapsed;e.max=math.max(e.max,elapsed)
    local own=math.max(0,elapsed-node.child)
    e.self=e.self+own;e.self_max=math.max(e.self_max,own)
    if C.frame_scopes then C.frame_scopes[label]=(C.frame_scopes[label] or 0)+own end
    if elapsed==0 then e.zero=e.zero+1 end
    if not result[1] then count("sampled_errors");error(result[2],0) end
    return unpack(result,2,result.n)
end
local monitored={update=true,spawn_minion=true,unregister_unit=true,mutator_breed_init=true,replacement_breed=true,
    generate_roamers=true,_generate_roamers=true,_create_zones=true,_create_sub_zones=true,circle_placement=true,
    current_faction=true,_setup_next_horde=true,_spawn_horde_wave=true,_spawn_horde=true,_check_monster_override=true,
    _setup_specials_slot=true,_on_special_spawned=true,_spawn_special=true,_spawn_monster=true,_spawn_boss_patrol=true,
    _populate_hazard_props=true,_fetch_settings=true,_update_timer=true,add_trickle_horde=true,spawn_type_enabled=true,
    horde=true,_init_coordinated_horde_strikes=true,_evaluate_coordinated_horde_strike=true,
    get_ramp_up_frequency_modifier=true,current_density_type=true,set_max_alive_specials_multiplier=true,
    on_gameplay_post_init=true,_init_state_managers=true,_try_activate_roamer=true,_trigger_runtime_spawn=true,
    _limit_roamer_breeds=true,_fill_spawns_by_timer=true,spawn_group=true,add_pacing_modifiers=true,
    _load_mutators=true,request_proc_event_param_table=true,_clear_param_tables=true}
local function wrap_handler(client,target,method,handler,safe)
    local target_name=type(target)=="string" and target or C.names[target] or type(target)=="table" and (target.__class_name or target.__name)
    local label="mod."..client.name.."."..(target_name and target_name.."." or "")..method
    local proxies=setmetatable({},{__mode="k"})
    if safe then return function(...)
        if not C.session or not C.collecting or not client.enabled then return handler(...) end
        return C.call(label,false,handler,...)
    end end
    return function(fn,...)
        if not C.session or not C.collecting or not client.enabled then return handler(fn,...) end
        local proxy=proxies[fn]
        if not proxy then
            proxy=function(...) return C.call("next."..label,false,fn,...) end
            proxies[fn]=proxy
        end
        return C.call(label,false,handler,proxy,...)
    end
end
local function emit(part,text)
    local mod=C.logger or dmf
    mod:info("[ComparePerf] version=%s run=%d stage=%s elapsed=%.3f part=%s %s",C.version,C.serial,C.stage or "idle",C.elapsed or 0,part,text)
end
local function kv(t)
    local parts={};for _,key in ipairs(sorted(t)) do parts[#parts+1]=key.."="..clean(t[key]) end
    return table.concat(parts,";")
end
local function mod_enabled(mod) return not mod.is_enabled or mod:is_enabled() end
function C.refresh_clients()
    C.collecting=false;C.logger=nil;C.throttle=false
    for _,name in ipairs(C.client_order or {}) do
        local client=C.clients[name]
        client.enabled=setting(client.mod,"performance_debug",true)~=false
        if client.enabled then
            C.collecting=true;C.logger=C.logger or client.mod
            C.throttle=C.throttle or setting(client.mod,"performance_buff_warning_summary",false)==true
        end
    end
end
local config_keys={"challenge_rating_multiplier","alive_specials_multiplier","roamer_spawn_multiplier","ramp_horde_multiplier",
    "coordinated_strike_multiplier","high_density_type","faction","extra_circumstance_count","faction_combined_within_wave",
    "faction_switch_guaranteed","spawn_multiplier_common","spawn_multiplier_elite","spawn_multiplier_special","spawn_multiplier_boss",
    "spawn_mode_common","spawn_mode_elite","spawn_mode_special","spawn_mode_boss","buff_proc_capacity","havoc_circumstances_serialized",
    "nurgle_blessing_rank_scaling","monster_specials_melee_twin_captain","monster_specials_ranged_twin_captain","monster_specials_houndmaster",
    "mutator_poxwalker_bombers","mutator_mutants","mutator_snipers","mutator_chaos_hounds","mutator_waves_of_specials","mutator_more_ogryns",
    "mutator_monster_specials","mutator_minion_nurgle_blessing","havoc_mutator_more_captains_02","mutator_monster_havoc_twins",
    "mutator_havoc_armored_infected","mutator_tough_skin_enemies","mutator_bolstering_minions","mutator_corrupted_enemies","mutator_encroaching_garden",
    "mutator_havoc_enraged","mutator_headshot_parasite_enemies","mutator_rotten_armor","mutator_stimmed_minions"}
function C.configuration()
    local related={}
    for _,name in ipairs({"SoloPlay","Realms","TrueSoloQoL","MortisBuffManager"}) do
        local mod=get_mod(name);related[name]=mod and mod_enabled(mod) or false
    end
    emit("related_mods_enabled",kv(related))
    for _,name in ipairs(sorted(C.clients)) do
        local client=C.clients[name];local mod=client.mod
        local values={mod=name,build=client.build,enabled=mod_enabled(mod),debug=client.enabled,
            buff_warning_summary=setting(mod,"performance_buff_warning_summary",false)}
        for _,key in ipairs(config_keys) do local value=mod:get(key);if type(value)~="table" and value~=nil then values[key]=value end end
        if name=="HavocEnemyDirector" then
            local cfg=mod:get("director_config_v1")
            if type(cfg)=="table" then
                values.advanced_saved=cfg.enabled;values.total_cap_saved=cfg.total_cap
                for key,value in pairs(cfg.category_caps or {}) do values["cap_saved_"..key]=value end
            end
        end
        emit("config",kv(values))
        if name=="HavocEnemyDirector" and mod.get_session_config then
            local cfg=mod.get_session_config()
            local values={enabled=cfg.enabled,total_cap=cfg.total_cap,revision=cfg.revision,
                native_extras=cfg.native_extras_enabled,havoc_twins=cfg.havoc_twins_enabled}
            for key,value in pairs(cfg.category_caps or {}) do values["cap_"..key]=value end
            emit("director_session",kv(values))
            for _,id in ipairs(sorted(cfg.generators)) do
                local value={id=id};for key,setting in pairs(cfg.generators[id]) do
                    if type(setting)~="table" then value[key]=setting end
                end;emit("generator_override",kv(value))
            end
            emit("director_custom",kv({count=#(cfg.custom or {}),note="export the generator template to reproduce custom pools exactly"}))
        end
    end
    local state=current_state();local pacing=state and state.pacing
    if pacing then
        local values={pressure=pacing._total_challenge_rating or 0}
        for key,value in pairs(pacing._challenge_rating_thresholds or {}) do values["threshold_"..key]=value end
        local specials=pacing._specials_pacing
        if specials then values.special_slots=specials._max_alive_specials end
        emit("pacing_config",kv(values))
    end
    local mutators=state and state.mutator and state.mutator._mutators
    if type(mutators)=="table" then emit("active_mutators",table.concat(sorted(mutators),",")) end
    local solo=get_mod("SoloPlay")
    if solo then
        local values={}
        for _,key in ipairs({"havoc_mission","havoc_difficulty","havoc_faction","havoc_resistance","havoc_challenge","havoc_theme_circumstance","havoc_difficulty_circumstance"}) do
            local value=solo:get(key);if value~=nil and type(value)~="table" then values[key]=value end
        end
        for i=1,12 do local key="havoc_circumstance"..i;local value=solo:get(key);if value~=nil then values[key]=value end end
        emit("mission_settings",kv(values))
    end
end
function C.start(mission,stage)
    if C.session then C.finish("replaced") end
    C.refresh_clients();C.serial=C.serial+1;C.session=true;C.stage=stage or "initialization"
    C.mission=mission or "unknown";C.elapsed=0;C.start_time=time();C.last_frame=nil;C.last_game_time=nil
    C.next_report=30;C.next_snapshot=0;C.next_sample=0;C.window=new_window();C.sample_frame=false;C.frame_created=0
    C.frame_rejects=0;C.frame_queries=0;C.frame_scopes={};C.last_population=nil;C.last_population_t=nil
    C.metadata=setmetatable({},{__mode="k"});C.buff_last_drops=setmetatable({},{__mode="k"})
    C.buff_next_sample=setmetatable({},{__mode="k"});C.pending_config=true;C.warning_next=-1
    emit("start",kv({mission=C.mission,clock=C.clock_name,clock_hz=C.clock_hz or "unavailable",debug=C.collecting,
        frame_sample_hz=4,population_hz=1,summary_seconds=30,warnings_summarized=C.throttle,
        note="scope times include observer cost; next scopes include native code and other hooks"}))
end
local function hist_text(h)
    return string.format("n=%d;mean_ms=%.4f;p50_upper_ms=%d;p95_upper_ms=%d;p99_upper_ms=%d;max_ms=%.4f",
        h.n,h.n>0 and h.sum/h.n or 0,percentile(h,.5),percentile(h,.95),percentile(h,.99),h.max)
end
function C.report(reason)
    if not C.session or not C.window then return end
    local w=C.window
    emit("window","reason="..reason..";mission="..clean(C.mission)..";debug="..tostring(C.collecting)..";warnings_summarized="..tostring(C.throttle))
    if C.collecting then
        emit("frame_wall",hist_text(w.frames));emit("update_dt",hist_text(w.dt))
        for _,band in ipairs(sorted(w.bands)) do emit("frame_population_band","alive="..band..";"..hist_text(w.bands[band])) end
        for _,spike in ipairs(w.spikes) do emit("slow_frame_sample",kv(spike)) end
        emit("counts",kv(w.counters));emit("peaks",kv(w.peaks))
        local pop={samples=w.pop_n}
        for key,value in pairs(w.pop) do pop[key.."_mean"]=string.format("%.3f",w.pop_n>0 and value/w.pop_n or 0) end
        emit("population",kv(pop))
        local scopes={};for key,value in pairs(w.scopes) do scopes[#scopes+1]={key,value} end
        table.sort(scopes,function(a,b) return a[1]<b[1] end)
        for _,row in ipairs(scopes) do
            local key,e=row[1],row[2]
            if e.calls>0 then emit("scope",string.format("name=%s;calls=%d;samples=%d;sample_total_ms=%.6f;sample_self_ms=%.6f;max_ms=%.6f;self_max_ms=%.6f;zero=%d",
                key,e.calls,e.n,e.total,e.self,e.max,e.self_max,e.zero)) end
        end
        if next(w.events) then emit("buff_events_sampled",kv(w.events)) end
        if next(w.buff_templates) then emit("player_buff_templates",table.concat(sorted(w.buff_templates),",")) end
        if next(w.breeds) then emit("created_breeds",kv(w.breeds)) end
        if w.warning_trace then emit("buff_warning_trace",w.warning_trace) end
    end
    C.window=new_window();C.next_report=(C.elapsed or 0)+30
end
function C.finish(reason)
    if not C.session then return end
    C.report(reason or "mission_end");C.session=false;C.sample_frame=false;C.metadata=nil;C.last_frame=nil
    C.buff_last_drops=nil;C.buff_next_sample=nil
end
local function category(breed)
    if not breed then return "unknown" end
    local tags=breed.tags or {}
    if breed.is_untargetable or breed.breed_type and breed.breed_type~="minion" or tags.witch or tags.ritualist then return "other" end
    if tags.monster or tags.captain or tags.cultist_captain then return "boss" end
    if tags.special then return "special" end;if tags.elite then return "elite" end;return "common"
end
function C.snapshot()
    local state=current_state();local manager=state and state.minion_spawn
    if not manager or not manager.spawned_minions then return end
    local started=time();local units=manager:spawned_minions();local pop={alive=0,common=0,elite=0,special=0,boss=0,other=0,unknown=0,dead=0}
    pop.allocated=manager:total_allocated_num_enemies();pop.queued=manager._spawn_queue_size or 0
    local health=HEALTH_ALIVE or ALIVE or {};count("observer_population_scans")
    for _,unit in ipairs(units) do
        count("observer_population_visits")
        if health[unit] then
            pop.alive=pop.alive+1
            local cat=C.metadata[unit]
            if not cat then
                local ext=ScriptUnit and ScriptUnit.has_extension and ScriptUnit.has_extension(unit,"unit_data_system")
                cat=category(ext and ext:breed());C.metadata[unit]=cat
            end
            pop[cat]=pop[cat]+1
        else pop.dead=pop.dead+1 end
    end
    local w=C.window;w.pop_n=w.pop_n+1
    C.last_population=pop;C.last_population_t=C.elapsed
    for key,value in pairs(pop) do w.pop[key]=(w.pop[key] or 0)+value;peak("population_"..key,value) end
    local pacing=state.pacing
    if pacing then peak("pressure",pacing._total_challenge_rating or 0) end
    if collectgarbage then local ok,kb=pcall(collectgarbage,"count");if ok and finite(kb) then peak("lua_kb",kb) end end
    if started then count("observer_snapshot_ms",math.max(0,time()-started)*1000) end
end
function C.poll(dt)
    if not C.installed then C.install_probes() end
    local was_enabled=C.collecting;C.refresh_clients()
    if not C.session then return end
    if was_enabled~=C.collecting then
        emit("state","debug="..tostring(C.collecting));C.last_frame=nil;C.window=new_window()
    end
    if not C.collecting then C.sample_frame=false;C.last_frame=nil;return end
    local now=time();C.elapsed=now and C.start_time and now-C.start_time or (C.elapsed or 0)+(finite(dt) and dt or 0)
    if C.pending_config and current_state() and current_state().pacing then C.pending_config=false;C.configuration() end
    peak("created_per_frame",C.frame_created or 0);peak("buff_rejected_per_frame",C.frame_rejects or 0)
    if C.collecting and C.stage=="gameplay" and server() then
        local game_time=Managers.time and Managers.time.time and Managers.time:time("gameplay")
        local paused=finite(game_time) and C.last_game_time~=nil and game_time<=C.last_game_time
        if not paused then
            if now and C.last_frame then
                local ms=math.max(0,now-C.last_frame)*1000;observe(C.window.frames,ms)
                for _,threshold in ipairs(frame_thresholds) do if ms>threshold then count("frame_over_"..threshold.."ms") end end
                local pop=C.last_population
                local fresh=pop and C.last_population_t and C.elapsed-C.last_population_t<=1.1
                if fresh then
                    local n=pop.alive
                    local band=n<80 and "0-79" or n<120 and "80-119" or n<160 and "120-159" or n<240 and "160-239" or n<360 and "240-359" or "360+"
                    local hist=C.window.bands[band] or new_hist();C.window.bands[band]=hist;observe(hist,ms)
                end
                if ms>50 then
                    local spike={at=string.format("%.3f",C.elapsed),wall_ms=ms,created=C.frame_created or 0,buff_rejected=C.frame_rejects or 0,
                        nav_queries=C.frame_queries or 0,profiled=C.sample_frame,alive=fresh and pop.alive or "unknown",population_age=C.last_population_t and C.elapsed-C.last_population_t or "unknown"}
                    for name,value in pairs(C.frame_scopes or {}) do
                        local owner=name:match("^mod%.([^.]+)%.")
                        if owner then spike["sampled_self_ms_"..owner]=(spike["sampled_self_ms_"..owner] or 0)+value end
                    end
                    local top=C.window.spikes;top[#top+1]=spike
                    table.sort(top,function(a,b) return a.wall_ms>b.wall_ms end);if #top>5 then top[#top]=nil end
                end
            end
            if finite(dt) then observe(C.window.dt,dt*1000) end
        else count("paused_or_no_game_time_updates") end
        C.last_game_time=game_time;C.last_frame=now
        C.sample_frame=C.elapsed>=C.next_sample
        if C.sample_frame then C.next_sample=C.elapsed+.25 end
        if C.elapsed>=C.next_snapshot then C.next_snapshot=C.elapsed+1;C.snapshot() end
    else C.sample_frame=false;C.last_frame=nil end
    C.frame_created=0;C.frame_rejects=0;C.frame_queries=0
    for key in pairs(C.frame_scopes) do C.frame_scopes[key]=nil end
    if C.elapsed>=C.next_report then C.report("periodic") end
end
local function bind(object,name,method,handler,safe)
    if type(object)~="table" or type(object[method])~="function" then return false end
    C.names[object]=name;C.registered[object]=C.registered[object] or {}
    if C.registered[object][method] then return true end
    C.registered[object][method]=true
    if safe then dmf:hook_safe(object,method,handler) else dmf:hook(object,method,handler) end
    return true
end
local function require_probe(path,name,setup)
    dmf:hook_require(path,function(object) if type(object)=="table" then C.names[object]=name;setup(object) end end)
end
local function plain_probe(object,name,method,force)
    bind(object,name,method,function(fn,...)
        if not C.session or not C.collecting then return fn(...) end
        return C.call("path."..name.."."..method,force,fn,...)
    end)
end
local function excluded_mission(name) return name=="hub_ship" or name=="hub" or name=="psykhanium" or name=="training_grounds" end
function C.install_probes()
    if not dmf.hook_require then return end
    C.installed=true
    -- The observer hooks use DMF's owner, separate from all four functional mods.
    require_probe("scripts/managers/pacing/pacing_manager","PacingManager",function(object)
        plain_probe(object,"PacingManager","update",false)
        bind(object,"PacingManager","spawn_type_enabled",function(fn,self,kind,...)
            if not C.session or not C.collecting then return fn(self,kind,...) end
            local function done(...)
                local allowed,reason=...
                count("gate_"..tostring(kind).."_"..(allowed and "allowed" or tostring(reason or "blocked")))
                return ...
            end
            return done(fn(self,kind,...))
        end)
    end)
    require_probe("scripts/managers/pacing/roamer_pacing/roamer_pacing","RoamerPacing",function(object)
        plain_probe(object,"RoamerPacing","update",false);plain_probe(object,"RoamerPacing","generate_roamers",true)
    end)
    require_probe("scripts/managers/pacing/specials_pacing/specials_pacing","SpecialsPacing",function(object)
        plain_probe(object,"SpecialsPacing","update",false);plain_probe(object,"SpecialsPacing","_spawn_special",false)
    end)
    require_probe("scripts/managers/minion/minion_spawn_manager","MinionSpawnManager",function(object)
        plain_probe(object,"MinionSpawnManager","spawn_minion",false)
        bind(object,"MinionSpawnManager","_initialize_blackboard_components",function(self,unit,breed)
            if not C.session or not C.collecting then return end
            count("created");count("created_"..category(breed));C.frame_created=(C.frame_created or 0)+1
            local name=breed and breed.name or "unknown";C.window.breeds[name]=(C.window.breeds[name] or 0)+1
        end,true)
        bind(object,"MinionSpawnManager","unregister_unit",function(fn,self,...)
            if not C.session or not C.collecting then return fn(self,...) end
            local function done(...) local result=...;if result then count("unregistered") end;return ... end
            return done(fn(self,...))
        end)
    end)
    require_probe("scripts/managers/horde/horde_manager","HordeManager",function(object)
        bind(object,"HordeManager","horde",function(fn,self,kind,template,side,target,composition,...)
            if not C.session or not C.collecting then return fn(self,kind,template,side,target,composition,...) end
            count("horde_calls");count("horde_type_"..tostring(kind))
            local low,high=0,0
            for _,entry in ipairs(type(composition)=="table" and composition.breeds or {}) do
                local amount=entry.amount
                if type(amount)=="table" then low=low+(tonumber(amount[1]) or 0);high=high+(tonumber(amount[2]) or 0)
                elseif finite(amount) then low=low+amount;high=high+amount end
            end
            count("horde_requested_min",low);count("horde_requested_max",high);peak("horde_batch_requested",high)
            local function done(...) local ok=...;count(ok and "horde_success" or "horde_failed");return ... end
            return done(C.call("path.HordeManager.horde",true,fn,self,kind,template,side,target,composition,...))
        end)
    end)
    require_probe("scripts/managers/main_path/utilities/spawn_point_queries","SpawnPointQueries",function(object)
        bind(object,"SpawnPointQueries","get_random_occluded_position",function(fn,...)
            if not C.session or not C.collecting then return fn(...) end
            count("occluded_queries");C.frame_queries=(C.frame_queries or 0)+1
            local function done(...) local position=...;if not position then count("occluded_query_failed") end;return ... end
            return done(C.call("path.SpawnPointQueries.get_random_occluded_position",true,fn,...))
        end)
    end)
    require_probe("scripts/extension_systems/buff/buff_extension_base","BuffExtensionBase",function(object)
        local function pool_drops(self)
            local pool=self._hed_proc_pool
            if pool and finite(pool.dropped) then
                local previous=C.buff_last_drops[self] or 0;local delta=math.max(0,pool.dropped-previous)
                count("hed_buff_rejected",delta);C.frame_rejects=(C.frame_rejects or 0)+delta;C.buff_last_drops[self]=pool.dropped
            end
        end
        bind(object,"BuffExtensionBase","_update_proc_events",function(fn,self,...)
            if not C.session or not C.collecting then return fn(self,...) end
            local events=self._num_proc_events or 0
            if events==0 then if self._hed_proc_pool then pool_drops(self) end;return fn(self,...) end
            local kind=self._player and "player" or "minion"
            count("buff_"..kind.."_batches");count("buff_"..kind.."_events",events);peak("buff_"..kind.."_queue",self._num_params_table_in_use or events)
            peak("buff_capacity_observed",self._hed_proc_pool and self._hed_proc_pool.capacity or 300)
            pool_drops(self)
            if self._player and C.elapsed>=(C.buff_next_sample[self] or 0) then
                C.buff_next_sample[self]=C.elapsed+1
                for i=1,events do local event=self._proc_events[(i-1)*2+1];if event~=nil then
                    local name=tostring(event);C.window.events[name]=(C.window.events[name] or 0)+1
                end end
                for _,buff in ipairs(self._buffs or {}) do
                    local template=buff._template
                    if template and template.name then C.window.buff_templates[template.name]=true end
                end
                peak("player_buff_count",#(self._buffs or {}))
            end
            return C.call("path.BuffExtensionBase."..kind,false,fn,self,...)
        end)
        bind(object,"BuffExtensionBase","destroy",function(fn,self,...)
            if C.session and C.collecting then pool_drops(self) end
            return fn(self,...)
        end)
    end)
    -- This hook counts actual native rejections at their existing log call. It
    -- avoids adding another hook to the much hotter proc-allocation function.
    if Log and type(Log.warning)=="function" then
        bind(Log,"Log","warning",function(fn,tag,message,...)
            if not C.session or not C.collecting or tag~="BuffExtensionBase" or message~="Out of proc event tables, ignoring proc!" then return fn(tag,message,...) end
            count("native_buff_rejected")
            C.frame_rejects=(C.frame_rejects or 0)+1
            local w=C.window;local n=w.counters.native_buff_rejected
            if not w.warning_trace and debug and debug.traceback then w.warning_trace=clean(debug.traceback("",2)) end
            if C.throttle and C.elapsed<C.warning_next then count("buff_warnings_suppressed");return end
            C.warning_next=C.elapsed+1;count("buff_warnings_emitted")
            if n%64==1 then return C.call("path.Log.buff_warning",true,fn,tag,message,...) end
            return fn(tag,message,...)
        end)
    end
    -- Available before a mission starts; the actual active mission is recorded
    -- from this method's explicit arguments, including its local-host flag.
    local init=CLASS and CLASS.GameplayInitStepManagers
    local initialize=function(fn,self,world,physics,nav,has_navmesh,level,level_name,seed,is_server,mission,...)
            C.host_mission=is_server and not excluded_mission(mission)
            if is_server and not excluded_mission(mission) then
                C.start(mission,"initialization")
                local giver,challenge,resistance,circumstance,havoc_data=...
                emit("mission_context",kv({seed=seed,challenge=challenge,resistance=resistance,circumstance=circumstance,havoc_data=type(havoc_data)=="string" and havoc_data or "unavailable"}))
            end
            return C.call("path.GameplayInitStepManagers.init",true,fn,self,world,physics,nav,has_navmesh,level,level_name,seed,is_server,mission,...)
    end
    if init then bind(init,"GameplayInitStepManagers","_init_state_managers",initialize)
    else dmf:hook("GameplayInitStepManagers","_init_state_managers",initialize) end
    local coverage={initialization=init and "bound" or "delayed"}
    for _,name in ipairs({"StateGameplay","ExtensionManager","MinionBrainSystem","BuffSystem"}) do
        local object=CLASS and CLASS[name]
        coverage[name]=type(object)=="table" and type(object.update)=="function" or false
        if coverage[name] then plain_probe(object,name,"update",false) end
    end
    emit("observer_ready",kv(coverage))
end
function C.state_changed(status,state)
    if state=="GameplayStateRun" then
        if status=="enter" then
            if not C.session and C.host_mission~=false and server() then C.start("unknown","gameplay") end
            if C.session then C.report("initialization_end");C.stage="gameplay";C.last_frame=nil;C.pending_config=true end
        elseif status=="exit" then C.finish("mission_end") end
    elseif state=="StateGameplay" and status=="exit" then C.finish("state_exit") end
end
function C.attach(mod,name,build)
    if C.clients[name] and C.clients[name].mod==mod then C.clients[name].build=build;return end
    local client={mod=mod,name=name,build=build,enabled=setting(mod,"performance_debug",true)~=false}
    C.clients[name]=client
    C.client_order=sorted(C.clients)
    local raw_hook,raw_safe=mod.hook,mod.hook_safe
    if raw_hook then mod.hook=function(self,target,method,handler)
        if monitored[method] and type(handler)=="function" then handler=wrap_handler(client,target,method,handler,false) end
        return raw_hook(self,target,method,handler)
    end end
    if raw_safe then mod.hook_safe=function(self,target,method,handler)
        if monitored[method] and type(handler)=="function" then handler=wrap_handler(client,target,method,handler,true) end
        return raw_safe(self,target,method,handler)
    end end
    C.refresh_clients()
    mod:info("[ComparePerf] component=%s build=%s observer=%s debug=%s clock=%s; default-on comparison diagnostics are included",name,build,C.version,tostring(client.enabled),C.clock_name)
    if not C.core_bound and type(dmf.mods_update_event)=="function" and type(dmf.mods_game_state_changed_event)=="function" then
        C.core_bound=true
        dmf:hook_safe(dmf,"mods_update_event",function(dt) C.poll(dt) end)
        dmf:hook_safe(dmf,"mods_game_state_changed_event",C.state_changed)
        if type(dmf.mods_unload_event)=="function" then dmf:hook_safe(dmf,"mods_unload_event",function() C.finish("unload") end) end
    end
end
return C
