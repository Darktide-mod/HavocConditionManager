-- Filesystem packages feed the existing validated selection/options library.
-- Discovery changes next-mission data only; active engines retain snapshots.
local L={}
function L.new(mod,kind,catalog,Schema,Codec,Files,Base,Packages,Hash,options)
    options=options or {}
    local self=Base.new(mod,kind,catalog,Schema,Codec,Files,options)
    local package_api=Packages.new(Schema,Codec,Hash)
    local previous_document=Schema.copy(self.document);local previous_selected=Schema.copy(self.options.selected)
    local saved=mod:get("diy_packages_v1")
    local settings=type(saved)=="table" and saved.version==1 and Schema.copy(saved) or {version=1,disabled={}}
    settings.disabled=type(settings.disabled)=="table" and settings.disabled or {}
    for id,value in pairs(settings.disabled)do if not Packages.id(id) or value~=true then settings.disabled[id]=nil end end
    self.packages={};self.active_packages={};self.package_errors={};self.entry_sources={};self.entry_hashes={};self.legacy_policy_keys={}
    self.document={format=Schema.format,version=Schema.version,kind=kind,id="diy_packages",name={en="DIY packages",["zh-cn"]="DIY 包",["zh-tw"]="DIY 套件"},entries={}}
    local store,store_error,snapshot,snapshot_revision
    local initializing=true
    local raw_signature=self.signature
    local function persist() mod:set("diy_packages_v1",Schema.copy(settings)) end
    local function filesystem()
        if store then return store end
        local ffi=Mods and Mods.lua and Mods.lua.ffi
        if not ffi then local ok,value=pcall(require,"ffi");if ok then ffi=value end end
        if not ffi then return nil,"diy_package_io" end
        local ok,value,why=pcall(Files.new,ffi,options.name)
        if not ok then store_error=tostring(value);return nil,"diy_package_io" end
        store,store_error=value,why
        return store,store_error
    end
    local function report(error)
        if type(error)=="string" and error:match("^template_") then error="diy_package_io" end
        self.last_error=error;return nil,error
    end
    local function write_document(fs,document,id,with_script)
        local files=package_api.from_document(document,id,with_script)
        local checked,why=package_api.validate(files,catalog,kind,id);if not checked then return nil,why end
        return fs.write_package(id,files,Packages.id,Packages.path)
    end
    local function bootstrap(fs)
        if settings.bootstrapped then return true end
        -- Convert existing loose JSON once. Preserve originals and never
        -- replace a directory that its author has already installed.
        local names,why=fs.list();if not names then return nil,why end
        for _,name in ipairs(names)do
            local bytes=fs.read(name)
            local raw=bytes and Codec.decode(bytes)
            local doc=raw and Schema.validate(raw,catalog,kind)
            if doc and #doc.entries>0 then
                local id=name:sub(1,-6);if not Packages.id(id) then id=doc.id end
                local ok,err=write_document(fs,doc,id,false)
                if not ok and err~="diy_package_exists" then return nil,err end
            end
        end
        if #previous_document.entries>0 and previous_document.id~="diy_packages" then
            local names=fs.list_packages(Packages.id) or {};local found=false
            local old_hash=Hash.hex(assert(Codec.encode(previous_document)))
            for _,id in ipairs(names)do
                local files=fs.read_package(id,Packages.id,Packages.path)
                local pack=files and package_api.validate(files,catalog,kind,id)
                if pack and Hash.hex(assert(Codec.encode(pack.document)))==old_hash then found=true;break end
            end
            if not found then
                local ok,err=write_document(fs,previous_document,previous_document.id,false)
                if not ok and err~="diy_package_exists" then return nil,err end
            end
        end
        if options.starter then
            local starter=options.starter();local id="starter-"..kind
            if starter then
                local ok,err=write_document(fs,starter,id,true)
                if not ok and err~="diy_package_exists" then return nil,err end
            end
        end
        settings.bootstrapped=true;persist();return true
    end
    local function lookup(name)
        local ok,value=pcall(get_mod,name);return ok and value or nil
    end
    function self.directory()
        local fs,why=filesystem();return fs and fs.package_directory,why
    end
    function self.copy_directory()
        local path,why=self.directory();if not path then return report(why) end
        if Clipboard and Clipboard.put then Clipboard.put(path)
        elseif Clipboard and Clipboard.set then Clipboard.set(path)
        else return report(path) end
        return true
    end
    function self.signature()
        return self.package_signature or raw_signature()
    end
    function self.scan()
        local fs,why=filesystem();if not fs then return report(why) end
        local ok;ok,why=bootstrap(fs);if not ok then return report(why) end
        local selected=self.files[self.selected_file]
        local names,errors;names,why,errors=fs.list_packages(Packages.id)
        if not names then return report(why) end
        local packages={};errors=errors or {};local total_bytes=0
        for _,id in ipairs(names)do
            local files;files,why=fs.read_package(id,Packages.id,Packages.path)
            local pack;if files then pack,why=package_api.validate(files,catalog,kind,id) end
            if pack and total_bytes+pack.bytes>Packages.max_library_bytes then errors[id]="diy_package_limit"
            elseif pack then packages[id]=pack;total_bytes=total_bytes+pack.bytes else errors[id]=why end
        end
        local composed=package_api.compose(packages,catalog,kind,settings.disabled,lookup)
        for id,error in pairs(composed.errors)do errors[id]=error end
        local identities={}
        for id,pack in pairs(composed.packages)do identities[#identities+1]=id..":"..pack.closure_hash end
        table.sort(identities);local signature=Hash.hex(table.concat(identities,"\n"))..":"..#composed.document.entries
        local changed=signature~=self.package_signature
        self.packages,self.active_packages,self.package_errors=packages,composed.packages,errors
        self.files=names;self.selected_file=math.max(1,math.min(self.selected_file,#names))
        for i,id in ipairs(names)do if id==selected then self.selected_file=i end end
        if changed then
            local selected_ids={};local seen={}
            for _,id in ipairs(self.options.selected)do if composed.sources[id] then selected_ids[#selected_ids+1]=id;seen[id]=true end end
            if not settings.selection_migrated then
                local old_hash=Hash.hex(assert(Codec.encode(previous_document)))
                for id,pack in pairs(composed.packages)do
                    if Hash.hex(assert(Codec.encode(pack.document)))==old_hash then
                        for _,old_id in ipairs(previous_selected)do
                            local mapped=package_api.identity(id,old_id)
                            if composed.sources[mapped] and not seen[mapped] then selected_ids[#selected_ids+1]=mapped;seen[mapped]=true end
                        end
                        break
                    end
                end
            end
            table.sort(selected_ids);self.options.selected=selected_ids
            self.document=composed.document;self.entry_sources=composed.sources;self.entry_hashes=composed.hashes
            self.legacy_policy_keys={}
            for id,source in pairs(composed.sources)do
                local old=source.document_id.."/"..source.entry_id
                self.legacy_policy_keys[old]=self.legacy_policy_keys[old] or {}
                self.legacy_policy_keys[old][#self.legacy_policy_keys[old]+1]=composed.document.id.."/"..id
            end
            self.package_signature=signature
            mod:set("diy_document_v1",assert(Codec.encode(self.document)))
            mod:set("diy_options_v1",Schema.copy(self.options))
            settings.selection_migrated=true;persist()
        end
        self.revision=self.revision+1;snapshot=nil
        self.last_error=nil;self.last_message=nil
        if options.changed and changed and not initializing then options.changed("packages") end
        return true
    end
    function self.package_enabled(id) return self.active_packages[id]~=nil end
    function self.package_disabled(id) return settings.disabled[id]==true end
    function self.format_message(value)
        local key,extra=tostring(value):match("^(diy_[%w_]+)(.*)$")
        return key and (mod:localize(key)..extra) or tostring(value)
    end
    function self.status_message()
        local loaded,invalid=0,0
        for _ in pairs(self.active_packages)do loaded=loaded+1 end
        for id in pairs(self.package_errors)do if not settings.disabled[id] then invalid=invalid+1 end end
        local summary=mod:localize("diy_packages_count",loaded,#self.files,#self.document.entries,invalid)
        local id=self.files[self.selected_file]
        local issue=id and self.package_errors[id]
        if not issue then
            local ids={};for key in pairs(self.package_errors)do if not settings.disabled[key] then ids[#ids+1]=key end end;table.sort(ids)
            id=ids[1];issue=id and self.package_errors[id]
        end
        if issue then
            if settings.disabled[id] then issue=mod:localize("diy_package_disabled")
            else issue=self.format_message(issue) end
            return summary.."\n"..id..": "..issue,not settings.disabled[id]
        end
        return summary,false
    end
    function self.toggle_package(id)
        if not Packages.id(id) then return report("diy_package_path") end
        settings.disabled[id]=not settings.disabled[id] or nil;persist();return self.scan()
    end
    function self.import_file(name)
        -- A selected installed package is already discovered at startup;
        -- this action explicitly reloads it after authoring changes.
        if not Packages.id(name) then return report("diy_package_path") end
        local ok,why=self.scan();if not ok then return nil,why end
        for i,id in ipairs(self.files)do if id==name then self.selected_file=i end end
        if not self.active_packages[name] then return report(self.package_errors[name] or "diy_package_missing") end
        return self.document
    end
    function self.import_text(text,source)
        local raw,why=Codec.decode(text);if not raw then return report(why) end
        local doc;doc,why=Schema.validate(raw,catalog,kind);if not doc then return report(why) end
        local fs;fs,why=filesystem();if not fs then return report(why) end
        local id=doc.id
        local canonical=assert(Codec.encode(doc))
        local function equivalent(existing_id)
            local files=fs.read_package(existing_id,Packages.id,Packages.path)
            local existing=files and package_api.validate(files,catalog,kind,existing_id)
            return existing and Codec.encode(existing.document)==canonical
        end
        -- The starter and author folders may use a different ID from the
        -- JSON document. Reuse an identical installed document under any
        -- valid folder ID, preserving its Lua/resources and selected keys.
        local installed,listing_error=fs.list_packages(Packages.id)
        if not installed then return report(listing_error) end
        for _,existing_id in ipairs(installed)do
            if equivalent(existing_id) then
                settings.disabled[existing_id]=nil;persist();self.source_file=source
                return self.import_file(existing_id)
            end
        end
        local ok;ok,why=write_document(fs,doc,id,false)
        if not ok and why=="diy_package_exists" then
            -- Clipboard imports create another complete package; never
            -- overwrite an author's Lua/resources with JSON-only content.
            if equivalent(id) then ok=true
            else
                id=id:sub(1,50).."-"..Hash.hex(canonical):sub(1,12)
                ok,why=write_document(fs,doc,id,false)
                if not ok and why=="diy_package_exists" and equivalent(id) then ok=true end
            end
        end
        if not ok then return report(why) end
        self.source_file=source;return self.import_file(id)
    end
    function self.export(name,document)
        local fs,why=filesystem();if not fs then return report(why) end
        if document then
            local doc;doc,why=Schema.validate(document,catalog,kind);if not doc then return report(why) end
            local id="starter-"..kind
            local ok;ok,why=write_document(fs,doc,id,true)
            if not ok and why~="diy_package_exists" then return report(why) end
            self.scan()
            for i,value in ipairs(self.files)do if value==id then self.selected_file=i end end
            self.last_message=ok and "diy_packages_refreshed" or "diy_package_exists"
            return true
        end
        if not next(self.active_packages) then return report("diy_package_missing") end
        local path;path,why=fs.export_packages(self.active_packages,Packages.id,Packages.path)
        if not path then return report(why) end
        self.last_error=nil;self.last_message=mod:localize("diy_packages_exported",path);return path
    end
    function self.snapshot()
        if not snapshot or snapshot_revision~=self.revision then
            snapshot={document=Schema.copy(self.document),options=Schema.copy(self.options),signature=self.signature(),
                packages=Schema.copy(self.active_packages),sources=Schema.copy(self.entry_sources),hashes=Schema.copy(self.entry_hashes)}
            snapshot_revision=self.revision
        end
        return snapshot
    end
    function self.runtime_error(package_id,message)
        self.package_errors[package_id]=tostring(message);self.revision=self.revision+1
    end
    function self.resolve_startup_dependencies()
        if self.startup_dependencies_resolved then return end
        self.startup_dependencies_resolved=true
        for _,pack in pairs(self.packages)do if #(pack.manifest.requires_mods or {})>0 then return self.scan() end end
    end
    -- Initialization performs a single directory scan. There is no filesystem
    -- work from snapshot(), signatures, frame updates, kills, or entry effects.
    self.scan()
    initializing=false
    return self
end
return L
