# Havoc Condition Manager

Choose SoloPlay mission conditions and adjust enemy pacing. HCM provides broad controls; the optional Havoc Enemy Director edits individual fields in the same game templates. Realms sessions use the local host's settings.

## Conditions and mission setup

- Import the current SoloPlay condition list and group eligible entries as Havoc, Auric/Maelstrom, events and general conditions.
- Add or remove conditions without a fixed slot count. A shared native mutator loads once even when several selected conditions include it.
- Choose mission, faction, difficulty and environment in the mission page. An unsupported map/environment pair falls back to Default.
- Apply the selected native pickup, health-station and hazard settings. Native replacement rules still govern conflicting effects.

Available entries depend on the installed game and SoloPlay. HCM supplies no separate Havoc or Maelstrom condition definitions.

## Overall tuning

Open HCM in Mod Options and select Overall tuning. The main page shows the intensity slider and linked values. The 20 individual controls are in Advanced settings; hover titles for details.

Level 1 preserves the native spawn configuration for the selected mission, difficulty and conditions when HED overrides are also at baseline. Levels 2–10 increase ordinary enemies gradually and increase elite, specialist and monster pressure more strongly. Intermediate levels interpolate between the following anchors; integer allowances may remain equal across adjacent levels. A level describes a preset, not a measured difficulty or kill-count multiplier.

- Route population: 1× / 1.2× / 1.5× at levels 1 / 5 / 10. Camp count and event budget: 1× / 1.1× / 1.25×.
- Ordinary enemies per horde or trickle wave: 1× / 1.1× / 1.25×. Horde frequency: 1× / 1.08× / 1.2×; trickle frequency: 1× / 1.05× / 1.1×. Ordinary horde wave counts stay native.
- Existing elite members in horde compositions and patrol teams: 1× / 1.75× / 3×. Ordinary members keep their separate counts. A patrol with 8 elites and 8 ordinary troops requests 24 elites and 8 ordinary troops at 3× elite members. Roamer packs and point-budget events keep native selection ratios and grow through population and budget.
- Specialist capacity: 1× / 2× / 3×; refill frequency: 1× / 2× / 3.25×; surge allowance: 1× / 3× / 6×. Capacity and frequency together represent nominal scheduling capacity, subject to native pauses, player-dependent limits and spawn checks.
- Map monster encounter allowance: 1× / 4× / 8×. Elite patrol encounter allowance: 1× / 3× / 6×. These counts are separate from patrol team size.
- Coordinated tactic allowance: 1× / 2× / 3×. Supported tactics' upper combat-load limit rises from 35 to 70 to 105. The medium-load lower bound stays at 8; capable-player, pacing-stage and other native conditions still apply. HED can append requirements to the adjusted conditions or explicitly replace them.
- General combat capacity: 1× / 1.5× / 2×; recovery duration: 1× / 0.85× / 0.7×. At level 10, the living-plus-queued admission threshold is 290 and the difficulty-5 horde threshold is 190. Condition encounter counts, escalation, mission objectives and separate scripted-event limits retain their settings.

Patrols and monsters first use unused authored encounter points. Overflow waits for valid hidden navigation positions. Both queues share a minimum 20-second interval and receive turns weighted by their starting overflow quotas. A ready queue gets a turn after at most three successful admissions of the other queue. If one class is blocked or fails to spawn, the other may try; only successful spawns consume allowance. Supplemental bosses wait while three ordinary map monsters are alive, and at most two supplemental patrol groups remain active. Native pauses, positions and mission length can still leave allowance unused.

Route and supplemental elite patrols create one member at a time, at least 0.15 seconds apart, while retaining native breeds, group sounds and unit initialization. Route patrols use native formation links and a main-path walking destination. Supplemental patrols spawn with a current combat target and native combat behavior. Every final member position must be hidden from the current valid team, at least 35 metres from each teammate including bots, and 30–120 metres ahead along the main path. Unavailable positions delay the remaining members. Supplemental encounters wait until the native safe-zone restriction ends, then start their 20-second interval; a patrol consumes its encounter allowance only after all members are created.

Supplemental encounters and recycled enemies prefer an existing hidden spawn region around 60 metres ahead of the leading player. Searches use the actual native spawn-group count and a bounded local region. The final distance and visibility checks also apply to positions expanded from a patrol anchor, so a hidden anchor alone is insufficient. These checks reuse native route queries, navigation placement and the horde visibility helper.

Ordinary hordes and mission events use native position selection, authored door groups and the adjusted template pacing. This includes the Courtroom ascender event and its native rear entrances. HCM adds no navigation-route approval or waiting period to those spawns.

Selecting a level replaces all 20 HCM values; individual edits show Custom. Exact saved presets from the previous curve migrate to the same level on the new curve. Other custom values and HED overrides remain. Changes save automatically and apply next mission.

Due spawners run across successive updates while retaining queues, order and completion callbacks. Ordinary and coordinated hordes defer their next wave while the central queue is congested. Temporary pacing refusals preserve unspawned map encounters. Repeated Buff-capacity warnings are summarized; the Buff event pool remains 300.

HCM-hosted missions at every intensity level record a final count of successfully created common enemies, elites, specialists, monsters and other units. This is a spawn receipt, not a kill counter. Blocked coordinated selections can record actual engaged counts and load by category at most once per 30 seconds, capped at 120 snapshots per mission. Encounter overflow reports successful admissions and final unused allowance with blocking reasons. These bounded records use the game log.

Known pacing patrol followers that lose their leader can rejoin native combat once, with recoveries spaced at least 0.15 seconds apart. This uses the existing perception updates and native alert/aggro methods. Mission ownership, player-owned units and traversal protections still apply, and a patrol being recycled is not woken by its own staged removal.

## Automatic rear-enemy recycling

Recycling is active at every intensity level while HCM runs on the local mission host, with no separate switch. Level 1 keeps native spawn multipliers and includes this behavior.

Known common enemies and elites can qualify when they are at least 35 metres from every living teammate, including bots, at least 60 metres behind the entire team along the main path, and remain disengaged and effectively stationary for at least 30 seconds. Movement is measured from the enemy's own position: more than 3 metres from its observation anchor restarts the quiet period. Slow movement accumulates across samples. Player movement, changing targets and replanned path lengths do not count as enemy movement. A retained distant target, persistent modifier or old injury alone does not block recycling. Unavailable main-path information retains the enemy.

Sources include known native roamers, pacing patrols, ordinary trickle groups and ordinary hordes with recorded origins. A retained ordinary-horde group target does not imply mission ownership. Intact walking patrols require all living members to qualify. An individually qualified, stationary member of a combat patrol can retire while its active teammates remain. Groups above 64 members, groups still being assembled and externally controlled patrols remain excluded. Native corpses neither block survivors nor provide allowance.

Recorded non-objective event elites can enter the quiet period only when active scripted events, event trickles and queued event starts have ended. Ordinary scripted event waves receive no additional observation records. Required mission targets and automatic-event ownership remain protected, as do specialists, bosses, captains, companions and player-owned units. Recent damage, active combat effects, marks, invulnerability, traversal and visibility also prevent removal. Each removal rechecks actual movement, current team distance, main-path position and native immediate visibility.

Recycling uses native removal and recreation. Each removed original can provide one replacement of the same breed; whole-patrol transfers retain the removed members' composition and grouping. Health is initialized again and random modifiers can be rerolled. Non-death retirement of rotten-armour units suppresses only the death liquid, sound and visual payload. Normal kills and other buff cleanup retain native behavior.

Replacements wait for native pacing, capacity and a suitable hidden forward position. Allowance is limited to 24 records and 96 units, expires after 180 seconds and can remain unused at mission end. Different transfers are at least 8 seconds apart; whole-patrol members enter the native queue at least 0.15 seconds apart. Consumption rechecks current positions and visibility; rejected requests retain their allowance. Retiring a replacement never produces another credit.

Observation reuses the native perception schedule and existing candidate queue. Movement samples store three numbers without allocating boxed vectors or querying remaining navigation distance. Detailed checks remain limited to four per second and removal to one unit per second. Whole-patrol retirement processes one group at a time, with at least 20 seconds between group starts. There is no added whole-map enemy scan or independent pathfinding probe. Ready observations remain queued for the next available removal slot.

Bounded game-log receipts distinguish removal, replacement allowance, queued/cancelled requests, actual creation and unused allowance. Spawn-batch records retain source, event door group, first position and counts. Patrol completion records are capped at 64 per mission; the first eight removals and orphan recoveries are logged. Eligibility figures count observations and changes in refusal reasons, not unique remaining enemies.

## Fine editing and saved settings

Havoc Enemy Director adds Detailed tuning. HCM first supplies broad changes; a HED field override then sets that field's exact value. Native difficulty and condition modifiers can still change the final result. Mission combat-node budgets are a specific case: HCM's event-budget multiplier scales the final budget and its native cap after the node's base values and native modifiers.

Values save automatically and apply when the next mission starts. A running mission retains its starting configuration. DMF switches apply immediately in the hub and are deferred during a mission. Disabling HCM restores SoloPlay's menu and suspends HED for later missions.

The first use imports valid native IDs from the previous HCM selection. Retired condition aliases are omitted; the original saved value is retained. Old category multipliers and custom-generator settings are not converted into native template edits. Start from the new defaults and configure the controls before your next mission.

English, Simplified Chinese and Traditional Chinese follow the game language. Native identifiers remain visible where needed to distinguish exact templates.

## Requirements

Darktide Mod Loader, Darktide Mod Framework and SoloPlay are required. Realms is optional for co-op. Havoc Enemy Director is optional. Other mods replacing the same native templates or scheduling methods may conflict.

## Vortex installation

- Close the game and install the requirements. Import this ZIP with Install From File, enable it and select Deploy Mods.
- Enable HavocConditionManager in Load Order after SoloPlay. Place the optional HavocEnemyDirector after HavocConditionManager.
- Restart the game and open Havoc Condition Manager in Mod Options.

## Manual installation

- Close the game. When upgrading, remove the previous HavocConditionManager installation folder before extracting the new ZIP; saved settings are stored separately.
- Extract the ZIP into Darktide/mods, producing mods/HavocConditionManager.
- Add HavocConditionManager on its own line after SoloPlay in mods/mod_load_order.txt. Place the optional HavocEnemyDirector after it.
- Restart the game and open HCM in Mod Options.

## Credits

SoloPlay and the original UI foundation: deluxghost. Native game systems and assets: Fatshark. Game-source reference: Aussiemon/Darktide-Source-Code.
