-- Reuse the native perception scheduler, route data, LOS and despawn queue.
-- Only known native pacing roamers/patrols and one-transfer replacements qualify.
local mod=get_mod("HavocConditionManager")
local Roamer=require("scripts/managers/pacing/roamer_pacing/roamer_pacing")
local Monster=require("scripts/managers/pacing/monster_pacing/monster_pacing")
local Horde=require("scripts/managers/horde/horde_manager")
local Perception=require("scripts/extension_systems/perception/minion_perception_extension")
local Health=require("scripts/extension_systems/health/health_extension")
local Placement=mod.spawn_placement
local CHECK_INTERVAL,QUIET_TIME,BEHIND,DISTANCE_SQ=5,30,60,35*35
local MAX_CREDITS,CREDIT_LIFETIME,SPAWN_INTERVAL=24,180,8
local state,patrol_context
local MAX_GROUP,MAX_CREDIT_UNITS=64,96
local protected_keywords={"bleeding","burning","warpfire_burning","electrocuted","electrocuted_chain_lightning",
    "electrocuted_arc","electrocuted_arc_ability","electrocuted_arc_grenade","electrocuted_shock_mine",
    "taunted","veteran_tag","sticky_projectiles","weapon_malfunction","toxin"}
local function current()
    if not state then state={credits={},checks=0,next_check=0,next_remove=0,next_spawn=0,
        removed=0,credited=0,queued=0,created=0,discarded=0,cancelled=0,los=0,positions=0,credit_units=0,
        next_patrol=0,patrols=0,interrupted=0,rejoined=0,reasons={},tracked=0,observed=0,qualified=0,
        observations={},first=1,last=0,target_candidates=0} end
    return state
end
local function extension(unit,name) return ScriptUnit.has_extension(unit,name) end
local function native_group(unit)
    local ext=extension(unit,"group_system")
    return ext and ext.group and ext:group()
end
local function attach(unit,owner,record,side_id,origin)
    local ext=unit and extension(unit,"perception_system")
    if not ext then return end
    local group=origin and native_group(unit)
    if group then
        group._hcm_recycling=group._hcm_recycling or origin
        origin=group._hcm_recycling
    end
    ext._hcm_straggler={owner=owner,record=record,side_id=side_id,next_check=0,group=group,origin=origin}
    current().tracked=current().tracked+1
end
mod:hook_safe(Roamer,"_try_activate_roamer",function(self,record,side_id)
    if mod.has_local_gameplay_authority() and record.active and record.spawned_unit then
        attach(record.spawned_unit,self,record,side_id,record.patrol_id and {kind="roamers"})
    end
end)
-- Observe only native pacing patrol creation. Mission-controlled and expedition
-- loot patrols retain their original ownership and cannot enter this pool.
mod:hook(Monster,"_spawn_boss_patrol",function(fn,self,record,ahead_distance,side_id,...)
    if mod.has_local_gameplay_authority() and self._pacing_type=="default" then
        return mod.queue_native_patrol(self,record,side_id)
    end
    local previous=patrol_context
    patrol_context=mod.has_local_gameplay_authority() and
        (self._pacing_type=="default" or self._hcm_recyclable_patrol) and {kind="monsters"} or nil
    local ok,result=pcall(fn,self,record,ahead_distance,side_id,...)
    patrol_context=previous
    if not ok then error(result,0) end
    return result
end)
mod:hook(Horde,"horde",function(fn,self,kind,template,side_id,target_side_id,composition,...)
    local previous=patrol_context
    local previous_batch=mod.current_spawn_batch
    local params=select(9,...)
    patrol_context=mod.has_local_gameplay_authority() and template=="trickle_horde" and
        not (previous_batch and previous_batch.event) and
        not (params and (params.externally_controlled_patrol or params.mutator_name)) and
        {kind="trickle_hordes",health=select(5,...)} or nil
    if mod.has_local_gameplay_authority() and not previous_batch then
        local batch=mod.new_spawn_batch(template,side_id,target_side_id,params and (params.externally_controlled_patrol or params.mutator_name))
        batch.horde=true;batch.kind=template=="trickle_horde" and "trickle_hordes" or "hordes"
        mod.current_spawn_batch=batch
    end
    local ok,a,b,c,d,e=pcall(fn,self,kind,template,side_id,target_side_id,composition,...)
    patrol_context=previous
    mod.current_spawn_batch=previous_batch
    if not ok then error(a,0) end
    return a,b,c,d,e
end)
mod.track_redeployed_unit=function(unit)
    local board=BLACKBOARDS and BLACKBOARDS[unit]
    local batch=mod.current_spawn_batch
    if board and batch and batch.event then
        if batch.source~="mission_spawner" or batch.protected_objective or not batch.event_manager then return end
        local perception=extension(unit,"perception_system")
        local tags=perception and perception._breed and perception._breed.tags or {}
        -- Only extend event coverage to the reported elite leftovers. Large
        -- scripted common waves do not need additional observation records.
        if not tags.elite or tags.special or tags.monster or tags.captain or tags.companion then return end
        local sides=Managers.state.extension:system("side_system")
        local side=sides.side_by_unit[unit]
        if side then
            attach(unit,nil,nil,side.side_id)
            local meta=extension(unit,"perception_system")._hcm_straggler
            meta.event_batch=batch;meta.origin={kind="hordes"}
        end
        return
    end
    if board and batch and batch.horde and not batch.event and batch.kind=="hordes" then
        local sides=Managers.state.extension:system("side_system")
        local side=sides.side_by_unit[unit]
        if side then
            attach(unit,nil,nil,side.side_id)
            local meta=extension(unit,"perception_system")._hcm_straggler
            meta.origin={kind="hordes"};meta.horde_batch=batch
        end
        return
    end
    if board and board.spawn and (board.spawn.spawn_source=="hcm_redeployed" or board.spawn.spawn_source=="hcm_patrol" or patrol_context) then
        local sides=Managers.state.extension:system("side_system")
        local side=sides.side_by_unit[unit]
        if side then
            local replacement=board.spawn.spawn_source=="hcm_redeployed"
            local group=native_group(unit)
            attach(unit,nil,nil,side.side_id,group and group._hcm_recycling or patrol_context)
            if replacement then current().created=current().created+1 end
        end
    end
end
local function reset_candidate(meta) meta.since=nil end
local function note_veto(meta,reason)
    if reason and meta.reason~=reason then
        local counts=current().reasons;counts[reason]=(counts[reason] or 0)+1
    end
    meta.reason=reason
end
local function moved(meta,position)
    -- Persist three numbers, avoiding per-sample vector boxing/allocations.
    local x,y,z=Vector3.to_elements(position)
    if meta.motion_x==nil then meta.motion_x=x;meta.motion_y=y;meta.motion_z=z
    else
        local dx,dy,dz=x-meta.motion_x,y-meta.motion_y,z-meta.motion_z
        if dx*dx+dy*dy+dz*dz<=9 then return end
        meta.motion_x=x;meta.motion_y=y;meta.motion_z=z
        note_veto(meta,"moving");reset_candidate(meta)
        return true
    end
end
local function has_objective(unit)
    local objective=extension(unit,"mission_objective_target_system")
    if not objective then return false end
    if not objective.objective_name then return true end
    local name=objective:objective_name()
    -- The native component is present before an objective is assigned. Its
    -- initial "default" name is explicitly excluded by the native registrar.
    return objective._registered_objective or name and name~="" and name~="default"
end
local function basic(ext,unit,meta)
    local board=BLACKBOARDS and BLACKBOARDS[unit]
    local perception=board and board.perception
    local breed=ext._breed
    local tags=breed and breed.tags or {}
    if not HEALTH_ALIVE[unit] or ext._is_perception_disabled or not perception or not breed
        or breed.breed_type~="minion" or tags.special or tags.monster or tags.captain or tags.companion
        or perception.lock_target or perception.has_line_of_sight then return nil,"combat_or_type" end
    local spawn=board.spawn
    if not spawn or spawn.is_exiting_spawner then return nil,"spawner" end
    if meta.record then
        if spawn.spawn_source~="roamer_pacing" or meta.record.patrol_id and not meta.group
            or meta.record._hcm_retired or meta.record.spawned_unit~=unit then return nil,"roamer_source" end
    elseif not meta.horde_batch and not meta.event_batch and spawn.spawn_source~="hcm_redeployed" and not (meta.group and meta.origin and
        (meta.origin.kind=="monsters" and (not spawn.spawn_source or spawn.spawn_source=="" or spawn.spawn_source=="hcm_patrol") or
        meta.origin.kind=="trickle_hordes" and (not spawn.spawn_source or spawn.spawn_source=="" or spawn.spawn_source=="trickle_patrol"))) then return nil,"patrol_source" end
    local group=board.group_data
    if meta.event_batch and not mod.event_batch_released(meta.event_batch) then return nil,"event_active" end
    -- Ordinary horde templates assign a group target for navigation. That is
    -- not objective ownership, and can persist after all combat has stopped.
    if group and (group.group_target and not (meta.horde_batch or meta.event_batch) or
        group.owning_auto_event_id and group.owning_auto_event_id~="") then return nil,"group_control" end
    local nav=extension(unit,"navigation_system")
    if not nav or not nav.is_following_path
        or not nav.is_using_smart_object or nav:is_using_smart_object() then return nil,"navigation" end
    local health=extension(unit,"health_system")
    if not health or not health.current_health_percent
        or health.is_invulnerable and health:is_invulnerable() then return nil,"health" end
    local t=Managers.time:time("gameplay")
    if meta.last_damage and t-meta.last_damage<QUIET_TIME then return nil,"recent_damage" end
    if has_objective(unit) then return nil,"objective" end
    local tag=extension(unit,"smart_tag_system")
    if tag and (not tag.tag_id or tag:tag_id()) then return nil,"tag" end
    local buffs=extension(unit,"buff_system")
    if not buffs or not buffs.has_keyword then return nil,"unknown_buffs" end
    for _,keyword in ipairs(protected_keywords) do if buffs:has_keyword(keyword) then return nil,"buff_"..keyword end end
    local spawn_manager=Managers.state.minion_spawn
    if not spawn_manager or not spawn_manager._spawned_minions_index_lookup[unit]
        or spawn_manager._minions_with_owners[unit] then return nil,"owner" end
    return breed
end
local function behind_team(ext,unit,meta)
    local main=Managers.state.main_path
    if not main or not main.is_main_path_ready or not main:is_main_path_ready() then return nil,"route_unavailable" end
    local side=ext._side_system and ext._side_system.side_by_unit[unit]
    local players=side and side.enemy_player_units
    if not players or #players==0 or #players>8 then return nil,"players_unavailable" end
    local position=POSITION_LOOKUP[unit]
    if not position then return nil,"position_unavailable" end
    local distance=main:travel_distance_from_position(position,true)
    if not distance then return nil,"route_unavailable" end
    local count=0
    for _,player in ipairs(players) do
        if HEALTH_ALIVE[player] then
            local player_position=POSITION_LOOKUP[player]
            if not player_position then return nil,"position_unavailable" end
            if Vector3.distance_squared(position,player_position)<DISTANCE_SQ then return nil,"near_teammate" end
            if ext:has_line_of_sight(player) then return nil,"cached_los" end
            local progress=main:travel_distance_from_position(player_position,true)
            if not progress or progress-distance<BEHIND then return nil,"not_behind_team" end
            count=count+1
        end
    end
    if count==0 then return nil,"players_unavailable" end
    return players,side
end
local function rejoin_orphan(ext,unit,meta,t)
    if state and (t<(state.next_rejoin or 0) or state.patrol_job and state.patrol_job.group==meta.group) then return end
    local board=BLACKBOARDS and BLACKBOARDS[unit]
    local patrol=board and board.patrol
    local perception=board and board.perception
    local group=board and board.group_data
    local tags=ext._breed and ext._breed.tags or {}
    if meta.rejoined or not meta.group or not meta.origin or meta.origin.replacement
        or not HEALTH_ALIVE[unit] or ext._is_perception_disabled
        or tags.special or tags.monster or tags.captain or tags.companion
        or not patrol or not patrol.should_patrol or (patrol.patrol_index or 0)<=1
        or HEALTH_ALIVE[patrol.patrol_leader_unit] or not perception or perception.target_unit or perception.lock_target
        or group and (group.group_target or group.owning_auto_event_id and group.owning_auto_event_id~="")
        or has_objective(unit) then return end
    local nav=extension(unit,"navigation_system")
    local manager=Managers.state.minion_spawn
    if not nav or not nav.is_using_smart_object or nav:is_using_smart_object()
        or not manager or manager._minions_with_owners[unit] or not ext.alert or not ext.aggro then return end
    local context=Placement.context(meta.side_id,Managers.state.pacing._target_side_id)
    if not context or not HEALTH_ALIVE[context.target] or not context.side.ai_target_units
        or not context.side.ai_target_units[context.target] then return end
    -- BtPatrolAction returns immediately forever when its follow unit dies.
    -- Hand this one orphan back to native combat instead of duplicating patrol
    -- navigation or changing the running behavior action's private scratchpad.
    ext:alert(context.target);ext:aggro();meta.rejoined=true
    local s=current();s.rejoined=s.rejoined+1;s.next_rejoin=t+0.15
    if s.rejoined<=8 then mod:info("Patrol orphan rejoined combat: %s.",ext._breed.name) end
end
mod:hook_safe(Perception,"update",function(self,unit,dt,t)
    local meta=self._hcm_straggler
    if not meta or not mod.has_local_gameplay_authority() then return end
    if t>=(meta.next_rejoin or 0) then
        meta.next_rejoin=t+CHECK_INTERVAL;rejoin_orphan(self,unit,meta,t)
    end
    meta.seen=t
    -- A target can remain selected indefinitely outside detection/LOS. Only
    -- actual sight/engagement or renewed approach cancels the quiet interval.
    if meta.event_batch and not mod.event_batch_released(meta.event_batch) then
        note_veto(meta,"event_active");reset_candidate(meta);return
    end
    local perception=self._perception_component
    if not perception or perception.lock_target or perception.has_line_of_sight then
        note_veto(meta,"combat_or_los");reset_candidate(meta);return
    end
    local side=self._side_system and self._side_system.side_by_unit[unit]
    local players=side and side.enemy_player_units
    local position=POSITION_LOOKUP[unit]
    if not position or not players or #players==0 then reset_candidate(meta);return end
    for _,player in ipairs(players) do
        if HEALTH_ALIVE[player] and POSITION_LOOKUP[player] then
            local distance=Vector3.distance_squared(position,POSITION_LOOKUP[player])
            if distance<DISTANCE_SQ or self:has_line_of_sight(player) then
                note_veto(meta,distance<DISTANCE_SQ and "near_teammate" or "cached_los");reset_candidate(meta);return
            end
        end
    end
    if t<meta.next_check then return end
    meta.next_check=t+CHECK_INTERVAL
    -- Measure the minion itself. Player/bot motion and a replanned path can
    -- reduce remaining distance even while this unit never moves at all.
    -- Keep the anchor across samples so slow genuine pursuit still resets
    -- the quiet timer. Any direction protects a moving stair/path follower.
    if moved(meta,position) then return end
    local s=current()
    if meta.enqueued or s.last-s.first+1>=256 then return end
    meta.enqueued=true;s.last=s.last+1;s.observations[s.last]={unit=unit,ext=self,meta=meta}
end)
mod:hook_safe(Health,"add_damage",function(self,amount)
    if not amount or amount<=0 then return end
    local ext=self._unit and extension(self._unit,"perception_system")
    local meta=ext and ext._hcm_straggler
    if meta then meta.last_damage=Managers.time:time("gameplay");reset_candidate(meta) end
end)
local function observe(s,t)
    if t<s.next_check then return end
    s.next_check=t+1
    for _=1,4 do
        local item=s.observations[s.first]
        if not item then break end
        s.observations[s.first]=nil;s.first=s.first+1
        local self,unit,meta=item.ext,item.unit,item.meta
        meta.enqueued=nil
        if HEALTH_ALIVE[unit] and self._hcm_straggler==meta then
            s.observed=s.observed+1
            local players,side
            local breed,reason=basic(self,unit,meta)
            if breed then players,side=behind_team(self,unit,meta);reason=not players and side or nil end
            note_veto(meta,reason)
            if not players then reset_candidate(meta)
            else
                meta.checked=t
                if not meta.since then
                    s.qualified=s.qualified+1;meta.since=t
                    if self._perception_component.target_unit then s.target_candidates=s.target_candidates+1 end
                end
                if t-meta.since>=QUIET_TIME and not s.pending and not s.patrol_job then
                    s.pending={unit=unit,ext=self,meta=meta,at=t}
                    -- Keep the remaining observations in the existing FIFO
                    -- for the next second. Discarding their ready result here
                    -- made them wait another full perception interval.
                    break
                end
            end
        end
    end
    if s.first>s.last then s.first=1;s.last=0 end
end
local function add_credit(s,credit,t)
    local count=credit.breeds and #credit.breeds or 1
    if #s.credits<MAX_CREDITS and s.credit_units+count<=MAX_CREDIT_UNITS then
        if #s.credits==0 then s.next_spawn=math.max(s.next_spawn,t+SPAWN_INTERVAL) end
        credit.expires=t+CREDIT_LIFETIME
        s.credits[#s.credits+1]=credit;s.credit_units=s.credit_units+count;s.credited=s.credited+count
    else s.discarded=s.discarded+count end
end
local function group_ready(group,t,job)
    local system=Managers.state.extension:system("group_system")
    if not group or #group.members==0 or #group.members>MAX_GROUP or
        system._locked_group_ids and system._locked_group_ids[group.id] then return end
    local live=0
    for _,unit in ipairs(group.members) do
        if HEALTH_ALIVE[unit] and (not job or not job.removed[unit]) then
            local ext=extension(unit,"perception_system")
            local meta=ext and ext._hcm_straggler
            if not meta or meta.group~=group or not meta.since or t-meta.since<QUIET_TIME or
                not meta.checked or not meta.seen or t-meta.seen>6 or not basic(ext,unit,meta) or
                job and not job.members[unit] then return end
            -- Cheap current vetoes reuse the native cached LOS; route projection
            -- remains on the four-per-second observation budget and final unit.
            local side=ext._side_system.side_by_unit[unit]
            local players=side and side.enemy_player_units
            local position=POSITION_LOOKUP[unit]
            if not position or not players or #players==0 then return end
            for _,player in ipairs(players) do
                if HEALTH_ALIVE[player] and (not POSITION_LOOKUP[player] or
                    Vector3.distance_squared(position,POSITION_LOOKUP[player])<DISTANCE_SQ or
                    ext:has_line_of_sight(player)) then return end
            end
            live=live+1
        end
    end
    return live>0,live
end
local function finish_patrol(s,t,interrupted)
    local job=s.patrol_job
    if #job.breeds>0 and not job.origin.replacement then
        add_credit(s,{breeds=job.breeds,side_id=job.side_id,kind=job.origin.kind,health=job.origin.health},t)
    end
    s.patrol_job=nil
    if interrupted then
        s.interrupted=s.interrupted+1
        for _,unit in ipairs(job.group.members) do
            if HEALTH_ALIVE[unit] then
                local ext=extension(unit,"perception_system")
                if ext and ext._hcm_straggler then reset_candidate(ext._hcm_straggler) end
            end
        end
    else s.patrols=s.patrols+1 end
end
local function detached_combat_member(unit,meta)
    local group=meta.group
    local board=BLACKBOARDS[unit]
    local system=Managers.state.extension:system("group_system")
    -- A combat group can leave one stationary member far behind while its
    -- others keep fighting. Native despawn removes just this member. Keep
    -- passive formations and groups still being assembled as one operation.
    return group and meta.origin and #group.members<=MAX_GROUP and
        not (system._locked_group_ids and system._locked_group_ids[group.id]) and
        not (board.patrol and board.patrol.should_patrol)
end
local function recycle(s,t)
    local pending=s.pending
    if t<s.next_remove or not pending and not s.patrol_job then return end
    s.pending=nil;s.next_remove=t+1
    if not s.patrol_job and pending.meta.group then
        local group=pending.meta.group
        if t>=s.next_patrol and group_ready(group,t) then
            local job={group=group,origin=pending.meta.origin,side_id=pending.meta.side_id,
                list={},members={},removed={},breeds={},index=1}
            for _,unit in ipairs(group.members) do
                if HEALTH_ALIVE[unit] then job.list[#job.list+1]=unit;job.members[unit]=true end
            end
            s.patrol_job=job;s.next_patrol=t+20
        elseif not detached_combat_member(pending.unit,pending.meta) then
            note_veto(pending.meta,"group_not_ready");return
        end
    end
    local job=s.patrol_job
    if job then
        local ready,live=group_ready(job.group,t,job)
        if not ready then finish_patrol(s,t,live~=0);return end
        -- Native group membership is removed when the entity is destroyed,
        -- later than health death. Corpses neither block nor earn credits.
        while job.list[job.index] and not HEALTH_ALIVE[job.list[job.index]] do job.index=job.index+1 end
        local unit=job.list[job.index]
        if not unit then finish_patrol(s,t,false);return end
        local ext=extension(unit,"perception_system")
        pending={unit=unit,ext=ext,meta=ext and ext._hcm_straggler,at=t}
    end
    local unit,ext,meta=pending.unit,pending.ext,pending.meta
    if t-pending.at>2 or not meta or not meta.since or t-meta.since<QUIET_TIME then return end
    local position=POSITION_LOOKUP[unit]
    if position and moved(meta,position) then
        if job then finish_patrol(s,t,true) end
        return
    end
    local breed=basic(ext,unit,meta)
    local players=breed and behind_team(ext,unit,meta)
    if not players or not ext.immediate_line_of_sight_check then
        reset_candidate(meta);if job then finish_patrol(s,t,true) end;return
    end
    for _,player in ipairs(players) do
        if HEALTH_ALIVE[player] then
            s.los=s.los+1
            if ext:immediate_line_of_sight_check(player) then
                reset_candidate(meta);if job then finish_patrol(s,t,true) end;return
            end
        end
    end
    local manager=Managers.state.minion_spawn
    local spawn_source=BLACKBOARDS[unit].spawn.spawn_source
    if not spawn_source or spawn_source=="" then spawn_source=meta.origin and meta.origin.kind or "native" end
    mod.retiring_units[unit]=true
    manager:despawn_minion(unit)
    if manager._spawned_minions_index_lookup[unit] then mod.retiring_units[unit]=nil;return end
    s.removed=s.removed+1
    if s.removed<=8 then
        mod:info("Rear unit recycled: %s; source %s; group %s.",breed.name,
            spawn_source,tostring(meta.group and meta.group.id or "none"))
    end
    ext._hcm_straggler=nil
    if meta.record then
        -- Keep active until native dead-unit bookkeeping removes the record.
        meta.record._hcm_retired=true;meta.record.active=true
        meta.owner._roamer_lookup[unit]=nil
        if not job then add_credit(s,{breed=breed.name,side_id=meta.side_id},t) end
    end
    if job then
        job.removed[unit]=true;job.breeds[#job.breeds+1]=breed.name;job.index=job.index+1
        if job.index>#job.list then finish_patrol(s,t,false) end
    elseif meta.horde_batch or meta.event_batch then
        add_credit(s,{breed=breed.name,side_id=meta.side_id,kind="hordes"},t)
    elseif meta.group and not meta.record and meta.origin and not meta.origin.replacement then
        add_credit(s,{breed=breed.name,side_id=meta.side_id,kind=meta.origin.kind,health=meta.origin.health},t)
    end
end
local function replenish(s,pacing,t)
    if t<s.next_spawn or #s.credits==0 then return end
    s.next_spawn=t+SPAWN_INTERVAL
    while s.credits[1] and s.credits[1].expires<t do
        local expired=table.remove(s.credits,1)
        local count=(expired.breeds and #expired.breeds or 1)-(expired.index or 1)+1
        s.discarded=s.discarded+count;s.credit_units=s.credit_units-count
        if expired.group_id then Managers.state.extension:system("group_system"):unlock_group_id(expired.group_id) end
    end
    local credit=s.credits[1]
    if not credit or credit.inflight or not pacing:spawn_type_enabled(credit.kind or "roamers") then return end
    local count=(credit.breeds and #credit.breeds or 1)-(credit.index or 1)+1
    local manager=Managers.state.minion_spawn
    -- Native admission checks use '>'; leave headroom for other spawners.
    local capacity=math.floor(145*mod.template_runtime.config().coarse.combat_tolerance+0.5)
    if manager._spawn_queue_size>=16 or manager:total_allocated_num_enemies()+1>capacity-4 then return end
    local context=Placement.context(credit.side_id,pacing._target_side_id)
    if not context then return end
    if not credit.positions then
        s.positions=s.positions+1
        local anchor=Placement.anchor(context,credit)
        if not anchor then return end
        local positions={}
        local num=GwNavQueries.flood_fill_from_position(pacing._nav_world,anchor,2,2,count,positions)
        if not num or num<1 then return end
        credit.positions={};credit.position_index=1
        for i=1,num do credit.positions[i]=Vector3Box(positions[i]) end
    end
    local position=credit.positions[credit.position_index]:unbox()
    if not Placement.within_limits(context,position) then credit.positions=nil;return end
    if credit.breeds and not credit.group_id then
        local system=Managers.state.extension:system("group_system")
        credit.group_id=system:generate_group_id()
        system:lock_group_id(credit.group_id)
        system:group_from_id(credit.group_id)._hcm_recycling={kind=credit.kind,replacement=true}
    end
    local params=manager:queue_minion_to_spawn(credit.breeds and credit.breeds[credit.index or 1] or credit.breed,
        position,Quaternion.identity(),credit.side_id)
    params.spawn_source="hcm_redeployed";params.optional_aggro_state="aggroed"
    params.optional_target_unit=context.target;params.optional_group_id=credit.group_id;params.optional_health_modifier=credit.health
    params._hcm_redeployment={owner=s,credit=credit,target_side_id=pacing._target_side_id}
    credit.inflight=true;s.queued=s.queued+1
end
-- A queued native request may wait several frames. Validate again at actual
-- consumption, and return a refused unit to its credit instead of losing it.
mod.prepare_redeployment=function(ticket,entry)
    if ticket.owner~=state or not mod.has_local_gameplay_authority() then return false end
    local pacing=Managers.state.pacing
    local t=Managers.time:time("gameplay")
    local credit=ticket.credit
    if credit.expires<t or not pacing:spawn_type_enabled(credit.kind or "roamers") then return false end
    local context=Placement.context(credit.side_id,ticket.target_side_id)
    if not context or not Placement.valid(context,entry.position:unbox()) then return false end
    entry.optional_target_unit=context.target
    return true
end
mod.finish_redeployment=function(ticket,unit)
    local s,credit=ticket.owner,ticket.credit
    credit.inflight=nil
    if s~=state then return end
    local t=Managers.time:time("gameplay")
    if not unit then s.cancelled=s.cancelled+1;credit.positions=nil;s.next_spawn=t+SPAWN_INTERVAL;return end
    credit.index=(credit.index or 1)+1;credit.position_index=credit.position_index+1;s.credit_units=s.credit_units-1
    if credit.position_index>#credit.positions then credit.positions=nil end
    if credit.index>(credit.breeds and #credit.breeds or 1) then
        table.remove(s.credits,1)
        if credit.group_id then Managers.state.extension:system("group_system"):unlock_group_id(credit.group_id) end
        s.next_spawn=t+SPAWN_INTERVAL
    else s.next_spawn=t+0.15 end
end
mod.update_straggler_recycling=function(pacing,t)
    if not state or not mod.has_local_gameplay_authority() then return end
    observe(state,t)
    recycle(state,t)
    replenish(state,pacing,t)
end
mod.finish_straggler_recycling=function()
    if state then
        local s=state
        local system=Managers.state.extension and Managers.state.extension:system("group_system")
        for _,credit in ipairs(s.credits) do if system and credit.group_id then system:unlock_group_id(credit.group_id) end end
        if s.patrol_job and not s.patrol_job.origin.replacement then
            s.discarded=s.discarded+#s.patrol_job.breeds
        end
        local reasons={}
        for reason,count in pairs(s.reasons) do reasons[#reasons+1]=reason.."="..tostring(count) end
        table.sort(reasons)
        mod:info("Rear distant-target candidates: %d; active DOT/visibility/recent damage remain protected.",s.target_candidates)
        mod:info("Rear eligibility receipt: tracked %d; detailed checks %d; quiet periods started %d; orphan rejoined %d; veto transitions [%s].",
            s.tracked,s.observed,s.qualified,s.rejoined,table.concat(reasons,", "))
        mod:info("Rear recycling receipt: removed %d; credits %d; queued %d; created %d; pending %d; discarded %d; cancelled requests %d; retirement LOS queries %d; spawn-position queries %d.",
            s.removed,s.credited,s.queued,s.created,s.credit_units,s.discarded,s.cancelled,s.los,s.positions)
        if s.patrols>0 or s.interrupted>0 then
            mod:info("Rear patrol receipt: completed groups %d; interrupted groups %d.",s.patrols,s.interrupted)
        end
    end
    state=nil;patrol_context=nil
end
return true
