# Havoc Condition Manager

Choose SoloPlay mission conditions and adjust enemy pacing. HCM provides broad controls; the optional Havoc Enemy Director edits individual fields in the same game templates. Realms sessions use the local host's settings.

## Conditions and mission setup

- Import the current SoloPlay condition list and group eligible entries as Havoc, Auric/Maelstrom, events and general conditions.
- Add or remove conditions without a fixed slot count. A shared native mutator loads once even when several selected conditions include it.
- Choose mission, faction, difficulty and environment in the mission page. An unsupported map/environment pair falls back to Default.
- Apply the selected native pickup, health-station and hazard settings. Native replacement rules still govern conflicting effects.

Available entries depend on the installed game and SoloPlay. HCM supplies no separate Havoc or Maelstrom condition definitions.

## Overall tuning

**Open HCM in Mod Options and select Overall tuning. Overall intensity selects a coordinated level from 1 to 10; individual sliders remain multipliers. Click values to type and hover titles for explanations.**

The intensity profile favors elite patrols, specialists and map monsters. It sustains pressure through more follow-up waves and encounters instead of raising every multiplier together. A level is a preset, not a promise that final difficulty or enemy count increases by that number.

- Elite patrol and map monster encounters: 2× at level 5, 3× at level 10.
- Horde waves, coordinated tactic allowance, specialist slots, specialist replenishment frequency and specialist surge allowance: 1.5× at level 5, 2× at level 10.
- Combat load tolerance: 1.25× at level 5, 1.5× at level 10.
- Map enemy density, encampments, enemies per horde wave, ordinary horde frequency, trickle size and frequency, event budgets, condition encounter counts, recovery duration and escalation strength stay at 1×.

Intermediate levels increase gradually. Level 1 sets all HCM multipliers to their defaults. Choosing a level replaces all 18 HCM values, so old size, frequency and wave multipliers do not remain stacked. Individual edits are still available up to 10× and appear as Custom when they no longer match a profile. HED field overrides are retained.

The six groups cover map population, horde encounters, trickle waves, specialists, monsters and events, and combat pacing. Wave spacing, encounter conditions and concurrent-enemy limits continue to govern arrivals. A template with no eligible patrol or monster source does not gain one from a multiplier; rounding and available map locations can limit the result.

Temporary pacing limits defer unspawned map enemies instead of deleting their plans while modified settings are active. They can spawn when capacity returns and the squad is still within activation range. This preserves later encounters without forcing extra enemies onto an already crowded battlefield.

Existing values are preserved when upgrading. Select an intensity level again to apply this profile; an older all-equal configuration remains Custom until changed. Values save automatically and apply next mission.

## Fine editing and saved settings

Havoc Enemy Director adds Detailed tuning. HCM first supplies broad changes; a HED field override then sets that field's exact value. Native difficulty and condition modifiers can still change the final result. Mission combat-node budgets are a specific case: HCM's event-budget multiplier scales the final budget and its native cap after the node's base values and native modifiers.

Values save automatically and apply when the next mission starts. A running mission retains its starting configuration. DMF switches apply immediately in the hub and are deferred during a mission. Disabling HCM restores SoloPlay's menu and suspends HED for later missions.

The first use imports valid native IDs from the previous HCM selection. Retired condition aliases are omitted; the original saved value is retained. Old category multipliers and custom-generator settings are not converted into native template edits. Start from the new defaults and configure the controls before your next mission.

English, Simplified Chinese and Traditional Chinese follow the game language. Native identifiers remain visible where needed to distinguish exact templates.

## Requirements

Darktide Mod Loader, Darktide Mod Framework and SoloPlay are required. Realms is optional for co-op. Havoc Enemy Director is optional. Other mods replacing the same native templates or scheduling methods may conflict.

## Vortex installation

- Close the game and install the requirements. Import this ZIP with Install From File, enable it and select Deploy Mods.
- Enable HavocConditionManager in Load Order after SoloPlay. Place the optional HavocEnemyDirector after HavocConditionManager.
- Restart the game and open Havoc Condition Manager in Mod Options.

## Manual installation

- Close the game. When upgrading, remove the previous HavocConditionManager installation folder before extracting the new ZIP; saved settings are stored separately.
- Extract the ZIP into Darktide/mods, producing mods/HavocConditionManager.
- Add HavocConditionManager on its own line after SoloPlay in mods/mod_load_order.txt. Place the optional HavocEnemyDirector after it.
- Restart the game and open HCM in Mod Options.

## Credits

SoloPlay and the original UI foundation: deluxghost. Native game systems and assets: Fatshark. Game-source reference: Aussiemon/Darktide-Source-Code.
