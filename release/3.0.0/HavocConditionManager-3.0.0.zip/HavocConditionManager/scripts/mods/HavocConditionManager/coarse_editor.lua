local mod=get_mod("HavocConditionManager")
local S=mod.template_schema
return function(view,ui)
    local lang=mod:localize("native_language")
    local function text(d) return S.text(d,lang) end
    local groups={{"map","Map population","地图布置"},{"hordes","Horde encounters","尸潮遭遇"},{"trickle","Trickle waves","小股敌潮"},
        {"specials","Specialists","特感调度"},{"encounters","Monsters & events","怪物与事件"},{"pacing","Combat pacing","战斗节奏"}}
    view._hcm_coarse_group=view._hcm_coarse_group or "map"
    local cfg=S.coarse_config(mod:get("native_configuration_v3"))
    ui:panel("native_intro_panel",105,220,1710,72)
    ui:text("native_intro",120,225,1675,60,mod:localize("native_coarse_intro"),22,"gold")
    ui:panel("native_groups",105,312,350,632)
    for i,group in ipairs(groups) do
        ui:button("native_group_"..group[1],120,328+(i-1)*66,320,52,text({en=group[2],cn=group[3]}),
            function() view._hcm_coarse_group=group[1] end,view._hcm_coarse_group==group[1])
    end
    ui:button("native_reset",120,858,320,54,mod:localize("native_reset_all"),function() mod:set("native_configuration_v3",S.coarse_config()) end)
    local n=0
    for _,d in ipairs(S.coarse) do
        if d.group==view._hcm_coarse_group then
            local y=312+n*142; n=n+1; local value=cfg[d.id]
            local function set(v) local current=S.coarse_config(mod:get("native_configuration_v3")); current[d.id]=S.normalize(v,d); mod:set("native_configuration_v3",current) end
            ui:panel("native_row_"..d.id,475,y,1340,128)
            ui:stepper("native_"..d.id,490,y+10,1080,text(d),string.format("%.4g×",value),function(direction) set(value+direction*d.step) end,
                S.text(d,lang,true),{label=text(d),value=value,min=d.min,max=d.max,set=set})
            ui:button("native_reset_"..d.id,1590,y+10,205,44,mod:localize("native_reset"),function() set(1) end)
            ui:text("native_hint_"..d.id,490,y+63,1300,56,S.text(d,lang,true),20,"muted")
        end
    end
end
