# Native spawning and condition audit (2.4.12)

This review uses public game Lua, native template fixtures and the actual DMF/SoloPlay loading paths. The test catalogue contains 64 configurations; availability in the game depends on its version. Passing offline loading and callback tests does not prove every engine effect on every map.

## Native mode

The director does not compile or run grouped generators, filter pools, replace capacity checks or take over specialist slots, bosses, rituals or map spawning. Grey values are saved advanced settings, not the live native values. HCM still applies selected native conditions and spawn multipliers. Saved mode changes apply next mission.

## Compatibility boundaries

- Shared mutator IDs initialize once, including an environment with hunting grounds plus the standalone hound condition.
- One map-compatible environment is selected. Tests cover 19 maps and 133 native mission constructions, with default fallback for unsupported themes.
- Rotten Armour and several events force Scabs; the Auric Dreg condition, broker_stimms and leftover force Dregs. Opposite forced factions cannot both apply. The last actual native write wins, and mixed factions do not bypass a forced faction.
- Native MinionSpawnManager.mutator_breed_init replaces its entire context. HCM retains this behavior: multiple replacement conditions are not necessarily a union of pools.
- Competing horde-template overrides and pacing fields follow native write order rather than creating additional independent generators.
- Pickup changes are added once, excluding the primary environment already applied by the native pickup system. Negative no-ammo weights clamp to zero. Health stations and barrel settings retain native override order. Loader tests and all five pickup tiers pass.
- Rotten Armour retains its travel reinforcement, effective-player minimum and cooldown gates. Rituals retain their native condition-spawner path.

## Performance

mutator_encroaching_garden applies havoc_encroaching_garden. The native Buff periodically queries nearby units using healing_frequency, applies healing Buffs and uses a head particle effect. No additional spawn generator is invented for it. More affected enemies can increase native query, healing and rendering work; this release does not change native Buff templates, IDs or healing frequency.

This release skips composition traversal for equal category speeds, avoids an extra specialist replacement lookup without quantity scaling, and avoids a per-frame result-table allocation when guaranteed faction switching is inactive. The director also stops copying advanced-only pacing metadata in native mode.

These are behavior-preserving Lua optimizations. No in-game A/B frame-rate measurement has been made, so recovering the previously reported approximately 30 FPS gap is not promised. Native caps still limit 5x quantity; capacity expansion belongs to advanced mode.

## Missing public implementations

Complete implementations for mutator_duplicating_enemies, mutator_armored_bombers, mutator_havoc_thorny_armor and the event mutator_gameplay_barren_odin are absent from this public Lua checkout. They are recorded separately rather than assigned invented generators or declared fully compatible. The per-condition field inventory is in the director release's checks/condition-native-audit.json.
