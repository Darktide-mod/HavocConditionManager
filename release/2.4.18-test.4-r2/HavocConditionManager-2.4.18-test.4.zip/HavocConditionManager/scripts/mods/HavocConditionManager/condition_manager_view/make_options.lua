local mod = get_mod("HavocConditionManager")
local base_mod = get_mod("SoloPlay")
local SoloPlaySettings = mod._condition_ui_settings
if not SoloPlaySettings then
	SoloPlaySettings = base_mod:io_dofile("SoloPlay/scripts/mods/SoloPlay/SoloPlaySettings")
	mod.extend_condition_settings(SoloPlaySettings)
end
local HavocConditions = mod:io_dofile("HavocConditionManager/scripts/mods/HavocConditionManager/havoc_conditions")

local make_options = {}

local function havoc_circumstance_display_name(circumstance_name)
	return SoloPlaySettings.loc.havoc_circumstances[circumstance_name] or SoloPlaySettings.loc.circumstances[circumstance_name]
end

make_options.normal_mission = function (current)
	local options = {}
	for _, mission_name in ipairs(SoloPlaySettings.order.missions) do
		local option = {
			ignore_localization = true,
			display_name = SoloPlaySettings.loc.missions[mission_name],
			id = mission_name,
			value = mission_name,
		}
		options[#options+1] = option
	end
	return options
end

make_options.normal_side_mission = function (current)
	local options = {
		{
			ignore_localization = true,
			display_name = base_mod:localize("default_text_none"),
			id = "default",
			value = "default",
		},
	}
	for _, side_mission_name in ipairs(SoloPlaySettings.order.side_missions) do
		local option = {
			ignore_localization = true,
			display_name = SoloPlaySettings.loc.side_missions[side_mission_name],
			id = side_mission_name,
			value = side_mission_name,
		}
		options[#options+1] = option
	end
	return options
end

make_options.normal_circumstance = function (current)
	local options = {
		{
			ignore_localization = true,
			display_name = base_mod:localize("default_text_none"),
			id = "default",
			value = "default",
		},
	}
	local allow_list = SoloPlaySettings.lookup.circumstances_of_missions[current.normal_mission]
	for _, circumstance_name in ipairs(SoloPlaySettings.order.circumstances) do
		if not allow_list or allow_list[circumstance_name] then
			local option = {
				ignore_localization = true,
				display_name = SoloPlaySettings.loc.circumstances[circumstance_name],
				id = circumstance_name,
				value = circumstance_name,
			}
			options[#options+1] = option
		end
	end
	return options
end

make_options.normal_mission_giver = function (current)
	local options = {
		{
			ignore_localization = true,
			display_name = base_mod:localize("default_text"),
			id = "default",
			value = "default",
		},
	}
	local allow_list = SoloPlaySettings.lookup.mission_givers_of_missions[current.normal_mission]
	for _, mission_giver_name in ipairs(SoloPlaySettings.order.mission_givers) do
		if not allow_list or allow_list[mission_giver_name] then
			local option = {
				ignore_localization = true,
				display_name = SoloPlaySettings.loc.mission_givers[mission_giver_name],
				id = mission_giver_name,
				value = mission_giver_name,
			}
			options[#options+1] = option
		end
	end
	return options
end

make_options.havoc_mission = function (current)
	local options = {}
	for _, mission_name in ipairs(SoloPlaySettings.order.havoc_missions) do
		local option = {
			ignore_localization = true,
			display_name = SoloPlaySettings.loc.missions[mission_name],
			id = mission_name,
			value = mission_name,
		}
		options[#options+1] = option
	end
	return options
end

make_options.havoc_faction = function (current)
	local options = {}
	for _, faction_name in ipairs(SoloPlaySettings.order.havoc_factions) do
		local option = {
			ignore_localization = true,
			display_name = base_mod:localize("havoc_faction_" .. faction_name),
			id = faction_name,
			value = faction_name,
		}
		options[#options+1] = option
	end
	return options
end

make_options.havoc_mission_giver = function (current)
	local options = {
		{
			ignore_localization = true,
			display_name = base_mod:localize("default_text"),
			id = "default",
			value = "default",
		},
	}
	local allow_list = SoloPlaySettings.lookup.mission_givers_of_missions[current.havoc_mission]
	for _, mission_giver_name in ipairs(SoloPlaySettings.order.mission_givers) do
		if not allow_list or allow_list[mission_giver_name] then
			local option = {
				ignore_localization = true,
				display_name = SoloPlaySettings.loc.mission_givers[mission_giver_name],
				id = mission_giver_name,
				value = mission_giver_name,
			}
			options[#options+1] = option
		end
	end
	return options
end

local function action_placeholder(localization_key)
	return {
		ignore_localization = true,
		display_name = mod:localize(localization_key),
		id = "default",
		value = "default",
	}
end

make_options.havoc_add_circumstance = function (current)
	local options = {
		action_placeholder("default_text_select_to_add"),
	}
	local selected = current.havoc_circumstances or {}

	if #selected >= HavocConditions.max_primary then
		return options
	end

	for _, circumstance_name in ipairs(SoloPlaySettings.order.havoc_circumstances) do
		if not HavocConditions.contains(selected, circumstance_name) then
			options[#options + 1] = {
				ignore_localization = true,
				display_name = havoc_circumstance_display_name(circumstance_name),
				id = circumstance_name,
				value = circumstance_name,
			}
		end
	end

	return options
end

make_options.havoc_remove_circumstance = function (current)
	local options = {
		action_placeholder("default_text_select_to_remove"),
	}
	local selected = current.havoc_circumstances or {}

	if #selected < 1 then
		return options
	end

	for _, circumstance_name in ipairs(selected) do
		options[#options + 1] = {
			ignore_localization = true,
			display_name = havoc_circumstance_display_name(circumstance_name),
			id = circumstance_name,
			value = circumstance_name,
		}
	end

	return options
end

make_options.havoc_theme_circumstance = function (current)
	local options = {
		{
			ignore_localization = true,
			display_name = base_mod:localize("default_text_none"),
			id = "default",
			value = "default",
		},
	}
	for _, circumstance_name in ipairs(SoloPlaySettings.order.havoc_theme_circumstances) do
		if mod.condition_catalog.environment_available(SoloPlaySettings,current.havoc_mission,circumstance_name) then
			local option = {
				ignore_localization = true,
				display_name = havoc_circumstance_display_name(circumstance_name),
				id = circumstance_name,
				value = circumstance_name,
			}
			options[#options+1] = option
		end
	end
	return options
end

make_options.havoc_difficulty_circumstance = function (current)
	local options = {
		{
			ignore_localization = true,
			display_name = base_mod:localize("default_text_none"),
			id = "default",
			value = "default",
		},
	}
	for _, circumstance_name in ipairs(SoloPlaySettings.order.havoc_difficulty_circumstances) do
		local option = {
			ignore_localization = true,
			display_name = havoc_circumstance_display_name(circumstance_name),
			id = circumstance_name,
			value = circumstance_name,
		}
		options[#options+1] = option
	end
	return options
end

return make_options
