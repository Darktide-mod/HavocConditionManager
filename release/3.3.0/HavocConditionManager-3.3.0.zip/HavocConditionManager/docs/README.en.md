# Havoc Condition Manager

Choose SoloPlay mission conditions and adjust enemy pacing. HCM provides broad controls; the optional Havoc Enemy Director edits individual fields in the same game templates. Realms sessions use the local host's settings.

## Conditions and mission setup

- Import the current SoloPlay condition list and group eligible entries as Havoc, Auric/Maelstrom, events and general conditions.
- Add or remove conditions without a fixed slot count. A shared native mutator loads once even when several selected conditions include it.
- Choose mission, faction, difficulty and environment in the mission page. An unsupported map/environment pair falls back to Default.
- Apply the selected native pickup, health-station and hazard settings. Native replacement rules still govern conflicting effects.

Available entries depend on the installed game and SoloPlay. HCM supplies no separate Havoc or Maelstrom condition definitions.

## Overall tuning

Open HCM in Mod Options and select Overall tuning. The main page shows the intensity slider and linked values. The 18 individual controls are folded into Advanced settings; hover titles for details.

Levels 1–10 link elite patrols, map monster encounters, specialist capacity and replenishment. Level 1 uses baseline values. A level is a coordinated preset, not a measured multiplier for enemy count or difficulty.

- Level 5: patrol and map monster counts each 3×; specialist capacity and replenishment each 2×.
- Level 10: patrol count 6×, map monster count 5×, specialist capacity 3×, replenishment 3.25× and surge allowance 6×.

Higher patrol and monster settings use unused authored encounter points to supplement the native plan. Several encounters can share a map section at separated positions, so increasing monsters no longer consumes every section before patrols can be planned. More encounters along the same route also shorten travel between fights. Available positions still limit the final plan; missing positions are reported. Native spawn methods, patrol formations and mission objectives remain in use. Heat-based encounter templates scale their patrol/monster allowances and shared timer as well.

Specialist capacity also scales same-breed limits, coordinated attack size and finite disabler allowances based on eligible players. Replenishment also shortens slot spacing and coordinated attack/surge refill intervals. Native breed selection, protection duration, trigger chance, rush/loner checks and spawn-position checks still apply.

Ordinary hordes remain a supporting part of the profile. Level 10 uses 1.35× wave size, 6× waves and 2.25× frequency, including ordinary wave gaps. Route population and event budgets are 1.35×. Combat capacity is 3×: the overall living-plus-queued admission threshold rises from 145 to 435; the difficulty-5 horde threshold rises from 95 to 285. Mission pauses and tension/heat stages still apply. Trickle size, condition encounter counts, escalation and independent scripted-event limits retain their own settings.

Selecting a level replaces all 18 HCM values. Individual edits appear as Custom; HED field overrides remain. Upgrades preserve saved values, so select a level again to apply the revised profile. Changes save automatically and apply next mission.

Due spawners run across successive updates while retaining their queues, order and completion callbacks. Ordinary and coordinated hordes defer their next wave while the central queue is congested. Temporary pacing refusals preserve unspawned map encounters. Repeated Buff-capacity warnings are summarized by count; the Buff event pool remains 300.

## Fine editing and saved settings

Havoc Enemy Director adds Detailed tuning. HCM first supplies broad changes; a HED field override then sets that field's exact value. Native difficulty and condition modifiers can still change the final result. Mission combat-node budgets are a specific case: HCM's event-budget multiplier scales the final budget and its native cap after the node's base values and native modifiers.

Values save automatically and apply when the next mission starts. A running mission retains its starting configuration. DMF switches apply immediately in the hub and are deferred during a mission. Disabling HCM restores SoloPlay's menu and suspends HED for later missions.

The first use imports valid native IDs from the previous HCM selection. Retired condition aliases are omitted; the original saved value is retained. Old category multipliers and custom-generator settings are not converted into native template edits. Start from the new defaults and configure the controls before your next mission.

English, Simplified Chinese and Traditional Chinese follow the game language. Native identifiers remain visible where needed to distinguish exact templates.

## Requirements

Darktide Mod Loader, Darktide Mod Framework and SoloPlay are required. Realms is optional for co-op. Havoc Enemy Director is optional. Other mods replacing the same native templates or scheduling methods may conflict.

## Vortex installation

- Close the game and install the requirements. Import this ZIP with Install From File, enable it and select Deploy Mods.
- Enable HavocConditionManager in Load Order after SoloPlay. Place the optional HavocEnemyDirector after HavocConditionManager.
- Restart the game and open Havoc Condition Manager in Mod Options.

## Manual installation

- Close the game. When upgrading, remove the previous HavocConditionManager installation folder before extracting the new ZIP; saved settings are stored separately.
- Extract the ZIP into Darktide/mods, producing mods/HavocConditionManager.
- Add HavocConditionManager on its own line after SoloPlay in mods/mod_load_order.txt. Place the optional HavocEnemyDirector after it.
- Restart the game and open HCM in Mod Options.

## Credits

SoloPlay and the original UI foundation: deluxghost. Native game systems and assets: Fatshark. Game-source reference: Aussiemon/Darktide-Source-Code.
