-- Strength is a coordinated profile, not a second multiplier at runtime.
local S=get_mod("HavocConditionManager").template_schema
local P={min=1,max=10,step=1}
-- Values at strength 1, 5 and 10. Unlisted controls stay at the baseline.
P.anchors={
    roamer_population={1,1.15,1.35},
    encampments={1,1.5,2},
    patrols={1,3,6},
    horde_size={1,1.15,1.35},
    horde_frequency={1,1.6,2.25},
    horde_waves={1,3,6},
    coordinated_allowance={1,3,6},
    trickle_frequency={1,1.5,2},
    special_slots={1,2,3},
    special_frequency={1,2,3.25},
    special_surges={1,3,6},
    monster_encounters={1,3,5},
    event_budget={1,1.15,1.35},
    combat_tolerance={1,1.75,3},
    recovery_duration={1,0.8,0.6},
}
local profiles={}
for level=1,10 do
    local values={}
    local segment=level<=5 and 1 or 2
    local alpha=level<=5 and (level-1)/4 or (level-5)/5
    for id,points in pairs(P.anchors) do
        values[id]=math.floor((points[segment]+(points[segment+1]-points[segment])*alpha)*100+0.5)/100
    end
    profiles[level]=S.coarse_config(values)
end
function P.values(level)
    if not S.finite(level) or level%1~=0 or not profiles[level] then return nil end
    return S.copy(profiles[level])
end
function P.match(values)
    for level=1,10 do
        local same=true
        for _,d in ipairs(S.coarse) do if math.abs(values[d.id]-profiles[level][d.id])>0.000001 then same=false;break end end
        if same then return level end
    end
end
return P
