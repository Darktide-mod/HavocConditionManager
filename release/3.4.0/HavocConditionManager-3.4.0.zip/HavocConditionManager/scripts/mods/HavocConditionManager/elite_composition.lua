-- Rebalance existing native troops without adding actors or new breed types.
local M={}
local function role(breeds,name)
    local breed=breeds and breeds[name]
    if not breed then return end
    local tags=breed.tags or {}
    if tags.monster or tags.captain or tags.special then return end
    return tags.elite and "elite" or "common"
end
M.role=role
function M.tagged_elite(tags)
    if type(tags)~="table" then return false end
    if tags.elite then return true end
    if #tags==0 then return false end
    for _,clause in ipairs(tags) do
        local elite=false
        for _,tag in ipairs(clause) do if tag=="elite" then elite=true end end
        if not elite then return false end
    end
    return true
end
function M.fraction(list,breeds)
    local count,total=0,0
    for _,name in ipairs(list or {}) do
        local kind=role(breeds,name)
        if kind then total=total+1;if kind=="elite" then count=count+1 end end
    end
    return total>0 and count/total or 0
end
function M.list(value,bias,breeds)
    if bias==1 then return value end
    local elites,commons={},{}
    for i,name in ipairs(value) do
        local kind=role(breeds,name)
        local group=kind=="elite" and elites or kind=="common" and commons
        if group then group[#group+1]=i end
    end
    local ne,nc=#elites,#commons
    if ne==0 or nc==0 then return value end
    local wanted=math.floor((ne+nc)*ne*bias/(ne*bias+nc)+0.5)
    local delta=wanted-ne
    if delta==0 then return value end
    local from,to=delta>0 and commons or elites,delta>0 and elites or commons
    local result={};for i,name in ipairs(value) do result[i]=name end
    local n,used=math.abs(delta),0
    for i,index in ipairs(from) do
        if math.floor(i*n/#from)>math.floor((i-1)*n/#from) then
            result[index]=value[to[used%#to+1]];used=used+1
        end
    end
    return result
end
local function distribute(weights,total,caps)
    local result,sum,weight_sum={},0,0
    for _,weight in ipairs(weights) do weight_sum=weight_sum+weight end
    if weight_sum==0 then return caps end
    local fractions={}
    for i,weight in ipairs(weights) do
        local ideal=total*weight/weight_sum
        result[i]=math.min(caps and caps[i] or total,math.floor(ideal))
        fractions[i]=ideal-result[i];sum=sum+result[i]
    end
    while sum<total do
        local best
        for i in ipairs(weights) do
            if (not caps or result[i]<caps[i]) and (not best or fractions[i]>fractions[best]) then best=i end
        end
        if not best then break end
        result[best]=result[best]+1;fractions[best]=fractions[best]-1;sum=sum+1
    end
    return result
end
function M.amounts(value,bias,breeds,copy)
    if bias==1 then return value end
    local indices,minimum,maximum,weights_min,weights_max={},0,0,{},{}
    local has_elite,has_common=false,false
    for i,entry in ipairs(value) do
        local kind=role(breeds,entry.name)
        if kind then
            indices[#indices+1]=i
            local factor=kind=="elite" and bias or 1
            minimum=minimum+entry.amount[1];maximum=maximum+entry.amount[2]
            weights_min[#indices]=entry.amount[1]*factor;weights_max[#indices]=entry.amount[2]*factor
            if entry.amount[2]>0 then
                has_elite=has_elite or kind=="elite";has_common=has_common or kind=="common"
            end
        end
    end
    if not has_elite or not has_common then return value end
    local upper=distribute(weights_max,maximum)
    local lower=minimum>0 and distribute(weights_min,minimum,upper) or {}
    local result=copy(value)
    for i,index in ipairs(indices) do result[index].amount={lower[i] or 0,upper[i]} end
    return result
end
return M
