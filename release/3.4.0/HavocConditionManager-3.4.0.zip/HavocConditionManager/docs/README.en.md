# Havoc Condition Manager

Choose SoloPlay mission conditions and adjust enemy pacing. HCM provides broad controls; the optional Havoc Enemy Director edits individual fields in the same game templates. Realms sessions use the local host's settings.

## Conditions and mission setup

- Import the current SoloPlay condition list and group eligible entries as Havoc, Auric/Maelstrom, events and general conditions.
- Add or remove conditions without a fixed slot count. A shared native mutator loads once even when several selected conditions include it.
- Choose mission, faction, difficulty and environment in the mission page. An unsupported map/environment pair falls back to Default.
- Apply the selected native pickup, health-station and hazard settings. Native replacement rules still govern conflicting effects.

Available entries depend on the installed game and SoloPlay. HCM supplies no separate Havoc or Maelstrom condition definitions.

## Overall tuning

Open HCM in Mod Options and select Overall tuning. The main page shows the intensity slider and linked values. The 19 individual controls are folded into Advanced settings; hover titles for details.

Levels 1–10 put more emphasis on elites, specialists and map monsters while reducing ordinary troop volume. Level 1 uses baseline values. A level is a coordinated preset, not a measured multiplier for enemy count or difficulty.

- Level 5: elite composition bias 1.75×, patrol count 3×, map monster count 4×; specialist capacity and replenishment each 2×.
- Level 10: elite composition bias 3×, patrol count 6×, map monster count 8×, specialist capacity 3×, replenishment 3.25× and surge allowance 6×.

Elite composition bias shifts existing mixed patrols, roamer groups and horde compositions toward their existing elite breeds. It preserves group size, or the adjusted wave size for hordes. For example, a 16-member patrol with 8 elites becomes 12 elites and 4 ordinary troops at 3× bias. Roamer pack weights and relevant elite limits also increase. Automatic combat events favor existing elite pools within their point budget. Pure ordinary groups retain their breeds; specialists, bosses and required objective characters use separate settings.

Patrol and monster settings first use separated, unused authored encounter points. If those cannot fit the requested count, the remaining allowance is retained for later encounters at valid hidden navigation positions. Additional encounters are at least 20 seconds apart, subject to native pacing and spawn checks. Supplemental bosses wait while three ordinary map monsters are alive, and at most two supplemental patrol groups remain active. These checks govern supplemental admissions; they do not cap mission-scripted bosses or all patrols. Short missions, combat pauses or missing positions can leave allowance unused. Native spawning, formations and mission objectives remain in use.

Specialist capacity also scales same-breed limits, coordinated attack size and finite disabler allowances based on eligible players. Replenishment shortens slot spacing and coordinated attack/surge refill intervals. Native breed selection, protection duration, trigger chance, rush/loner checks and spawn-position checks still apply.

Level 10 uses 0.65× horde and trickle wave size, 2× ordinary horde waves, 1.35× horde frequency and 3× coordinated tactic allowance. Trickle frequency, encampment count and event budget stay at 1×; route population is 0.85×. Combat capacity is 2×: the overall living-plus-queued admission threshold becomes 290 and the difficulty-5 horde threshold becomes 190. Recovery duration is 0.7×. Mission pauses, tension/heat stages, condition encounter counts, escalation and independent scripted-event limits retain their rules.

Selecting a level replaces all 19 HCM values. Individual edits appear as Custom; HED field overrides remain. Upgrades preserve saved values, so select a level again to apply the revised profile. Changes save automatically and apply next mission.

Due spawners run across successive updates while retaining queues, order and completion callbacks. Ordinary and coordinated hordes defer their next wave while the central queue is congested. Temporary pacing refusals preserve unspawned map encounters. Repeated Buff-capacity warnings are summarized by count; the Buff event pool remains 300.

## Fine editing and saved settings

Havoc Enemy Director adds Detailed tuning. HCM first supplies broad changes; a HED field override then sets that field's exact value. Native difficulty and condition modifiers can still change the final result. Mission combat-node budgets are a specific case: HCM's event-budget multiplier scales the final budget and its native cap after the node's base values and native modifiers.

Values save automatically and apply when the next mission starts. A running mission retains its starting configuration. DMF switches apply immediately in the hub and are deferred during a mission. Disabling HCM restores SoloPlay's menu and suspends HED for later missions.

The first use imports valid native IDs from the previous HCM selection. Retired condition aliases are omitted; the original saved value is retained. Old category multipliers and custom-generator settings are not converted into native template edits. Start from the new defaults and configure the controls before your next mission.

English, Simplified Chinese and Traditional Chinese follow the game language. Native identifiers remain visible where needed to distinguish exact templates.

## Requirements

Darktide Mod Loader, Darktide Mod Framework and SoloPlay are required. Realms is optional for co-op. Havoc Enemy Director is optional. Other mods replacing the same native templates or scheduling methods may conflict.

## Vortex installation

- Close the game and install the requirements. Import this ZIP with Install From File, enable it and select Deploy Mods.
- Enable HavocConditionManager in Load Order after SoloPlay. Place the optional HavocEnemyDirector after HavocConditionManager.
- Restart the game and open Havoc Condition Manager in Mod Options.

## Manual installation

- Close the game. When upgrading, remove the previous HavocConditionManager installation folder before extracting the new ZIP; saved settings are stored separately.
- Extract the ZIP into Darktide/mods, producing mods/HavocConditionManager.
- Add HavocConditionManager on its own line after SoloPlay in mods/mod_load_order.txt. Place the optional HavocEnemyDirector after it.
- Restart the game and open HCM in Mod Options.

## Credits

SoloPlay and the original UI foundation: deluxghost. Native game systems and assets: Fatshark. Game-source reference: Aussiemon/Darktide-Source-Code.
