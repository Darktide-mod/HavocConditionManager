# DIY verification and acceptance scope

Release candidates: MortisBuffManager 4.1.0, HavocConditionManager 4.0.2, HavocEnemyDirector 3.1.0. Native source: game Lua 1.12.5, commit 0f0cb45991e9305ef4a7b925370792d7d6035f95. These are offline checks, not a recorded game session.

| Area | Verification performed |
| --- | --- |
| JSON and schema | Malformed input, UTF-8, unknown fields, size/depth limits, stat kinds, event fields and all 46 starter entries. Invalid imports preserve prior valid data. |
| Runtime | Selection quotas/exclusivity, owner isolation, selector scope, temporary stacking/expiry, cooldown, delayed-action cancellation, removal/reselection, bounded queues and signals. |
| Native boundary | Original native buff reset/stat/proc methods, original health/toughness methods and complete ammo/stamina/warp-charge/overheat utility files. Engine unit services, attack execution, pickup creation and buff index allocation use fixtures. |
| Native inheritance | The actual class utility and DMF hooks execute against preloaded concrete player/minion classes. Both DIY mods apply once; minion proc overrides do not double-dispatch. Native idle request gating, activation scan, new enemy initialization, last-native-buff removal and final-owner restoration are exercised. |
| Lifecycle | Actual Mortis/HCM modules freeze mission snapshots, check library signatures and character choices, handle death/respawn, ownership loss, disable, exit, new missions and client authority. Native world services are fixtures. |
| Realms protocol | Host identity, membership, session nonce, character, monotone sequence, invalid/stale messages, three-second lease expiry, rate limits, shutdown and sequence retention across reload. Transport is simulated. |
| Files | Actual Windows Unicode paths and FFI file operations in isolated temporary application-data folders, atomic replacement, overwrite/path rejection and removal. |
| UI | Actual widget callbacks, import errors, mission locks, selection caps, pagination and stale callbacks; native private view structure; English, Simplified Chinese and Traditional Chinese layout bounds. Rendered previews are not gameplay screenshots. |
| HED | External request bounds, pending/admission pauses, expiry, shutdown, active-affix/signal predicates and existing native creation adapters; all existing director regression checks. |
| Existing behavior | The three projects' existing regression suites and source syntax/import checks. |

Live acceptance remains required for four-player prediction and latency, special keyword resources, interactions with other installed mods, actual rendering/input at the user's resolution and dense-encounter frame time. The existence of an identifier in the native catalog does not mean every weapon, class or damage path consumes it.

The source workspace includes six new DIY suites in development/diy-framework and each project's existing tests/run.py. Release validation additionally checks archive contents against source bytes, one-mod folder structure, the four required release files and the Vortex installer contract. It does not install or upload the mods.

Additional eligibility checks cover 128 native selector combinations, 132 actual ability combinations, 1000 seeds, host rejection, pending builds, stale cards and basic-box adapter ownership. See the [eligibility audit](ELIGIBILITY-AUDIT.en.md).

Additional offline checks execute native staff scheduling, spawning, cost and interruption, native explosion start and flame stack limits; generic ranged hooks and shotgun primitives use simulated damage boundaries. The actual mixed pool is sampled 25,000 times, and the shared selector 30,000 times. Tests cover native-first / DIY-only openings, all four switches, dynamic total/tier/exclusive limits, room manifests, named missing definitions, atomic batches, direct search/numeric input and paginated three-language UI layouts. These do not establish live rendering, multiplayer prediction or dense-scene performance.
