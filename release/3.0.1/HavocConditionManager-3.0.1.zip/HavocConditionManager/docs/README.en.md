# Havoc Condition Manager

Choose SoloPlay mission conditions and adjust enemy pacing. HCM provides broad controls; the optional Havoc Enemy Director edits individual fields in the same game templates. Realms sessions use the local host's settings.

## Conditions and mission setup

- Import the current SoloPlay condition list and group eligible entries as Havoc, Auric/Maelstrom, events and general conditions.
- Add or remove conditions without a fixed slot count. A shared native mutator loads once even when several selected conditions include it.
- Choose mission, faction, difficulty and environment in the mission page. An unsupported map/environment pair falls back to Default.
- Apply the selected native pickup, health-station and hazard settings. Native replacement rules still govern conflicting effects.

Available entries depend on the installed game and SoloPlay. HCM supplies no separate Havoc or Maelstrom condition definitions.

## Overall tuning

**Open HCM in Mod Options and select Overall tuning. Drag a slider or click its value to type. Hover a control title for an explanation of its purpose, effect and limits.**

The Overall intensity slider sets all 18 multipliers to the same value, up to 10×. Individual controls also support 10×. When individual values differ, it displays Custom; using the overall slider replaces those values. Setting it to 1× returns all HCM multipliers to their defaults. Precise HED field edits are retained.

The controls are arranged in six groups:

- Map population: route enemy count, encampments and elite patrols.
- Horde encounters: enemies per wave, encounter frequency, waves and coordinated tactic allowance.
- Trickle waves: enemies per group and encounter frequency.
- Specialists: base scheduling slots, replenishment frequency and coordinated surge allowance.
- Monsters and events: map monster encounters, combat-event budgets and condition-specific encounter counts.
- Combat pacing: combat load tolerance, recovery duration and escalation strength.

Higher frequency shortens waiting or travel requirements. Recovery duration works differently: raising it extends the recovery end timer, and recovery may still end earlier when tension falls. Overall intensity includes this setting. Hover explanations describe the relevant game mechanisms without requiring knowledge of template fields.

Multipliers adjust existing enemy sources. A source with no encounter allowance remains at zero. The game still chooses spawn positions and applies its scheduling and group limits, so the final enemy count may rise by less than the selected multiplier. The numeric input shows each control's allowed range.

## Fine editing and saved settings

Havoc Enemy Director adds Detailed tuning. HCM first supplies broad changes; a HED field override then sets that field's exact value. Native difficulty and condition modifiers can still change the final result. Mission combat-node budgets are a specific case: HCM's event-budget multiplier scales the final budget and its native cap after the node's base values and native modifiers.

Values save automatically and apply when the next mission starts. A running mission retains its starting configuration. DMF switches apply immediately in the hub and are deferred during a mission. Disabling HCM restores SoloPlay's menu and suspends HED for later missions.

The first use imports valid native IDs from the previous HCM selection. Retired condition aliases are omitted; the original saved value is retained. Old category multipliers and custom-generator settings are not converted into native template edits. Start from the new defaults and configure the controls before your next mission.

English, Simplified Chinese and Traditional Chinese follow the game language. Native identifiers remain visible where needed to distinguish exact templates.

## Requirements

Darktide Mod Loader, Darktide Mod Framework and SoloPlay are required. Realms is optional for co-op. Havoc Enemy Director is optional. Other mods replacing the same native templates or scheduling methods may conflict.

## Vortex installation

- Close the game and install the requirements. Import this ZIP with Install From File, enable it and select Deploy Mods.
- Enable HavocConditionManager in Load Order after SoloPlay. Place the optional HavocEnemyDirector after HavocConditionManager.
- Restart the game and open Havoc Condition Manager in Mod Options.

## Manual installation

- Close the game. When upgrading, remove the previous HavocConditionManager installation folder before extracting the new ZIP; saved settings are stored separately.
- Extract the ZIP into Darktide/mods, producing mods/HavocConditionManager.
- Add HavocConditionManager on its own line after SoloPlay in mods/mod_load_order.txt. Place the optional HavocEnemyDirector after it.
- Restart the game and open HCM in Mod Options.

## Credits

SoloPlay and the original UI foundation: deluxghost. Native game systems and assets: Fatshark. Game-source reference: Aussiemon/Darktide-Source-Code.
