# Havoc Condition Manager

Choose SoloPlay mission conditions and adjust enemy pacing. HCM provides broad controls; the optional Havoc Enemy Director edits individual fields in the same game templates. Realms sessions use the local host's settings.

## Conditions and mission setup

- Import the current SoloPlay condition list and group eligible entries as Havoc, Auric/Maelstrom, events and general conditions.
- Add or remove conditions without a fixed slot count. A shared native mutator loads once even when several selected conditions include it.
- Choose mission, faction, difficulty and environment in the mission page. An unsupported map/environment pair falls back to Default.
- Apply the selected native pickup, health-station and hazard settings. Native replacement rules still govern conflicting effects.

Available entries depend on the installed game and SoloPlay. HCM supplies no separate Havoc or Maelstrom condition definitions.

## Overall tuning

Open HCM in Mod Options and select Overall tuning. The main page shows the intensity slider and linked values. The 20 individual controls are in Advanced settings; hover titles for details.

Level 1 preserves the native spawn configuration for the selected mission, difficulty and conditions when HED overrides are also at baseline. Levels 2–10 increase ordinary enemies gradually and increase elite, specialist and monster pressure more strongly. Intermediate levels interpolate between the following anchors; integer allowances may remain equal across adjacent levels. A level describes a preset, not a measured difficulty or kill-count multiplier.

- Route population: 1× / 1.2× / 1.5× at levels 1 / 5 / 10. Camp count and event budget: 1× / 1.1× / 1.25×.
- Ordinary enemies per horde or trickle wave: 1× / 1.1× / 1.25×. Horde frequency: 1× / 1.08× / 1.2×; trickle frequency: 1× / 1.05× / 1.1×. Ordinary horde wave counts stay native.
- Existing elite members in horde compositions and patrol teams: 1× / 1.75× / 3×. Ordinary members keep their separate counts. A patrol with 8 elites and 8 ordinary troops requests 24 elites and 8 ordinary troops at 3× elite members. Roamer packs and point-budget events keep native selection ratios and grow through population and budget.
- Specialist capacity: 1× / 2× / 3×; refill frequency: 1× / 2× / 3.25×; surge allowance: 1× / 3× / 6×. Capacity and frequency together represent nominal scheduling capacity, subject to native pauses, player-dependent limits and spawn checks.
- Map monster encounter allowance: 1× / 4× / 8×. Elite patrol encounter allowance: 1× / 3× / 6×. These counts are separate from patrol team size.
- Coordinated tactic allowance: 1× / 2× / 3×. Supported tactics' upper combat-load limit rises from 35 to 70 to 105. The medium-load lower bound stays at 8; capable-player, pacing-stage and other native conditions still apply. HED can append requirements to the adjusted conditions or explicitly replace them.
- General combat capacity: 1× / 1.5× / 2×; recovery duration: 1× / 0.85× / 0.7×. At level 10, the living-plus-queued admission threshold is 290 and the difficulty-5 horde threshold is 190. Condition encounter counts, escalation, mission objectives and separate scripted-event limits retain their settings.

Patrols and monsters first use unused authored encounter points. Overflow waits for valid hidden navigation positions. Both queues share a minimum 20-second interval and receive turns weighted by their starting overflow quotas. A ready queue gets a turn after at most three successful admissions of the other queue. If one class is blocked or fails to spawn, the other may try; only successful spawns consume allowance. Supplemental bosses wait while three ordinary map monsters are alive, and at most two supplemental patrol groups remain active. Native pauses, positions and mission length can still leave allowance unused.

Route and supplemental elite patrols create one member at a time, at least 0.15 seconds apart, while retaining native breeds, group sounds and unit initialization. Route patrols use native formation links and a main-path walking destination. Supplemental patrols spawn with a current combat target and native combat behavior. Every final member position must be hidden from the current valid team, at least 35 metres from each teammate including bots, and 30–120 metres ahead along the main path. Unavailable positions delay the remaining members. Supplemental encounters wait until the native safe-zone restriction ends, then start their 20-second interval; a patrol consumes its encounter allowance only after all members are created.

Supplemental encounters and recycled enemies prefer an existing hidden spawn region around 60 metres ahead of the leading player. Searches use the actual native spawn-group count and a bounded local region. The final distance and visibility checks also apply to positions expanded from a patrol anchor, so a hidden anchor alone is insufficient. These checks reuse native route queries, navigation placement and the horde visibility helper.

Route and supplemental patrols, ordinary trickle hordes and recycled reinforcements also check the navigation route from the spawn area to the player's current position, rejecting long detours. Ordinary hordes in the central queue retain nearby rear attacks. Distant, exposed or unsuitable positions are retried at hidden forward points without losing requested units. A blocked request lets later requests proceed.

Mission-door selection prefers nearby reachable exits within the same authored encounter. The Courtroom ascender event can choose among its three existing door groups while retaining native composition, queues and completion accounting. If no suitable route is approved after 10 seconds, the wave uses its original door pool and logs the fallback so the event cannot wait indefinitely; native distant spawns remain possible in this case. Nodes assigned a required mission objective retain native handling.

Selecting a level replaces all 20 HCM values; individual edits show Custom. Exact saved presets from the previous curve migrate to the same level on the new curve. Other custom values and HED overrides remain. Changes save automatically and apply next mission.

Due spawners run across successive updates while retaining queues, order and completion callbacks. Ordinary and coordinated hordes defer their next wave while the central queue is congested. Temporary pacing refusals preserve unspawned map encounters. Repeated Buff-capacity warnings are summarized; the Buff event pool remains 300.

HCM-hosted missions at every intensity level record a final count of successfully created common enemies, elites, specialists, monsters and other units. This is a spawn receipt, not a kill counter. Blocked coordinated selections can record actual engaged counts and load by category at most once per 30 seconds, capped at 120 snapshots per mission. Encounter overflow reports successful admissions and final unused allowance with blocking reasons. These bounded records use the game log.

Known pacing patrol followers that lose their leader can rejoin native combat once, with recoveries spaced at least 0.15 seconds apart. This uses the existing perception updates and native alert/aggro methods. Mission ownership, player-owned units and traversal protections still apply, and a patrol being recycled is not woken by its own staged removal.

## Automatic rear-enemy recycling

Recycling is active at every intensity level while HCM runs on the local mission host, with no separate switch. Level 1 keeps native spawn multipliers and includes this behavior.

Known pacing common enemies and elites can qualify after at least 30 seconds without engagement or effective approach, at least 35 metres from every living teammate including bots and at least 60 metres behind the entire team along the main path. A retained distant target, persistent modifier, old injury or previous enhancement alone no longer prevents recycling. Enemies steadily reducing their player distance or remaining route stay protected, including slow pursuers. Unknown route information retains the enemy; crossing a step or checkpoint alone never triggers removal.

Sources include known native roamers, pacing patrols, ordinary trickle groups and ordinary central-queue hordes carrying origin records. All living patrol members must qualify; groups above 64 members and locked or externally controlled groups are excluded. Native corpses neither block survivors nor provide allowance. Staged retirement stops if a remaining member engages, becomes visible or protected, or the team returns. Recent damage, active combat effects, marks, actual invulnerability and traversal remain protected. Specialists, bosses, captains, companions, player-owned and mission-owned units are excluded. Each unit also passes a final native visibility check before removal.

Recycling uses native removal and recreation, retaining breeds and the removed patrol members' counts and group membership. Health is initialized again and random modifiers can be rerolled; old state is not migrated. Non-death retirement of rotten-armour units suppresses only their death liquid, sound and visual payload. Normal kills and other buff cleanup retain native behavior.

Only actually removed originals provide replacement allowance. They return when native pacing, capacity and suitable hidden forward positions permit. Interrupted patrols transfer only members already removed. Each original can transfer once; recycling a replacement creates no further allowance. Allowance is limited to 24 records and 96 units, expires after 180 seconds and may remain unused at mission end. Separate transfers are at least 8 seconds apart; patrol members enter the native queue individually at least 0.15 seconds apart. Current team positions, visibility and routes are checked again at consumption; rejected requests retain their allowance.

Candidate observation reuses native perception updates. Detailed checks are limited to four per second and removal to one unit per second, with one patrol processed at a time and at least 20 seconds between patrol starts. Spawn-route checks share one asynchronous navigation probe, start at most four searches per second and retain at most 24 waiting requests, briefly reusing results within a local area. The probe creates no enemy entity and adds no whole-map enemy scan.

Game-log receipts distinguish removals, allowance, queued/cancelled requests, actual creation, unused allowance and queries. Bounded spawn-batch records include origin, event door group, actual first position, target position, route length and fallback status. Patrol completion records are capped at 64 per mission. Eligibility records summarize changes in refusal reasons, and the first eight removals and orphan recoveries are logged. Observation counts are not a live population count.

## Fine editing and saved settings

Havoc Enemy Director adds Detailed tuning. HCM first supplies broad changes; a HED field override then sets that field's exact value. Native difficulty and condition modifiers can still change the final result. Mission combat-node budgets are a specific case: HCM's event-budget multiplier scales the final budget and its native cap after the node's base values and native modifiers.

Values save automatically and apply when the next mission starts. A running mission retains its starting configuration. DMF switches apply immediately in the hub and are deferred during a mission. Disabling HCM restores SoloPlay's menu and suspends HED for later missions.

The first use imports valid native IDs from the previous HCM selection. Retired condition aliases are omitted; the original saved value is retained. Old category multipliers and custom-generator settings are not converted into native template edits. Start from the new defaults and configure the controls before your next mission.

English, Simplified Chinese and Traditional Chinese follow the game language. Native identifiers remain visible where needed to distinguish exact templates.

## Requirements

Darktide Mod Loader, Darktide Mod Framework and SoloPlay are required. Realms is optional for co-op. Havoc Enemy Director is optional. Other mods replacing the same native templates or scheduling methods may conflict.

## Vortex installation

- Close the game and install the requirements. Import this ZIP with Install From File, enable it and select Deploy Mods.
- Enable HavocConditionManager in Load Order after SoloPlay. Place the optional HavocEnemyDirector after HavocConditionManager.
- Restart the game and open Havoc Condition Manager in Mod Options.

## Manual installation

- Close the game. When upgrading, remove the previous HavocConditionManager installation folder before extracting the new ZIP; saved settings are stored separately.
- Extract the ZIP into Darktide/mods, producing mods/HavocConditionManager.
- Add HavocConditionManager on its own line after SoloPlay in mods/mod_load_order.txt. Place the optional HavocEnemyDirector after it.
- Restart the game and open HCM in Mod Options.

## Credits

SoloPlay and the original UI foundation: deluxghost. Native game systems and assets: Fatshark. Game-source reference: Aussiemon/Darktide-Source-Code.
