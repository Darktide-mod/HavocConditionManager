-- Select from authored event doors before native nodes enqueue anything.
-- Native queues, queue IDs, ownership and event completion stay intact.
local mod=get_mod("HavocConditionManager")
local System=require("scripts/extension_systems/minion_spawner/minion_spawner_system")
local Terror=require("scripts/managers/terror_event/terror_event_manager")
local Placement=mod.spawn_placement
local override
local function copy(list)
    local result={};for i,spawner in ipairs(list) do result[i]=spawner end;return result
end
mod:hook(System,"spawners_in_group",function(fn,self,group,...)
    if override and override.group==group then return copy(override.spawners) end
    return fn(self,group,...)
end)
mod:hook(System,"spawners_in_group_distance_sorted",function(fn,self,group,...)
    if override and override.group==group then return copy(override.spawners) end
    return fn(self,group,...)
end)
local function prepare(owner,node,t,side_id,target_side_id,level)
    local context=Placement.context(side_id,target_side_id)
    if not context then return end
    local job=owner._hcm_event_placement
    if not job or job.node~=node or job.context_target~=context.target or t-job.started>8 then
        local system=Managers.state.extension:system("minion_spawner_system")
        local groups={node.spawner_group}
        -- These three pools are all authored for this same ascender encounter.
        -- Widening within the encounter avoids the distant sewer entrance
        -- without borrowing doors from another mission stage.
        if node.spawner_group:match("^spawner_ascender_trickle_[abc]$") then
            groups={"spawner_ascender_trickle_a","spawner_ascender_trickle_b","spawner_ascender_trickle_c"}
        end
        local candidates,seen={},{}
        for _,group in ipairs(groups) do
            for _,spawner in ipairs(system:spawners_in_group(group,node.group_in_level_data,level) or {}) do
                if not seen[spawner] and #candidates<48 and spawner.exit_position_boxed then
                    seen[spawner]=true
                    local boxed=spawner:exit_position_boxed()
                    if boxed then
                        local position=boxed:unbox()
                        local nearest=math.huge
                        for _,player in ipairs(context.side.valid_enemy_player_units_positions) do nearest=math.min(nearest,Vector3.distance_squared(position,player)) end
                        if nearest>=100 and nearest<=120*120 then
                            candidates[#candidates+1]={spawner=spawner,position=Vector3Box(position),distance=nearest,group=group}
                        end
                    end
                end
            end
        end
        table.sort(candidates,function(a,b) return a.distance<b.distance end)
        job={node=node,context_target=context.target,target=Vector3Box(context.position),started=t,candidates=candidates,index=1,approved={}}
        owner._hcm_event_placement=job
    end
    local tested=0
    while tested<3 and job.candidates[job.index] do
        local candidate=job.candidates[job.index]
        local connected,length=Placement.route(candidate,context,candidate.position:unbox(),t,85)
        if connected==nil then return end
        if connected then
            candidate.length=length;job.approved[#job.approved+1]=candidate
        end
        job.index=job.index+1;tested=tested+1;job.checked=(job.checked or 0)+1
        if #job.approved>0 and job.checked>=3 then break end
    end
    if job.candidates[job.index] and (#job.approved==0 or (job.checked or 0)<3) then return end
    if #job.approved==0 then return end
    table.sort(job.approved,function(a,b) return a.length<b.length end)
    local spawners={}
    for i=1,math.min(3,#job.approved) do
        local candidate=job.approved[i]
        local connected,length=Placement.route(candidate,context,candidate.position:unbox(),t,85)
        if connected==nil then return end
        if not connected then owner._hcm_event_placement=nil;return end
        for _,player in ipairs(context.side.valid_enemy_player_units_positions) do
            if Vector3.distance_squared(candidate.position:unbox(),player)<100 then owner._hcm_event_placement=nil;return end
        end
        candidate.length=length;spawners[i]=candidate.spawner
    end
    local batch=mod.new_spawn_batch("mission_spawner",side_id,target_side_id,node.spawner_group)
    batch.route_length=job.approved[1].length;batch.target_position=Vector3Box(context.position)
    batch.doors={};batch.door_routes={}
    for i=1,#spawners do
        local candidate=job.approved[i]
        batch.doors[candidate.spawner]=candidate.group;batch.door_routes[candidate.spawner]=candidate.length
    end
    return {group=node.spawner_group,spawners=spawners},batch
end
local function select_or_wait(owner,node,t,side,target_side,level)
    if owner._hcm_wait_node~=node then owner._hcm_event_wait=nil;owner._hcm_wait_node=node end
    owner._hcm_event_wait=owner._hcm_event_wait or t
    local selected,batch=prepare(owner,node,t,side,target_side,level)
    if selected then owner._hcm_event_wait=nil;return selected,batch end
    if t-owner._hcm_event_wait<10 then return end
    -- Missing/busy navigation must never make a required mission wave wait
    -- forever. Preserve the authored door pool and log this exceptional case.
    batch=mod.new_spawn_batch("mission_spawner",side,target_side,node.spawner_group)
    batch.fallback="no_approved_route_after_10s"
    owner._hcm_event_wait=nil;owner._hcm_event_placement=nil
    return false,batch
end
local function invoke(fn,selected,batch,...)
    local previous,previous_batch=override,mod.current_spawn_batch
    override=selected;mod.current_spawn_batch=batch
    local ok,result=pcall(fn,...)
    override=previous;mod.current_spawn_batch=previous_batch
    if not ok then error(result,0) end
    return result
end
function mod.run_event_spawn_node(fn,node,scratchpad,t,dt)
    if not mod.has_local_gameplay_authority() or scratchpad.started_spawn or node.mission_objective_id or not node.spawner_group then
        return fn(node,scratchpad,t,dt)
    end
    local pacing=Managers.state.pacing
    if not pacing:spawn_type_allowed("terror_events") then return false end
    local side_id,target_side_id=pacing._side_id,pacing._target_side_id
    local sides=Managers.state.extension:system("side_system")
    if node.side_name then side_id=sides:get_side_from_name(node.side_name).side_id end
    if node.target_side_name then target_side_id=sides:get_side_from_name(node.target_side_name).side_id end
    local selected,batch=select_or_wait(scratchpad,node,t,side_id,target_side_id,scratchpad.level)
    if not batch then return false end
    return invoke(fn,selected,batch,node,scratchpad,t,dt)
end
mod:hook(Terror,"_update_terror_trickle",function(fn,self,dt,t)
    local data=self._terror_trickle_data
    if not mod.has_local_gameplay_authority() or not data or not data.active or not data.spawner_group or
        not data.wave_timer or data.wave_timer>dt then return fn(self,dt,t) end
    if not Managers.state.pacing:spawn_type_allowed("terror_events") then return fn(self,dt,t) end
    local selected,batch=select_or_wait(data,data,t,data.spawn_side_id,data.target_side_id)
    if not batch then return end
    local result=invoke(fn,selected,batch,self,dt,t)
    data._hcm_event_placement=nil
    return result
end)
return true
