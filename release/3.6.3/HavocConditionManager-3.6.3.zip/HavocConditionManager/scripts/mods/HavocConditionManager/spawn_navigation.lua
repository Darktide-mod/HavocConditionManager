-- One native asynchronous navigation probe, shared by pending batches. It
-- has no unit, behavior or enemy slot. Partial far paths fail endpoint checks.
local mod=get_mod("HavocConditionManager")
local M={}
local waiting,active,next_start={},nil,0
local session,started,completed,rejected,timeouts=0,0,0,0,0
local function dispose(request)
    if request.bot then
        if GwNavBot.is_computing_new_path(request.bot) then GwNavBot.cancel_async_path_computation(request.bot) end
        GwNavBot.destroy(request.bot);request.bot=nil
    end
end
local function same(request,nav,logic,from,target,t)
    return request and request.session==session and request.nav==nav and request.logic==logic
        and t-request.seen<8 and (not request.finished or t-request.finished<3)
        and Vector3.distance_squared(from,request.from:unbox())<0.25
        and Vector3.distance_squared(target,request.target:unbox())<4
end
function M.check(owner,nav,logic,from,target,t,maximum)
    if not nav or not logic or not GwNavBot or not GwNavBot.create then return false,"navigation_unavailable" end
    local request=owner._hcm_route_query
    -- A waiting job keeps its FIFO position when the player moves. It has
    -- not entered the engine yet, so its destination can still be refreshed.
    if request and not request.started and not request.finished and not request.cancelled and t-request.seen<8 and
        request.session==session and request.nav==nav and request.logic==logic and
        Vector3.distance_squared(from,request.from:unbox())<0.25 then
        request.target=Vector3Box(target);request.seen=t
    end
    if not same(request,nav,logic,from,target,t) then
        if request then request.cancelled=true end
        if #waiting>=24 then return nil,"navigation_busy" end
        request={session=session,nav=nav,logic=logic,from=Vector3Box(from),target=Vector3Box(target),seen=t}
        owner._hcm_route_query=request;waiting[#waiting+1]=request
    end
    request.seen=t
    if not request.finished then return nil,"navigation_pending" end
    if request.reason then return false,request.reason end
    if request.length>maximum then return false,"route_too_long",request.length end
    return true,request.length
end
function M.update(t)
    local request=active
    if request then
        if request.cancelled or t-request.seen>8 then dispose(request);active=nil
        elseif t-request.started>3 then
            dispose(request);active=nil;request.finished=t;request.reason="navigation_timeout";timeouts=timeouts+1
        elseif not GwNavBot.is_computing_new_path(request.bot) then
            local reason,length
            if not GwNavBot.has_path(request.bot) then reason="no_route"
            else
                local count=GwNavBot.get_path_nodes_count(request.bot)
                local goal=count and count>0 and GwNavBot.get_path_node_pos(request.bot,count)
                if not goal or Vector3.distance_squared(goal,request.target:unbox())>9 then reason="partial_route"
                else
                    length=GwNavBot.get_remaining_distance_from_progress_to_end_of_path(request.bot)
                    if not length or length~=length or length==math.huge or length<0 then reason="invalid_route"
                    else length=math.max(length,Vector3.distance(request.from:unbox(),goal)) end
                end
            end
            request.finished=t;request.reason=reason;request.length=length
            completed=completed+1;if reason then rejected=rejected+1 end
            dispose(request);active=nil
        end
    end
    if active or t<next_start then return end
    for _=1,24 do
        request=table.remove(waiting,1)
        if not request then return end
        if not request.cancelled and t-request.seen<=8 and request.session==session then
            request.bot=GwNavBot.create(request.nav,1.6,0.5,1,request.from:unbox(),request.logic)
            GwNavBot.set_use_avoidance(request.bot,false)
            GwNavBot.set_outside_navmesh_distance(request.bot,0.2,0.2)
            GwNavBot.compute_new_path(request.bot,request.target:unbox(),true)
            request.started=t;active=request;started=started+1;next_start=t+0.25
            return
        end
    end
end
function M.reset()
    if active then dispose(active) end
    if started>0 then mod:info("Spawn navigation receipt: queries %d; completed %d; failed %d; timed out %d; maximum simultaneous 1.",started,completed,rejected,timeouts) end
    active=nil;waiting={};next_start=0;session=session+1;started=0;completed=0;rejected=0;timeouts=0
end
mod.spawn_navigation=M
return M
