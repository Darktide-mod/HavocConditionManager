-- Carry origin through both native asynchronous queues. Receipts describe
-- actual entities, not requested composition or a transient caller stack.
local mod=get_mod("HavocConditionManager")
local Minion=require("scripts/managers/minion/minion_spawn_manager")
local Spawner=require("scripts/extension_systems/minion_spawner/minion_spawner_extension")
local Utilities=require("scripts/managers/horde/utilities/horde_utilities")
local Breeds=require("scripts/settings/breed/breeds")
local Placement=mod.spawn_placement
local Pacing=require("scripts/managers/pacing/pacing_manager")
local Points=require("scripts/managers/main_path/utilities/spawn_point_queries")
local trickle_position
mod:hook(Points,"get_random_occluded_position",function(fn,...)
    if trickle_position then return trickle_position:unbox() end
    return fn(...)
end)
mod:hook(Pacing,"exp_random_position_away_from_players",function(fn,...)
    if trickle_position then return trickle_position:unbox() end
    return fn(...)
end)
function mod.run_trickle_horde(fn,self,kind,template,side,target_side,composition,...)
    local context=Placement.context(side,target_side)
    if not context then return false end
    local job=self._hcm_trickle_placement or {};self._hcm_trickle_placement=job
    local t=Managers.time:time("gameplay")
    if not job.position then
        local position=Placement.anchor(context,job)
        if not position then return false end
        job.position=Vector3Box(position)
    end
    local position=job.position:unbox()
    if not Placement.valid(context,position) then job.position=nil;return false end
    local connected,length=Placement.route(job,context,position,t)
    if not connected then
        if connected==false then Placement.reject(job,position,t);job.position=nil end
        return false
    end
    local batch=mod.current_spawn_batch
    batch.route_length=length;batch.target_position=Vector3Box(context.position);batch.corrected=true
    local previous=trickle_position;trickle_position=job.position
    local ok,a,b,c,d,e=pcall(fn,self,kind,template,side,target_side,composition,...)
    trickle_position=previous
    if not ok then error(a,0) end
    if a then self._hcm_trickle_placement=nil end
    return a,b,c,d,e
end
local serial,lines,batches=0,0,{}
function mod.new_spawn_batch(source,side,target_side,event)
    serial=serial+1
    local batch={id=serial,source=source,side_id=side,target_side_id=target_side,event=event,created=0,elite=0,queued=0}
    -- Retain at most 96 reporting records; spawn tickets themselves own the
    -- lifetime needed for a deferred request, independent of this receipt.
    if #batches>=96 then table.remove(batches,1) end
    batches[#batches+1]=batch
    return batch
end
function mod.tag_spawn_request(entry)
    local batch=mod.current_spawn_batch
    if batch then entry._hcm_batch=batch;batch.queued=batch.queued+1 end
    return entry
end
mod:hook(Minion,"spawn_minion",function(fn,self,breed,position,rotation,side,params,...)
    if not mod.has_local_gameplay_authority() then return fn(self,breed,position,rotation,side,params,...) end
    local previous=mod.current_spawn_batch
    local batch=params and params._hcm_batch or previous
    mod.current_spawn_batch=batch
    local ok,unit=pcall(fn,self,breed,position,rotation,side,params,...)
    mod.current_spawn_batch=previous
    if not ok then error(unit,0) end
    if unit and batch then
        batch.created=batch.created+1
        if Breeds[breed] and Breeds[breed].tags.elite then batch.elite=batch.elite+1 end
        if not batch.first_position then batch.first_position=Vector3Box(position) end
        batch.last_position=Vector3Box(position)
        if batch.created==1 and lines<96 then
            lines=lines+1
            mod:info("Spawn batch %d: source %s; event %s; door %s; door group %s; first %s; target %s; corrected %s; route %s; fallback %s.",
                batch.id,batch.source,tostring(batch.event or "none"),tostring(batch.door or "none"),tostring(batch.door_group or "none"),
                tostring(position),tostring(batch.target_position and batch.target_position:unbox() or "unknown"),
                tostring(batch.corrected or false),tostring(batch.route_length or "native"),tostring(batch.fallback or "none"))
        end
    end
    return unit
end)
mod:hook(Spawner,"add_spawns",function(fn,self,breeds,side,params,...)
    if mod.has_local_gameplay_authority() and mod.current_spawn_batch and params then
        params._hcm_batch=mod.current_spawn_batch
    end
    return fn(self,breeds,side,params,...)
end)
mod:hook(Spawner,"_spawn",function(fn,self,breed,data,...)
    local previous=mod.current_spawn_batch
    local batch=mod.has_local_gameplay_authority() and data and data._hcm_batch
    if batch then
        mod.current_spawn_batch=batch
        batch.door=tostring(self._unit)
        batch.door_group=batch.doors and batch.doors[self] or batch.event
        batch.route_length=batch.door_routes and batch.door_routes[self] or batch.route_length
    end
    local ok,result=pcall(fn,self,breed,data,...)
    mod.current_spawn_batch=previous
    if not ok then error(result,0) end
    return result
end)
function mod.prepare_horde_entry(batch,entry,t)
    if batch.event or not batch.horde then return true end
    if batch.next_try and t<batch.next_try then return nil end
    local context=Placement.context(entry.side_id,batch.target_side_id)
    if not context then return nil end
    local position=entry.position:unbox()
    if batch.corrected then
        if not batch.corrected_anchor then
            local anchor=Placement.anchor(context,batch)
            if not anchor then batch.next_try=t+2;return nil end
            batch.corrected_anchor=Vector3Box(anchor)
        end
        position=Utilities.try_find_spawn_position(context.nav,batch.corrected_anchor:unbox(),batch.created+1,6,3,context.traverse)
        if not position or not Placement.valid(context,position) then batch.corrected_anchor=nil;batch.next_try=t+2;return nil end
    end
    local visible=Utilities.position_has_line_of_sight_to_any_enemy_player(context.physics,position+Vector3.up(),context.side,"filter_ray_aim_assist_line_of_sight")
    local nearest=math.huge
    for _,player_position in ipairs(context.side.valid_enemy_player_units_positions) do nearest=math.min(nearest,Vector3.distance_squared(position,player_position)) end
    if visible or nearest<20*20 or nearest>120*120 then
        Placement.reject(batch,position,t);batch.corrected=true;batch.corrected_anchor=nil;batch.next_try=t+0.25;return nil
    end
    local connected,length=Placement.route(batch,context,position,t)
    if not connected then
        if connected==false then
            Placement.reject(batch,position,t);batch.corrected=true;batch.corrected_anchor=nil;batch.next_try=t+0.25
        end
        return nil
    end
    entry.position=Vector3Box(position);entry.optional_target_unit=context.target
    batch.route_length=length;batch.target_position=Vector3Box(context.position)
    return true
end
function mod.finish_spawn_flow()
    for _,batch in ipairs(batches) do
        if batch.created>0 then mod:info("Spawn batch receipt %d: source %s; actual %d; elite %d; corrected %s.",batch.id,batch.source,batch.created,batch.elite,tostring(batch.corrected or false)) end
    end
    batches={};serial=0;lines=0;mod.current_spawn_batch=nil
end
return true
