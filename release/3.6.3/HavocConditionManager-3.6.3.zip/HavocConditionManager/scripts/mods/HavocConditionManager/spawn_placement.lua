-- Reuse the game's main-path points and current horde LOS test. Query a small
-- region ahead of the team; never turn a missing hidden point into a near spawn.
local mod=get_mod("HavocConditionManager")
local SpawnPoints=require("scripts/managers/main_path/utilities/spawn_point_queries")
local MainPath=require("scripts/utilities/main_path_queries")
local HordeUtilities=require("scripts/managers/horde/utilities/horde_utilities")
local NavQueries=require("scripts/utilities/nav_queries")
local M={}
local MIN_DISTANCE,MIN_AHEAD,PREFERRED_AHEAD,MAX_AHEAD=35,30,60,120
function M.context(side_id,target_side_id)
    local pacing=Managers.state.pacing
    local main=Managers.state.main_path
    if not pacing or pacing:get_in_safe_zone() or not main or not main:is_main_path_ready() then return end
    local target,distance,path_position=main:ahead_unit(target_side_id)
    local position=target and POSITION_LOOKUP[target]
    local side=Managers.state.extension:system("side_system"):get_side(side_id)
    local horde=Managers.state.horde
    if not position or not distance or not side or not horde or not horde._physics_world
        or not side.valid_enemy_player_units_positions or #side.valid_enemy_player_units_positions==0 then return end
    path_position=path_position or MainPath.position_from_distance(distance)
    if not path_position then return end
    return {main=main,target=target,distance=distance,position=position,path_position=path_position,side=side,
        nav=pacing._nav_world,physics=horde._physics_world,
        traverse=pacing.roamer_traverse_logic and pacing:roamer_traverse_logic()}
end
function M.route(owner,context,position,t,maximum)
    -- Flood-fill members share an anchor only across directly traversable
    -- local ground. No per-member full path search is needed for a formation.
    local anchor=owner._hcm_route_anchor
    local local_distance=0
    if anchor and Vector3.distance_squared(position,anchor:unbox())<=36
        and NavQueries.ray_can_go(context.nav,position,anchor:unbox(),context.traverse,1,1) then
        local_distance=Vector3.distance(position,anchor:unbox());position=anchor:unbox()
    else owner._hcm_route_anchor=Vector3Box(position) end
    local target=NavQueries.position_on_mesh_with_outside_position(context.nav,context.traverse,context.position,1,1,2)
    if not target then return false,"target_off_navmesh" end
    local connected,length,measured=mod.spawn_navigation.check(owner,context.nav,context.traverse,position,target,t,(maximum or 100)-local_distance)
    if connected then return true,length+local_distance end
    return connected,length,measured and measured+local_distance
end
function M.reject(owner,position,t)
    owner._hcm_route_anchor=nil
    local rejected=owner._hcm_rejected or {};owner._hcm_rejected=rejected
    if #rejected>=8 then table.remove(rejected,1) end
    rejected[#rejected+1]={position=Vector3Box(position),until_t=t+15}
end
local function rejected(owner,position)
    if not owner or not owner._hcm_rejected then return false end
    local t=Managers.time:time("gameplay")
    for _,entry in ipairs(owner._hcm_rejected or {}) do
        if t<entry.until_t and Vector3.distance_squared(position,entry.position:unbox())<36 then return true end
    end
    return false
end
function M.within_limits(context,position)
    local nearest=math.huge
    for _,player_position in ipairs(context.side.valid_enemy_player_units_positions) do
        local d=Vector3.distance_squared(position,player_position)
        if d<MIN_DISTANCE*MIN_DISTANCE then return end
        nearest=math.min(nearest,d)
    end
    if nearest>MAX_AHEAD*MAX_AHEAD then return end
    local progress=context.main:travel_distance_from_position(position,true)
    local ahead=progress and progress-context.distance
    if not ahead or ahead<MIN_AHEAD or ahead>MAX_AHEAD then return end
    return ahead,math.sqrt(nearest)
end
function M.valid(context,position)
    local ahead,distance=M.within_limits(context,position)
    if not ahead then return end
    if HordeUtilities.position_has_line_of_sight_to_any_enemy_player(context.physics,position+Vector3.up(),
        context.side,"filter_ray_aim_assist_line_of_sight") then return end
    return true,ahead,distance
end
function M.anchor(context,owner)
    local points=context.main:nav_spawn_points()
    if not points then return end
    local groups=GwNavSpawnPoints.get_count(points)
    if groups<1 then return end
    local wanted=MainPath.position_from_distance(context.distance+PREFERRED_AHEAD)
    if not wanted then return end
    local candidates,count=SpawnPoints.get_occluded_positions(context.nav,points,wanted,
        context.side.valid_enemy_player_units_positions,4,groups,MIN_DISTANCE,MAX_AHEAD,nil,true)
    local choices={}
    -- The native query is local. Cap route projections too; LOS runs only on
    -- at most three preferred points and each final unit position when due.
    for i=1,math.min(count or 0,32) do
        local candidate=candidates[i]
        local ahead=M.within_limits(context,candidate)
        if ahead and not rejected(owner,candidate) then
            local score=math.abs(ahead-PREFERRED_AHEAD)
            local index=1
            while choices[index] and choices[index].score<=score do index=index+1 end
            if index<=3 then
                table.insert(choices,index,{position=candidate,score=score})
                choices[4]=nil
            end
        end
    end
    for _,choice in ipairs(choices) do if M.valid(context,choice.position) then return choice.position end end
end
mod.spawn_placement=M
return M
