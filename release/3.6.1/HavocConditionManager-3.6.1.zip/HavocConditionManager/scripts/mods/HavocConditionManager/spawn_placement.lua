-- Reuse the game's main-path points and current horde LOS test. Query a small
-- region ahead of the team; never turn a missing hidden point into a near spawn.
local mod=get_mod("HavocConditionManager")
local SpawnPoints=require("scripts/managers/main_path/utilities/spawn_point_queries")
local MainPath=require("scripts/utilities/main_path_queries")
local HordeUtilities=require("scripts/managers/horde/utilities/horde_utilities")
local M={}
local MIN_DISTANCE,MIN_AHEAD,PREFERRED_AHEAD,MAX_AHEAD=35,30,60,120
function M.context(side_id,target_side_id)
    local pacing=Managers.state.pacing
    local main=Managers.state.main_path
    if not pacing or pacing:get_in_safe_zone() or not main or not main:is_main_path_ready() then return end
    local target,distance=main:ahead_unit(target_side_id)
    local position=target and POSITION_LOOKUP[target]
    local side=Managers.state.extension:system("side_system"):get_side(side_id)
    local horde=Managers.state.horde
    if not position or not distance or not side or not horde or not horde._physics_world
        or not side.valid_enemy_player_units_positions or #side.valid_enemy_player_units_positions==0 then return end
    return {main=main,target=target,distance=distance,position=position,side=side,
        nav=pacing._nav_world,physics=horde._physics_world}
end
function M.within_limits(context,position)
    local nearest=math.huge
    for _,player_position in ipairs(context.side.valid_enemy_player_units_positions) do
        local d=Vector3.distance_squared(position,player_position)
        if d<MIN_DISTANCE*MIN_DISTANCE then return end
        nearest=math.min(nearest,d)
    end
    if nearest>MAX_AHEAD*MAX_AHEAD then return end
    local progress=context.main:travel_distance_from_position(position,true)
    local ahead=progress and progress-context.distance
    if not ahead or ahead<MIN_AHEAD or ahead>MAX_AHEAD then return end
    return ahead,math.sqrt(nearest)
end
function M.valid(context,position)
    local ahead,distance=M.within_limits(context,position)
    if not ahead then return end
    if HordeUtilities.position_has_line_of_sight_to_any_enemy_player(context.physics,position+Vector3.up(),
        context.side,"filter_ray_aim_assist_line_of_sight") then return end
    return true,ahead,distance
end
function M.anchor(context)
    local points=context.main:nav_spawn_points()
    if not points then return end
    local groups=GwNavSpawnPoints.get_count(points)
    if groups<1 then return end
    local wanted=MainPath.position_from_distance(context.distance+PREFERRED_AHEAD)
    if not wanted then return end
    local candidates,count=SpawnPoints.get_occluded_positions(context.nav,points,wanted,
        context.side.valid_enemy_player_units_positions,4,groups,MIN_DISTANCE,MAX_AHEAD,nil,true)
    local choices={}
    -- The native query is local. Cap route projections too; LOS runs only on
    -- at most three preferred points and each final unit position when due.
    for i=1,math.min(count or 0,32) do
        local candidate=candidates[i]
        local ahead=M.within_limits(context,candidate)
        if ahead then
            local score=math.abs(ahead-PREFERRED_AHEAD)
            local index=1
            while choices[index] and choices[index].score<=score do index=index+1 end
            if index<=3 then
                table.insert(choices,index,{position=candidate,score=score})
                choices[4]=nil
            end
        end
    end
    for _,choice in ipairs(choices) do if M.valid(context,choice.position) then return choice.position end end
end
mod.spawn_placement=M
return M
