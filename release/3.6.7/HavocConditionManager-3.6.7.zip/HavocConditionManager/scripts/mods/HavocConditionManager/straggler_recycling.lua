-- One rule: an ordinary enemy that has engaged but stayed out of contact
-- with every living teammate for 30 seconds can retire. Movement, route,
-- patrol flags and unrelated active events do not grant permanent immunity.
local mod=get_mod("HavocConditionManager")
local Roamer=require("scripts/managers/pacing/roamer_pacing/roamer_pacing")
local Monster=require("scripts/managers/pacing/monster_pacing/monster_pacing")
local Horde=require("scripts/managers/horde/horde_manager")
local Perception=require("scripts/extension_systems/perception/minion_perception_extension")
local Health=require("scripts/extension_systems/health/health_extension")
local Placement=mod.spawn_placement
local CHECK_INTERVAL,QUIET_TIME,DISTANCE_SQ=5,30,35*35
local MAX_CREDITS,MAX_CREDIT_UNITS,CREDIT_LIFETIME,SPAWN_INTERVAL=24,96,180,8
local state,patrol_context
local function current()
    if not state then state={credits={},next_remove=0,next_spawn=0,credit_units=0,
        removed=0,credited=0,queued=0,created=0,discarded=0,cancelled=0,los=0,positions=0,
        tracked=0,observed=0,qualified=0,rejoined=0,reasons={},debug_lines=0,debug_next=0,
        ready={},ready_index=1,ready_size=0} end
    return state
end
local function extension(unit,name) return ScriptUnit.has_extension(unit,name) end
local function native_group(unit)
    local ext=extension(unit,"group_system")
    return ext and ext.group and ext:group()
end
local function attach(unit,owner,record,side_id,origin)
    local ext=unit and extension(unit,"perception_system")
    local breed=ext and ext._breed
    local tags=breed and breed.tags or {}
    if not breed or breed.breed_type~="minion" or tags.special or tags.monster or tags.captain or tags.companion then return end
    local group=native_group(unit)
    if group and origin then
        group._hcm_recycling=group._hcm_recycling or origin;origin=group._hcm_recycling
    end
    local meta=ext._hcm_straggler
    if not meta then
        local s=current();s.tracked=s.tracked+1
        meta={id=s.tracked,next_check=0,side_id=side_id};ext._hcm_straggler=meta
    end
    if owner then meta.owner=owner;meta.record=record;meta.kind="roamers" end
    meta.group=group;meta.origin=origin or meta.origin
    if origin then meta.kind=origin.kind;meta.health=origin.health;meta.replacement=origin.replacement end
    return meta
end
mod:hook_safe(Roamer,"_try_activate_roamer",function(self,record,side_id)
    if mod.has_local_gameplay_authority() and record.active and record.spawned_unit then
        attach(record.spawned_unit,self,record,side_id,record.patrol_id and {kind="roamers"})
    end
end)
-- Observe only native pacing patrol creation. Mission-controlled and expedition
-- loot patrols retain their original ownership and cannot enter this pool.
mod:hook(Monster,"_spawn_boss_patrol",function(fn,self,record,ahead_distance,side_id,...)
    if mod.has_local_gameplay_authority() and self._pacing_type=="default" then
        return mod.queue_native_patrol(self,record,side_id)
    end
    local previous=patrol_context
    patrol_context=mod.has_local_gameplay_authority() and
        (self._pacing_type=="default" or self._hcm_recyclable_patrol) and {kind="monsters"} or nil
    local ok,result=pcall(fn,self,record,ahead_distance,side_id,...)
    patrol_context=previous
    if not ok then error(result,0) end
    return result
end)
mod:hook(Horde,"horde",function(fn,self,kind,template,side_id,target_side_id,composition,...)
    local previous=patrol_context
    local previous_batch=mod.current_spawn_batch
    local params=select(9,...)
    patrol_context=mod.has_local_gameplay_authority() and template=="trickle_horde" and
        not (previous_batch and previous_batch.event) and
        not (params and (params.externally_controlled_patrol or params.mutator_name)) and
        {kind="trickle_hordes",health=select(5,...)} or nil
    if mod.has_local_gameplay_authority() and not previous_batch then
        local batch=mod.new_spawn_batch(template,side_id,target_side_id,params and (params.externally_controlled_patrol or params.mutator_name))
        batch.horde=true;batch.kind=template=="trickle_horde" and "trickle_hordes" or "hordes"
        mod.current_spawn_batch=batch
    end
    local ok,a,b,c,d,e=pcall(fn,self,kind,template,side_id,target_side_id,composition,...)
    patrol_context=previous
    mod.current_spawn_batch=previous_batch
    if not ok then error(a,0) end
    return a,b,c,d,e
end)

mod.track_redeployed_unit=function(unit)
    local board=BLACKBOARDS and BLACKBOARDS[unit]
    local sides=Managers.state.extension:system("side_system")
    local side=sides.side_by_unit[unit]
    if not board or not side then return end
    local group=native_group(unit)
    local batch=mod.current_spawn_batch
    local meta=attach(unit,nil,nil,side.side_id,group and group._hcm_recycling or patrol_context)
    if not meta then return end
    meta.kind=meta.kind or batch and batch.kind or "hordes"
    meta.protected=batch and (batch.protected_objective or batch.event and batch.source~="mission_spawner")
    meta.source=batch and batch.source
    meta.batch=batch or meta.batch
    if board.spawn and board.spawn.spawn_source=="hcm_redeployed" and not meta.created_receipt then
        meta.replacement=true;meta.created_receipt=true;current().created=current().created+1
    end
end
local function has_objective(unit)
    local objective=extension(unit,"mission_objective_target_system")
    if not objective then return false end
    if not objective.objective_name then return true end
    local name=objective:objective_name()
    return objective._registered_objective or name and name~="" and name~="default"
end
local function note_reason(meta,reason,t)
    if meta.reason~=reason then
        local counts=current().reasons;counts[reason]=(counts[reason] or 0)+1
        meta.reason=reason;meta.reason_at=t
    end
end
local function sample(ext,unit,meta)
    local board=BLACKBOARDS and BLACKBOARDS[unit]
    local perception=board and board.perception
    if not HEALTH_ALIVE[unit] or ext._is_perception_disabled or not perception then return nil,"inactive" end
    -- Known pacing patrols are already committed encounters. Otherwise a
    -- whole passive formation on a bad point could retain permanent immunity.
    -- Untouched ambient enemies keep their native activation/despawn behavior.
    if perception.aggro_state~="aggroed" and not meta.origin then return nil,"passive" end
    if perception.has_line_of_sight then return nil,"target_visible" end
    local side=ext._side_system and ext._side_system.side_by_unit[unit]
    local players=side and side.enemy_player_units
    local position=POSITION_LOOKUP[unit]
    if not position or not players or #players==0 or #players>8 then return nil,"players_unknown" end
    local count,nearest,nearest_index=0,math.huge,0
    for i,player in ipairs(players) do
        if HEALTH_ALIVE[player] then
            local player_position=POSITION_LOOKUP[player]
            if not player_position then return nil,"players_unknown" end
            local distance=Vector3.distance_squared(position,player_position)
            if distance<nearest then nearest=distance;nearest_index=i end
            if ext:has_line_of_sight(player) then return nil,"player_visible",math.sqrt(distance),i end
            count=count+1
        end
    end
    if count==0 then return nil,"players_unknown" end
    nearest=math.sqrt(nearest)
    if nearest*nearest<DISTANCE_SQ then return nil,"near_teammate",nearest,nearest_index end
    local spawn=board.spawn
    if not spawn or spawn.is_exiting_spawner then return nil,"exiting_spawner",nearest,nearest_index end
    local group=board.group_data
    if meta.protected or has_objective(unit) or group and group.owning_auto_event_id and group.owning_auto_event_id~="" then
        return nil,"objective_or_controller",nearest,nearest_index
    end
    if meta.record and (meta.record._hcm_retired or meta.record.spawned_unit~=unit) then return nil,"stale_record",nearest,nearest_index end
    local manager=Managers.state.minion_spawn
    if not manager or not manager._spawned_minions_index_lookup[unit] or manager._minions_with_owners[unit] then
        return nil,"owner_or_removed",nearest,nearest_index
    end
    local health=extension(unit,"health_system")
    if not health or health.is_invulnerable and health:is_invulnerable() then return nil,"invulnerable_or_unknown",nearest,nearest_index end
    return players,"eligible",nearest,nearest_index
end
local function debug_evidence(s,unit,ext,meta,reason,t,distance,player_index,force)
    if s.debug_lines>=48 or t<s.debug_next or meta.debug_reason==reason then return end
    if not force and (not distance or reason=="player_visible" or t-(meta.reason_at or t)<30) then return end
    local board=BLACKBOARDS[unit]
    local spawn=board and board.spawn
    local nav=extension(unit,"navigation_system")
    s.debug_lines=s.debug_lines+1;s.debug_next=t+10;meta.debug_reason=reason
    mod:info("Recovery debug: id %d; breed %s; source %s; reason %s; reason age %.1fs; quiet %.1fs; last damage age %.1fs; nearest %.1fm; player index %d; position %s; aggro %s; target LOS %s; objective %s; auto-event %s; nav enabled %s; smart object %s.",
        meta.id,ext._breed.name,tostring(spawn and spawn.spawn_source or meta.source or "native"),reason,
        t-(meta.reason_at or t),meta.since and t-meta.since or 0,meta.last_damage and t-meta.last_damage or -1,
        distance or -1,player_index or 0,tostring(POSITION_LOOKUP[unit]),tostring(board and board.perception and board.perception.aggro_state),
        tostring(board and board.perception and board.perception.has_line_of_sight),tostring(meta.protected or has_objective(unit) or false),
        tostring(board and board.group_data and board.group_data.owning_auto_event_id),tostring(nav and nav._enabled),tostring(nav and nav._is_using_smart_object))
end
local function rejoin_orphan(ext,unit,meta,t)
    if t<(current().next_rejoin or 0) or meta.rejoined or not meta.group or not meta.origin or meta.replacement then return end
    local board=BLACKBOARDS[unit];local patrol=board and board.patrol;local perception=board and board.perception
    local group=board and board.group_data
    if not HEALTH_ALIVE[unit] or ext._is_perception_disabled or not patrol or not patrol.should_patrol or
        (patrol.patrol_index or 0)<=1 or HEALTH_ALIVE[patrol.patrol_leader_unit] or not perception or perception.target_unit or
        perception.lock_target or group and (group.group_target or group.owning_auto_event_id and group.owning_auto_event_id~="") or
        meta.protected or has_objective(unit) then return end
    local nav=extension(unit,"navigation_system");local manager=Managers.state.minion_spawn
    if not nav or not nav.is_using_smart_object or nav:is_using_smart_object() or not manager or manager._minions_with_owners[unit] then return end
    local side=ext._side_system.side_by_unit[unit]
    for _,player in ipairs(side and side.enemy_player_units or {}) do
        if HEALTH_ALIVE[player] and side.ai_target_units and side.ai_target_units[player] then
            ext:alert(player);ext:aggro();meta.rejoined=true
            local s=current();s.next_rejoin=t+0.15;s.rejoined=s.rejoined+1
            if s.rejoined<=8 then mod:info("Patrol orphan rejoined combat: %s.",ext._breed.name) end
            return
        end
    end
end
mod:hook_safe(Perception,"update",function(self,unit,dt,t)
    local meta=self._hcm_straggler
    if not meta or not mod.has_local_gameplay_authority() or t<meta.next_check then return end
    meta.next_check=t+CHECK_INTERVAL
    rejoin_orphan(self,unit,meta,t)
    local s=current()
    local players,reason,distance,index=sample(self,unit,meta)
    note_reason(meta,reason,t)
    if not players then
        meta.since=nil;debug_evidence(s,unit,self,meta,reason,t,distance,index);return
    end
    if not meta.since then meta.since=t;s.qualified=s.qualified+1 end
    if t-math.max(meta.since,meta.last_damage or 0)<QUIET_TIME then return end
    if meta.enqueued then return end
    if s.ready_size<16 then
        s.ready[(s.ready_index+s.ready_size-1)%16+1]=unit
        s.ready_size=s.ready_size+1;meta.enqueued=true
    else debug_evidence(s,unit,self,meta,"awaiting_removal_slot",t,distance,index) end
end)
mod:hook_safe(Health,"add_damage",function(self,amount)
    if not amount or amount<=0 then return end
    local ext=self._unit and extension(self._unit,"perception_system")
    local meta=ext and ext._hcm_straggler
    if meta then meta.last_damage=Managers.time:time("gameplay");if meta.since then meta.since=meta.last_damage end end
end)
local function add_credit(s,meta,breed,t)
    if meta.replacement then return end
    if s.credit_units>=MAX_CREDIT_UNITS then s.discarded=s.discarded+1;return end
    local last=s.credits[#s.credits]
    if last and not last.inflight and last.expires>=t and #last.breeds<64 and last.kind==meta.kind and
        last.side_id==meta.side_id and last.health==meta.health then
        last.breeds[#last.breeds+1]=breed
    elseif #s.credits<MAX_CREDITS then
        if #s.credits==0 then s.next_spawn=math.max(s.next_spawn,t+SPAWN_INTERVAL) end
        s.credits[#s.credits+1]={breeds={breed},side_id=meta.side_id,kind=meta.kind,health=meta.health,expires=t+CREDIT_LIFETIME}
    else s.discarded=s.discarded+1;return end
    s.credit_units=s.credit_units+1;s.credited=s.credited+1
end
local function recycle(s,t)
    if s.ready_size==0 or t<s.next_remove then return end
    local unit=s.ready[s.ready_index]
    s.ready[s.ready_index]=nil;s.ready_index=s.ready_index%16+1;s.ready_size=s.ready_size-1
    s.next_remove=t+1;s.observed=s.observed+1
    local ext=extension(unit,"perception_system");local meta=ext and ext._hcm_straggler
    if not meta then return end
    meta.enqueued=nil
    if not meta.since or t-math.max(meta.since,meta.last_damage or 0)<QUIET_TIME then return end
    local players,reason,distance,index=sample(ext,unit,meta)
    if not players or not ext.immediate_line_of_sight_check then
        meta.since=nil;note_reason(meta,reason,t);debug_evidence(s,unit,ext,meta,reason,t,distance,index,true);return
    end
    for _,player in ipairs(players) do
        if HEALTH_ALIVE[player] then
            s.los=s.los+1
            if ext:immediate_line_of_sight_check(player) then
                meta.since=nil;note_reason(meta,"fresh_visibility",t)
                debug_evidence(s,unit,ext,meta,"fresh_visibility",t,distance,index,true);return
            end
        end
    end
    local manager=Managers.state.minion_spawn
    local source=BLACKBOARDS[unit].spawn.spawn_source or meta.source or "native"
    mod.retiring_units[unit]=true;manager:despawn_minion(unit)
    if manager._spawned_minions_index_lookup[unit] then mod.retiring_units[unit]=nil;return end
    s.removed=s.removed+1
    if meta.batch then meta.batch.recycled=(meta.batch.recycled or 0)+1 end
    if s.removed<=16 then mod:info("Rear unit recycled: %s; source %s; group %s; id %d; out of contact %.1fs; nearest %.1fm; position %s.",
        ext._breed.name,source,tostring(meta.group and meta.group.id or "none"),meta.id,t-meta.since,distance,tostring(POSITION_LOOKUP[unit])) end
    ext._hcm_straggler=nil
    if meta.record then meta.record._hcm_retired=true;meta.record.active=true;meta.owner._roamer_lookup[unit]=nil end
    add_credit(s,meta,ext._breed.name,t)
end
local function replenish(s,pacing,t)
    if t<s.next_spawn or #s.credits==0 then return end
    s.next_spawn=t+SPAWN_INTERVAL
    while s.credits[1] and s.credits[1].expires<t do
        local expired=table.remove(s.credits,1)
        local count=(expired.breeds and #expired.breeds or 1)-(expired.index or 1)+1
        s.discarded=s.discarded+count;s.credit_units=s.credit_units-count
        if expired.group_id then Managers.state.extension:system("group_system"):unlock_group_id(expired.group_id) end
    end
    local credit=s.credits[1]
    if not credit or credit.inflight or not pacing:spawn_type_enabled(credit.kind or "roamers") then return end
    local count=(credit.breeds and #credit.breeds or 1)-(credit.index or 1)+1
    local manager=Managers.state.minion_spawn
    -- Native admission checks use '>'; leave headroom for other spawners.
    local capacity=math.floor(145*mod.template_runtime.config().coarse.combat_tolerance+0.5)
    if manager._spawn_queue_size>=16 or manager:total_allocated_num_enemies()+1>capacity-4 then return end
    local context=Placement.context(credit.side_id,pacing._target_side_id,t)
    if not context then return end
    if not credit.positions then
        s.positions=s.positions+1
        local anchor,reason=Placement.anchor(context,credit)
        if not anchor then if reason=="pending" then s.next_spawn=t+0.25 end;return end
        local positions={}
        local num=GwNavQueries.flood_fill_from_position(pacing._nav_world,anchor,2,2,count,positions)
        if not num or num<1 then return end
        credit.positions={};credit.position_index=1
        for i=1,num do credit.positions[i]=Vector3Box(positions[i]) end
    end
    local position=credit.positions[credit.position_index]:unbox()
    local valid,_,_,reason=Placement.valid(context,position)
    if not valid then
        credit.position_index=credit.position_index+1
        if reason~="footprint" or credit.position_index>#credit.positions then credit.positions=nil end
        s.next_spawn=t+0.25;return
    end
    if #credit.breeds>1 and not credit.group_id then
        local system=Managers.state.extension:system("group_system")
        credit.group_id=system:generate_group_id()
        system:lock_group_id(credit.group_id)
        system:group_from_id(credit.group_id)._hcm_recycling={kind=credit.kind,replacement=true}
    end
    local params=manager:queue_minion_to_spawn(credit.breeds and credit.breeds[credit.index or 1] or credit.breed,
        position,Quaternion.identity(),credit.side_id)
    params.spawn_source="hcm_redeployed";params.optional_aggro_state="aggroed"
    params.optional_target_unit=context.target;params.optional_group_id=credit.group_id;params.optional_health_modifier=credit.health
    params._hcm_redeployment={owner=s,credit=credit,target_side_id=pacing._target_side_id}
    credit.inflight=true;s.queued=s.queued+1
end
-- A queued native request may wait several frames. Validate again at actual
-- consumption, and return a refused unit to its credit instead of losing it.
mod.prepare_redeployment=function(ticket,entry)
    if ticket.owner~=state or not mod.has_local_gameplay_authority() then return false end
    local pacing=Managers.state.pacing
    local t=Managers.time:time("gameplay")
    local credit=ticket.credit
    if credit.expires<t or not pacing:spawn_type_enabled(credit.kind or "roamers") then return false end
    local context=Placement.context(credit.side_id,ticket.target_side_id,t)
    if not context or not Placement.valid(context,entry.position:unbox()) then return false end
    entry.optional_target_unit=context.target
    return true
end
mod.finish_redeployment=function(ticket,unit)
    local s,credit=ticket.owner,ticket.credit
    credit.inflight=nil
    if s~=state then return end
    local t=Managers.time:time("gameplay")
    if not unit then s.cancelled=s.cancelled+1;credit.positions=nil;s.next_spawn=t+SPAWN_INTERVAL;return end
    credit.index=(credit.index or 1)+1;credit.position_index=credit.position_index+1;s.credit_units=s.credit_units-1
    if credit.position_index>#credit.positions then credit.positions=nil end
    if credit.index>(credit.breeds and #credit.breeds or 1) then
        table.remove(s.credits,1)
        if credit.group_id then Managers.state.extension:system("group_system"):unlock_group_id(credit.group_id) end
        s.next_spawn=t+SPAWN_INTERVAL
    else s.next_spawn=t+0.15 end
end

mod.update_straggler_recycling=function(pacing,t)
    if not state or not mod.has_local_gameplay_authority() then return end
    recycle(state,t);replenish(state,pacing,t)
end
mod.finish_straggler_recycling=function()
    if state then
        local s=state
        local system=Managers.state.extension and Managers.state.extension:system("group_system")
        for _,credit in ipairs(s.credits) do if system and credit.group_id then system:unlock_group_id(credit.group_id) end end
        local reasons={}
        for reason,count in pairs(s.reasons) do reasons[#reasons+1]=reason.."="..tostring(count) end
        table.sort(reasons)
        mod:info("Recovery debug receipt: rule engaged or known pacing patrol, 35m from all teammates, 30s out of contact; route/motion/event-wait checks 0; samples every 5s; removal attempts at most 1/s; diagnostic samples %d/48.",s.debug_lines)
        mod:info("Rear eligibility receipt: tracked %d; final attempts %d; quiet periods started %d; orphan rejoined %d; reason transitions [%s].",
            s.tracked,s.observed,s.qualified,s.rejoined,table.concat(reasons,", "))
        mod:info("Rear recycling receipt: removed %d; credits %d; queued %d; created %d; pending %d; discarded %d; cancelled requests %d; retirement LOS queries %d; spawn-position queries %d.",
            s.removed,s.credited,s.queued,s.created,s.credit_units,s.discarded,s.cancelled,s.los,s.positions)
    end
    state=nil;patrol_context=nil
end
return true
