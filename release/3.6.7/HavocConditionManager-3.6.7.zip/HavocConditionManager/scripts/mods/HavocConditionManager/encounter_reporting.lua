-- Bounded functional receipts: count successful creation, report real blocked
-- selections at most once per 30 seconds, and write one mission-end summary.
local mod=get_mod("HavocConditionManager")
local E=mod.template_runtime
local state,registered
local function current()
    if not state then state={spawned={common=0,elite=0,special=0,monster=0,other=0},blocked={0,0,0},lines=0,next_at=0} end
    return state
end
local function category(breed)
    local tags=breed and breed.tags or {}
    if tags.captain then return "other" end
    if tags.monster then return "monster" end
    if tags.special then return "special" end
    if tags.elite then return "elite" end
    return breed and "common" or "other"
end
mod.report_coordinated_block=function(name,index,load,maximum)
    local s=current();s.blocked[index]=s.blocked[index]+1
    local t=Managers.time and Managers.time:time("gameplay")
    if not t or t<s.next_at or s.lines>=120 then return end
    s.next_at=t+30;s.lines=s.lines+1
    local counts,loads={common=0,elite=0,special=0,monster=0,other=0},{common=0,elite=0,special=0,monster=0,other=0}
    local pacing=Managers.state.pacing
    for unit in pairs(pacing._aggroed_minions or {}) do
        local data=ScriptUnit.has_extension(unit,"unit_data_system")
        local key=category(data and data:breed())
        counts[key]=counts[key]+1;loads[key]=loads[key]+((pacing._saved_challenge_ratings or {})[unit] or 0)
    end
    mod:info("Coordinated blocked: %s; condition %d; load %.2f / < %.2f; engaged count/load common %d/%.2f, elite %d/%.2f, special %d/%.2f, monster %d/%.2f, other %d/%.2f.",
        name,index,load,maximum,counts.common,loads.common,counts.elite,loads.elite,counts.special,loads.special,counts.monster,loads.monster,counts.other,loads.other)
end
local listener={}
function listener:on_minion_spawned(unit)
    if unit and mod.has_local_gameplay_authority() then
        if mod.track_redeployed_unit then mod.track_redeployed_unit(unit) end
        local counts=current().spawned
        local data=ScriptUnit and ScriptUnit.has_extension and ScriptUnit.has_extension(unit,"unit_data_system")
        local key=category(data and data:breed());counts[key]=counts[key]+1
    end
end
mod.start_encounter_report=function()
    local events=Managers.event
    if not mod.has_local_gameplay_authority() or not events or not events.register or events==registered then return end
    if registered then mod.finish_encounter_report() end
    events:register(listener,"minion_unit_spawned","on_minion_spawned")
    registered=events;current()
end
mod.finish_encounter_report=function()
    if registered then registered:unregister(listener,"minion_unit_spawned");registered=nil end
    if state then
        local c,b=state.spawned,state.blocked
        mod:info("Mission spawn receipt: common %d; elite %d; special %d; monster %d; other %d. Coordinated blocked checks: stage %d; players %d; load %d.",c.common,c.elite,c.special,c.monster,c.other,b[1],b[2],b[3])
    end
    state=nil
end
return true
