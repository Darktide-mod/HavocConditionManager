-- Carry origin through both native asynchronous queues. Receipts describe
-- actual entities, not requested composition or a transient caller stack.
local mod=get_mod("HavocConditionManager")
local Minion=require("scripts/managers/minion/minion_spawn_manager")
local Spawner=require("scripts/extension_systems/minion_spawner/minion_spawner_extension")
local Breeds=require("scripts/settings/breed/breeds")
local serial,lines,batches=0,0,{}
function mod.new_spawn_batch(source,side,target_side,event)
    serial=serial+1
    local batch={id=serial,source=source,side_id=side,target_side_id=target_side,event=event,created=0,elite=0,queued=0}
    -- Retain at most 96 reporting records; spawn tickets themselves own the
    -- lifetime needed for a deferred request, independent of this receipt.
    if #batches>=96 then table.remove(batches,1) end
    batches[#batches+1]=batch
    return batch
end
function mod.tag_spawn_request(entry)
    local batch=mod.current_spawn_batch
    if batch then entry._hcm_batch=batch;batch.queued=batch.queued+1 end
    return entry
end
mod:hook(Minion,"spawn_minion",function(fn,self,breed,position,rotation,side,params,...)
    if not mod.has_local_gameplay_authority() then return fn(self,breed,position,rotation,side,params,...) end
    local previous=mod.current_spawn_batch
    local batch=params and params._hcm_batch or previous
    mod.current_spawn_batch=batch
    local ok,unit=pcall(fn,self,breed,position,rotation,side,params,...)
    mod.current_spawn_batch=previous
    if not ok then error(unit,0) end
    if unit and batch then
        batch.created=batch.created+1
        if Breeds[breed] and Breeds[breed].tags.elite then batch.elite=batch.elite+1 end
        if not batch.first_position then batch.first_position=Vector3Box(position) end
        batch.last_position=Vector3Box(position)
        if batch.created==1 and lines<96 then
            lines=lines+1
            mod:info("Spawn batch %d: source %s; event %s; door %s; door group %s; first %s; target %s.",
                batch.id,batch.source,tostring(batch.event or "none"),tostring(batch.door or "none"),tostring(batch.door_group or "none"),
                tostring(position),tostring(batch.target_position and batch.target_position:unbox() or "unknown"))
        end
    end
    return unit
end)
mod:hook(Spawner,"add_spawns",function(fn,self,breeds,side,params,...)
    if mod.has_local_gameplay_authority() and mod.current_spawn_batch and params then
        params._hcm_batch=mod.current_spawn_batch
    end
    return fn(self,breeds,side,params,...)
end)
mod:hook(Spawner,"_spawn",function(fn,self,breed,data,...)
    local previous=mod.current_spawn_batch
    local batch=mod.has_local_gameplay_authority() and data and data._hcm_batch
    if batch then
        mod.current_spawn_batch=batch
        batch.door=tostring(self._unit)
        batch.door_group=batch.event
    end
    local ok,result=pcall(fn,self,breed,data,...)
    mod.current_spawn_batch=previous
    if not ok then error(result,0) end
    return result
end)
function mod.finish_spawn_flow()
    for _,batch in ipairs(batches) do
        if batch.created>0 then mod:info("Spawn batch receipt %d: source %s; actual %d; elite %d; nearby %d; recycled %d.",
            batch.id,batch.source,batch.created,batch.elite,batch.nearby or 0,batch.recycled or 0) end
    end
    batches={};serial=0;lines=0;mod.current_spawn_batch=nil
end
return true
