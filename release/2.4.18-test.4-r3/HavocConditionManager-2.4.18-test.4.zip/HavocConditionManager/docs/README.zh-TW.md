# 浩劫詞條管理器

浩劫詞條管理器以 SoloPlay 為前提，同時支援 Realms 聯機會話。透過 SoloPlay 選單配置單人或 Realms 聯機任務的詞條、環境和刷怪倍率。浩劫、金級／大漩渦、活動及陣營規則分開顯示，環境也可以單獨選擇。

HCM 單獨執行使用原版 Buff 觸發事件分配器及其容量（目前為 300）。啟用 HED 後，由 HED 的獨立控制項決定固定上限，適用於原版及高階兩種生成模式。請求超限即拒絕，執行中的溢位不會增加容量。請同時更新兩個配套模組並完全重新啟動遊戲。

## 可以調整什麼

- 組合受支援的詞條，不再受原有固定槽位數量限制。可用條目取決於本機遊戲指令碼。
- 按浩劫、金級／大漩渦、活動和陣營分類查詢詞條。
- 每局選擇一種相容環境；地圖不支援時回退到可用選項。
- 分別調整普通敵人、精英、特感和 Boss 的 1–5 倍刷新，選擇數量、速度或混合模式。
- 可以獨立使用；安裝高階生成器後，可進一步編輯生成器、池子和容量。

基礎模式組合原版詞條效果並調整刷新引數，保留原版生成器、池子與容量規則。詞條自身仍會施加原有的陣營和池子變化。因此，5 倍刷新不等於場上同時存活的敵人一定達到 5 倍。

## 依賴與安裝

先安裝 Darktide Mod Loader、Darktide Mod Framework 和 SoloPlay。本版配套使用的 Solo Play 版本為 2.6.1。使用 Realms 聯機時還需安裝 Realms，SoloPlay 仍為前提。Havoc Enemy Director 是可選擴充套件。

## Vortex 安裝

- 退出遊戲，在 Vortex 中管理 Darktide，並先安裝上方列出的依賴。
- 從本模組 Files 頁面下載安裝 ZIP，在 Vortex 中選擇 Install From File（從檔案安裝）匯入，然後啟用模組並點選 Deploy Mods（部署模組）。
- 開啟 Load Order（載入順序），啟用 HavocConditionManager 並將其排在 SoloPlay 後；如安裝 HavocEnemyDirector，則將其排在 HavocConditionManager 後。
- 啟動遊戲，從 Mod 選項開啟浩劫詞條管理器。

## 手動安裝

- 退出遊戲，並按各依賴的說明完成前置安裝。
- 開啟 Darktide 遊戲目錄；Steam 中可透過“屬性 → 已安裝檔案 → 瀏覽”進入。
- 進入遊戲的 mods 資料夾，將本 ZIP 內的 HavocConditionManager 資料夾解壓到此處，確認最終路徑為 mods/HavocConditionManager。
- 編輯 mods/mod_load_order.txt，在 SoloPlay 後另起一行加入 HavocConditionManager，保留其他條目。如使用 HavocEnemyDirector，應將其放在 HavocConditionManager 後。
- 儲存檔案並啟動遊戲，從 Mod 選項開啟浩劫詞條管理器。

使用本模組時，應停用同樣接管 Solo Play 詞條選擇的舊擴充套件。

## 框架開關

可在 Darktide Mod Framework 中啟用或禁用本模組。大廳內立即生效；本地或 Realms 任務中切換時，會儲存開關並在下一局應用，當前任務繼續使用已初始化的詞條和刷怪配置，並顯示提示。已有設定會保留。

關閉詞條管理器後，後續任務使用 SoloPlay 原選單與任務設定，高階生成器隨之停用。

## 使用方法

在 Mod 選項中找到浩劫詞條管理器並點選“開啟”，透過側邊箭頭切換頁面。在開啟下一局 SoloPlay 或 Realms 任務前設定詞條、環境和倍率；Realms 聯機時由房主配置任務。安裝高階生成器後，同一選單會增加“高階”頁。

支援英文、簡體中文、繁體中文，跟隨遊戲語言；更改遊戲語言後請重啟。原版詞條與環境名稱使用遊戲提供的翻譯。

## 相容性與限制

任務配置以 SoloPlay 為基礎，同時支援玩家主機的 Realms 會話；聯機時以房主的任務配置為準。不承諾修改官方匹配任務或進度；SoloPlay 任務不提供正常進度與獎勵。多個模組同時接管詞條或刷怪邏輯時可能互相覆蓋。

部分詞條效果由遊戲內部系統處理，可能只施加 Buff，並不產生新的刷怪來源。環境為單選，不提供多種環境疊加。

已透過程式碼與模擬介面檢查，包括不載入高階生成器的獨立執行檢查。本版尚未新增實機測試。佈局檢查覆蓋常見 16:9、16:10 和超寬比例，仍不能代替每種顯示器與介面縮放的實測。

## 致謝

Solo Play 與介面基礎：deluxghost。原版系統、名稱與引用素材：Fatshark。遊戲原始碼查閱：Aussiemon/Darktide-Source-Code。本模組為獨立社群專案。


