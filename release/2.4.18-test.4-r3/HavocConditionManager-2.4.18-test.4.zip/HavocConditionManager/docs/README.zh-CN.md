# 浩劫词条管理器

浩劫词条管理器以 SoloPlay 为前提，同时支持 Realms 联机会话。通过 SoloPlay 菜单配置单人或 Realms 联机任务的词条、环境和刷怪倍率。浩劫、金级／大漩涡、活动及阵营规则分开显示，环境也可以单独选择。

HCM 单独运行使用原版 Buff 触发事件分配器及其容量（当前为 300）。启用 HED 后，由 HED 的独立控件决定固定上限，适用于原版和高级两种生成模式。请求超限即拒绝，运行中的溢出不会增加容量。请同时更新两个配套模组并完全重启游戏。

## 可以调整什么

- 组合受支持的词条，不再受原有固定槽位数量限制。可用条目取决于本机游戏脚本。
- 按浩劫、金级／大漩涡、活动和阵营分类查找词条。
- 每局选择一种兼容环境；地图不支持时回退到可用选项。
- 分别调整普通敌人、精英、特感和 Boss 的 1–5 倍刷新，选择数量、速度或混合模式。
- 可以独立使用；安装高级生成器后，可进一步编辑生成器、池子和容量。

基础模式组合原版词条效果并调整刷新参数，保留原版生成器、池子与容量规则。词条自身仍会施加原有的阵营和池子变化。因此，5 倍刷新不等于场上同时存活的敌人一定达到 5 倍。

## 依赖与安装

先安装 Darktide Mod Loader、Darktide Mod Framework 和 SoloPlay。本版配套使用的 Solo Play 版本为 2.6.1。使用 Realms 联机时还需安装 Realms，SoloPlay 仍为前提。Havoc Enemy Director 是可选扩展。

## Vortex 安装

- 退出游戏，在 Vortex 中管理 Darktide，并先安装上方列出的依赖。
- 从本模组 Files 页面下载安装 ZIP，在 Vortex 中选择 Install From File（从文件安装）导入，然后启用模组并点击 Deploy Mods（部署模组）。
- 打开 Load Order（加载顺序），启用 HavocConditionManager 并将其排在 SoloPlay 后；如安装 HavocEnemyDirector，则将其排在 HavocConditionManager 后。
- 启动游戏，从 Mod 选项打开浩劫词条管理器。

## 手动安装

- 退出游戏，并按各依赖的说明完成前置安装。
- 打开 Darktide 游戏目录；Steam 中可通过“属性 → 已安装文件 → 浏览”进入。
- 进入游戏的 mods 文件夹，将本 ZIP 内的 HavocConditionManager 文件夹解压到此处，确认最终路径为 mods/HavocConditionManager。
- 编辑 mods/mod_load_order.txt，在 SoloPlay 后另起一行加入 HavocConditionManager，保留其他条目。如使用 HavocEnemyDirector，应将其放在 HavocConditionManager 后。
- 保存文件并启动游戏，从 Mod 选项打开浩劫词条管理器。

使用本模组时，应停用同样接管 Solo Play 词条选择的旧扩展。

## 框架开关

可在 Darktide Mod Framework 中启用或禁用本模组。大厅内立即生效；本地或 Realms 任务中切换时，会保存开关并在下一局应用，当前任务继续使用已初始化的词条和刷怪配置，并显示提示。已有设置会保留。

关闭词条管理器后，后续任务使用 SoloPlay 原菜单与任务设置，高级生成器随之停用。

## 使用方法

在 Mod 选项中找到浩劫词条管理器并点击“打开”，通过侧边箭头切换页面。在开启下一局 SoloPlay 或 Realms 任务前设置词条、环境和倍率；Realms 联机时由房主配置任务。安装高级生成器后，同一菜单会增加“高级”页。

支持英文、简体中文、繁体中文，跟随游戏语言；更改游戏语言后请重启。原版词条与环境名称使用游戏提供的翻译。

## 兼容性与限制

任务配置以 SoloPlay 为基础，同时支持玩家主机的 Realms 会话；联机时以房主的任务配置为准。不承诺修改官方匹配任务或进度；SoloPlay 任务不提供正常进度与奖励。多个模组同时接管词条或刷怪逻辑时可能互相覆盖。

部分词条效果由游戏内部系统处理，可能只施加 Buff，并不产生新的刷怪来源。环境为单选，不提供多种环境叠加。

已通过代码与模拟界面检查，包括不加载高级生成器的独立运行检查。本版尚未新增实机测试。布局检查覆盖常见 16:9、16:10 和超宽比例，仍不能代替每种显示器与界面缩放的实测。

## 致谢

Solo Play 与界面基础：deluxghost。原版系统、名称与引用素材：Fatshark。游戏源码查阅：Aussiemon/Darktide-Source-Code。本模组为独立社区项目。


