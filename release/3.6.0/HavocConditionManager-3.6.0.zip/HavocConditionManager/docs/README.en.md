# Havoc Condition Manager

Choose SoloPlay mission conditions and adjust enemy pacing. HCM provides broad controls; the optional Havoc Enemy Director edits individual fields in the same game templates. Realms sessions use the local host's settings.

## Conditions and mission setup

- Import the current SoloPlay condition list and group eligible entries as Havoc, Auric/Maelstrom, events and general conditions.
- Add or remove conditions without a fixed slot count. A shared native mutator loads once even when several selected conditions include it.
- Choose mission, faction, difficulty and environment in the mission page. An unsupported map/environment pair falls back to Default.
- Apply the selected native pickup, health-station and hazard settings. Native replacement rules still govern conflicting effects.

Available entries depend on the installed game and SoloPlay. HCM supplies no separate Havoc or Maelstrom condition definitions.

## Overall tuning

Open HCM in Mod Options and select Overall tuning. The main page shows the intensity slider and linked values. The 20 individual controls are in Advanced settings; hover titles for details.

Level 1 preserves the native spawn configuration for the selected mission, difficulty and conditions when HED overrides are also at baseline. Levels 2–10 increase ordinary enemies gradually and increase elite, specialist and monster pressure more strongly. Intermediate levels interpolate between the following anchors; integer allowances may remain equal across adjacent levels. A level describes a preset, not a measured difficulty or kill-count multiplier.

- Route population: 1× / 1.2× / 1.5× at levels 1 / 5 / 10. Camp count and event budget: 1× / 1.1× / 1.25×.
- Ordinary enemies per horde or trickle wave: 1× / 1.1× / 1.25×. Horde frequency: 1× / 1.08× / 1.2×; trickle frequency: 1× / 1.05× / 1.1×. Ordinary horde wave counts stay native.
- Existing elite members in horde compositions and patrol teams: 1× / 1.75× / 3×. Ordinary members keep their separate counts. A patrol with 8 elites and 8 ordinary troops requests 24 elites and 8 ordinary troops at 3× elite members. Roamer packs and point-budget events keep native selection ratios and grow through population and budget.
- Specialist capacity: 1× / 2× / 3×; refill frequency: 1× / 2× / 3.25×; surge allowance: 1× / 3× / 6×. Capacity and frequency together represent nominal scheduling capacity, subject to native pauses, player-dependent limits and spawn checks.
- Map monster encounter allowance: 1× / 4× / 8×. Elite patrol encounter allowance: 1× / 3× / 6×. These counts are separate from patrol team size.
- Coordinated tactic allowance: 1× / 2× / 3×. Supported tactics' upper combat-load limit rises from 35 to 70 to 105. The medium-load lower bound stays at 8; capable-player, pacing-stage and other native conditions still apply. HED can append requirements to the adjusted conditions or explicitly replace them.
- General combat capacity: 1× / 1.5× / 2×; recovery duration: 1× / 0.85× / 0.7×. At level 10, the living-plus-queued admission threshold is 290 and the difficulty-5 horde threshold is 190. Condition encounter counts, escalation, mission objectives and separate scripted-event limits retain their settings.

Patrols and monsters first use unused authored encounter points. Overflow waits for valid hidden navigation positions. Both queues share a minimum 20-second interval and receive turns weighted by their starting overflow quotas. A ready queue gets a turn after at most three successful admissions of the other queue. If one class is blocked or fails to spawn, the other may try; only successful spawns consume allowance. Supplemental bosses wait while three ordinary map monsters are alive, and at most two supplemental patrol groups remain active. Native pauses, positions and mission length can still leave allowance unused.

Selecting a level replaces all 20 HCM values; individual edits show Custom. Exact saved presets from the previous curve migrate to the same level on the new curve. Other custom values and HED overrides remain. Changes save automatically and apply next mission.

Due spawners run across successive updates while retaining queues, order and completion callbacks. Ordinary and coordinated hordes defer their next wave while the central queue is congested. Temporary pacing refusals preserve unspawned map encounters. Repeated Buff-capacity warnings are summarized; the Buff event pool remains 300.

HCM-hosted missions at every intensity level record a final count of successfully created common enemies, elites, specialists, monsters and other units. This is a spawn receipt, not a kill counter. Blocked coordinated selections can record actual engaged counts and load by category at most once per 30 seconds, capped at 120 snapshots per mission. Encounter overflow reports successful admissions and final unused allowance with blocking reasons. These bounded records use the game log.

## Automatic rear-enemy recycling

Recycling is active at every intensity level while HCM runs on the local mission host, with no separate switch. Level 1 keeps the native spawn multipliers and includes this behavior.

Eligible ordinary enemies and elites must remain without a combat target, at least 80 metres from every living teammate including bots, and at least 60 metres behind the entire team along the main path for at least 30 seconds. Unknown route information keeps the enemy in place. Crossing a step or checkpoint alone never triggers removal. Ordinary enemies following a path keep their pursuit.

Known native patrols can qualify while walking if the whole group remains disengaged and its route gap is not closing. All current members must qualify; groups larger than 64 and locked or externally controlled groups are excluded. Recycling proceeds one member at a time, stopping if any remaining member engages, becomes protected or visible, or the team returns. Damaged or marked enemies, combat effects, specialists, bosses, captains, companions and mission-owned units are protected. A final native line-of-sight check protects the unit being removed when cached visibility is unknown.

Only actually removed originals provide replacement allowance. Singles retain their breed; patrol transfers retain the removed members' breeds, counts and group membership. They return as a native combat group when pacing, capacity and hidden forward positions permit. An interrupted patrol transfers only the members already removed. Each original can transfer once; a replacement that later qualifies for cleanup creates no further allowance. Allowance is limited to 24 records and 96 units, expires after 180 seconds, and may remain unused when the mission ends. Each admission is at least 8 seconds apart; a whole patrol waits for sufficient capacity and distinct positions before entering the native queue.

Checks reuse native perception updates, group membership, route progress, visibility and spawn-point data. There is no additional whole-map enemy scan or patrol path search. Detailed candidate checks are limited to four per second, final removal to one unit per second, with one patrol processed at a time and at least 20 seconds between patrol starts. Native queue updates spread actual creation across frames. Mission-end receipts distinguish removed units, credited allowance, queued requests, actual creation, unused allowance and visibility/position queries.

## Fine editing and saved settings

Havoc Enemy Director adds Detailed tuning. HCM first supplies broad changes; a HED field override then sets that field's exact value. Native difficulty and condition modifiers can still change the final result. Mission combat-node budgets are a specific case: HCM's event-budget multiplier scales the final budget and its native cap after the node's base values and native modifiers.

Values save automatically and apply when the next mission starts. A running mission retains its starting configuration. DMF switches apply immediately in the hub and are deferred during a mission. Disabling HCM restores SoloPlay's menu and suspends HED for later missions.

The first use imports valid native IDs from the previous HCM selection. Retired condition aliases are omitted; the original saved value is retained. Old category multipliers and custom-generator settings are not converted into native template edits. Start from the new defaults and configure the controls before your next mission.

English, Simplified Chinese and Traditional Chinese follow the game language. Native identifiers remain visible where needed to distinguish exact templates.

## Requirements

Darktide Mod Loader, Darktide Mod Framework and SoloPlay are required. Realms is optional for co-op. Havoc Enemy Director is optional. Other mods replacing the same native templates or scheduling methods may conflict.

## Vortex installation

- Close the game and install the requirements. Import this ZIP with Install From File, enable it and select Deploy Mods.
- Enable HavocConditionManager in Load Order after SoloPlay. Place the optional HavocEnemyDirector after HavocConditionManager.
- Restart the game and open Havoc Condition Manager in Mod Options.

## Manual installation

- Close the game. When upgrading, remove the previous HavocConditionManager installation folder before extracting the new ZIP; saved settings are stored separately.
- Extract the ZIP into Darktide/mods, producing mods/HavocConditionManager.
- Add HavocConditionManager on its own line after SoloPlay in mods/mod_load_order.txt. Place the optional HavocEnemyDirector after it.
- Restart the game and open HCM in Mod Options.

## Credits

SoloPlay and the original UI foundation: deluxghost. Native game systems and assets: Fatshark. Game-source reference: Aussiemon/Darktide-Source-Code.
