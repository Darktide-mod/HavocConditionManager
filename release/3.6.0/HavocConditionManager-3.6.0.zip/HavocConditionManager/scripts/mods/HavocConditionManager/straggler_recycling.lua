-- Reuse the native perception scheduler, route data, LOS and despawn queue.
-- Only known native pacing roamers/patrols and one-transfer replacements qualify.
local mod=get_mod("HavocConditionManager")
local Roamer=require("scripts/managers/pacing/roamer_pacing/roamer_pacing")
local Monster=require("scripts/managers/pacing/monster_pacing/monster_pacing")
local Horde=require("scripts/managers/horde/horde_manager")
local Perception=require("scripts/extension_systems/perception/minion_perception_extension")
local SpawnPoints=require("scripts/managers/main_path/utilities/spawn_point_queries")
local CHECK_INTERVAL,QUIET_TIME,BEHIND,DISTANCE_SQ=5,30,60,80*80
local MAX_CREDITS,CREDIT_LIFETIME,SPAWN_INTERVAL=24,180,8
local state,patrol_context
local MAX_GROUP,MAX_CREDIT_UNITS=64,96
local protected_keywords={"bleeding","burning","warpfire_burning","electrocuted","electrocuted_chain_lightning",
    "electrocuted_arc","electrocuted_arc_ability","electrocuted_arc_grenade","electrocuted_shock_mine",
    "taunted","veteran_tag","sticky_projectiles","weapon_malfunction","toxin","stimmed",
    "blessed_by_nurgle_parasite","has_nurgle_parasite","havoc_gardens_embrace","nurgle_flies",
    "rotten_armor","super_armor_override","invulnerable","damage_immune","random_damage_immune"}
local function current()
    if not state then state={credits={},checks=0,next_check=0,next_remove=0,next_spawn=0,
        removed=0,credited=0,queued=0,created=0,discarded=0,los=0,positions=0,credit_units=0,
        next_patrol=0,patrols=0,interrupted=0} end
    return state
end
local function extension(unit,name) return ScriptUnit.has_extension(unit,name) end
local function native_group(unit)
    local ext=extension(unit,"group_system")
    return ext and ext.group and ext:group()
end
local function attach(unit,owner,record,side_id,origin)
    local ext=unit and extension(unit,"perception_system")
    if not ext then return end
    local group=origin and native_group(unit)
    if group then
        group._hcm_recycling=group._hcm_recycling or origin
        origin=group._hcm_recycling
    end
    ext._hcm_straggler={owner=owner,record=record,side_id=side_id,next_check=0,group=group,origin=origin}
end
mod:hook_safe(Roamer,"_try_activate_roamer",function(self,record,side_id)
    if mod.has_local_gameplay_authority() and record.active and record.spawned_unit then
        attach(record.spawned_unit,self,record,side_id,record.patrol_id and {kind="roamers"})
    end
end)
-- Observe only native pacing patrol creation. Mission-controlled and expedition
-- loot patrols retain their original ownership and cannot enter this pool.
mod:hook(Monster,"_spawn_boss_patrol",function(fn,self,...)
    local previous=patrol_context
    patrol_context=mod.has_local_gameplay_authority() and
        (self._pacing_type=="default" or self._hcm_recyclable_patrol) and {kind="monsters"} or nil
    local ok,result=pcall(fn,self,...)
    patrol_context=previous
    if not ok then error(result,0) end
    return result
end)
mod:hook(Horde,"horde",function(fn,self,kind,template,side_id,target_side_id,composition,...)
    local previous=patrol_context
    local params=select(9,...)
    patrol_context=mod.has_local_gameplay_authority() and template=="trickle_horde" and
        not (params and (params.externally_controlled_patrol or params.mutator_name)) and
        {kind="trickle_hordes",health=select(5,...)} or nil
    local ok,a,b,c,d,e=pcall(fn,self,kind,template,side_id,target_side_id,composition,...)
    patrol_context=previous
    if not ok then error(a,0) end
    return a,b,c,d,e
end)
mod.track_redeployed_unit=function(unit)
    local board=BLACKBOARDS and BLACKBOARDS[unit]
    if board and board.spawn and (board.spawn.spawn_source=="hcm_redeployed" or patrol_context) then
        local sides=Managers.state.extension:system("side_system")
        local side=sides.side_by_unit[unit]
        if side then
            local replacement=board.spawn.spawn_source=="hcm_redeployed"
            local group=replacement and native_group(unit)
            attach(unit,nil,nil,side.side_id,replacement and group and group._hcm_recycling or patrol_context)
            if replacement then current().created=current().created+1 end
        end
    end
end
local function reset_candidate(meta) meta.since=nil;meta.gap=nil end
local function basic(ext,unit,meta)
    local board=BLACKBOARDS and BLACKBOARDS[unit]
    local perception=board and board.perception
    local breed=ext._breed
    local tags=breed and breed.tags or {}
    if not HEALTH_ALIVE[unit] or ext._is_perception_disabled or not perception or not breed
        or breed.breed_type~="minion" or tags.special or tags.monster or tags.captain or tags.companion
        or perception.target_unit or perception.lock_target or perception.has_line_of_sight then return end
    local spawn=board.spawn
    if not spawn or spawn.is_exiting_spawner then return end
    if meta.record then
        if spawn.spawn_source~="roamer_pacing" or meta.record.patrol_id and not meta.group or meta.record.stim_buff_name
            or meta.record._hcm_retired or meta.record.spawned_unit~=unit then return end
    elseif spawn.spawn_source~="hcm_redeployed" and not (meta.group and meta.origin and
        (meta.origin.kind=="monsters" and (not spawn.spawn_source or spawn.spawn_source=="") or
        meta.origin.kind=="trickle_hordes" and spawn.spawn_source=="trickle_patrol")) then return end
    local patrol=meta.group and board.patrol and board.patrol.should_patrol
    if meta.group and not meta.origin.replacement and not patrol then return end
    local group=board.group_data
    if group and (group.group_target or group.owning_auto_event_id and group.owning_auto_event_id~="") then return end
    local nav=extension(unit,"navigation_system")
    if not nav or not nav.is_following_path or nav:is_following_path() and not patrol
        or not nav.is_using_smart_object or nav:is_using_smart_object() then return end
    local health=extension(unit,"health_system")
    if not health or not health.current_health_percent or health:current_health_percent()<1
        or health.last_damaging_unit and health:last_damaging_unit()
        or health.is_invulnerable and health:is_invulnerable() then return end
    local objective=extension(unit,"mission_objective_target_system")
    if objective and (not objective.objective_name or objective:objective_name() and objective:objective_name()~="") then return end
    local tag=extension(unit,"smart_tag_system")
    if tag and (not tag.tag_id or tag:tag_id()) then return end
    local buffs=extension(unit,"buff_system")
    if not buffs or not buffs.has_keyword then return end
    for _,keyword in ipairs(protected_keywords) do if buffs:has_keyword(keyword) then return end end
    local spawn_manager=Managers.state.minion_spawn
    if not spawn_manager or not spawn_manager._spawned_minions_index_lookup[unit]
        or spawn_manager._minions_with_owners[unit] then return end
    return breed
end
local function behind_team(ext,unit,meta)
    local main=Managers.state.main_path
    if not main or not main.is_main_path_ready or not main:is_main_path_ready() then return end
    local side=ext._side_system and ext._side_system.side_by_unit[unit]
    local players=side and side.enemy_player_units
    if not players or #players==0 or #players>8 then return end
    local position=POSITION_LOOKUP[unit]
    if not position then return end
    local distance=main:travel_distance_from_position(position,true)
    if not distance then return end
    local count,gap=0,math.huge
    for _,player in ipairs(players) do
        if HEALTH_ALIVE[player] then
            local player_position=POSITION_LOOKUP[player]
            if not player_position or Vector3.distance_squared(position,player_position)<DISTANCE_SQ
                or ext:has_line_of_sight(player) then return end
            local progress=main:travel_distance_from_position(player_position,true)
            if not progress or progress-distance<BEHIND then return end
            gap=math.min(gap,progress-distance)
            count=count+1
        end
    end
    if count==0 then return end
    return players,side,gap
end
mod:hook_safe(Perception,"update",function(self,unit,dt,t)
    local meta=self._hcm_straggler
    if not meta or not mod.has_local_gameplay_authority() then return end
    -- Target acquisition cancels a pending candidate on the native AI tick.
    local perception=self._perception_component
    if not perception or perception.target_unit or perception.has_line_of_sight then reset_candidate(meta);return end
    if t<meta.next_check then return end
    local s=current()
    if t>=s.next_check then s.next_check=t+1;s.checks=0 end
    if s.checks>=4 then return end
    s.checks=s.checks+1
    -- Reuse the native population count to prevent the same early units from
    -- exhausting every check window while later units never get a turn.
    local population=self._perception_system and self._perception_system._num_update_units or 0
    meta.next_check=t+math.max(CHECK_INTERVAL,math.ceil(population/4)+1)
    local players,side,gap
    if basic(self,unit,meta) then players,side,gap=behind_team(self,unit,meta) end
    if not players then reset_candidate(meta);return end
    if meta.group and meta.gap and gap<=meta.gap-5 then reset_candidate(meta) end
    meta.gap=meta.gap and math.max(meta.gap,gap) or gap
    meta.checked=t
    meta.since=meta.since or t
    if t-meta.since>=QUIET_TIME and not s.pending and not s.patrol_job then s.pending={unit=unit,ext=self,meta=meta,at=t} end
end)
local function add_credit(s,credit,t)
    local count=credit.breeds and #credit.breeds or 1
    if #s.credits<MAX_CREDITS and s.credit_units+count<=MAX_CREDIT_UNITS then
        if #s.credits==0 then s.next_spawn=math.max(s.next_spawn,t+SPAWN_INTERVAL) end
        credit.expires=t+CREDIT_LIFETIME
        s.credits[#s.credits+1]=credit;s.credit_units=s.credit_units+count;s.credited=s.credited+count
    else s.discarded=s.discarded+count end
end
local function group_ready(group,t,job)
    local system=Managers.state.extension:system("group_system")
    if not group or #group.members==0 or #group.members>MAX_GROUP or
        system._locked_group_ids and system._locked_group_ids[group.id] then return end
    local live=0
    for _,unit in ipairs(group.members) do
        if not job or not job.removed[unit] then
            if not HEALTH_ALIVE[unit] then return end
            local ext=extension(unit,"perception_system")
            local meta=ext and ext._hcm_straggler
            if not meta or meta.group~=group or not meta.since or t-meta.since<QUIET_TIME or
                not meta.checked or t>meta.next_check+2 or not basic(ext,unit,meta) or
                job and not job.members[unit] then return end
            -- Cheap current vetoes reuse the native cached LOS; route projection
            -- remains on the four-per-second observation budget and final unit.
            local side=ext._side_system.side_by_unit[unit]
            local players=side and side.enemy_player_units
            local position=POSITION_LOOKUP[unit]
            if not position or not players or #players==0 then return end
            for _,player in ipairs(players) do
                if HEALTH_ALIVE[player] and (not POSITION_LOOKUP[player] or
                    Vector3.distance_squared(position,POSITION_LOOKUP[player])<DISTANCE_SQ or
                    ext:has_line_of_sight(player)) then return end
            end
            live=live+1
        end
    end
    return live>0
end
local function finish_patrol(s,t,interrupted)
    local job=s.patrol_job
    if #job.breeds>0 and not job.origin.replacement then
        add_credit(s,{breeds=job.breeds,side_id=job.side_id,kind=job.origin.kind,health=job.origin.health},t)
    end
    s.patrol_job=nil
    if interrupted then
        s.interrupted=s.interrupted+1
        for _,unit in ipairs(job.group.members) do
            if HEALTH_ALIVE[unit] then
                local ext=extension(unit,"perception_system")
                if ext and ext._hcm_straggler then reset_candidate(ext._hcm_straggler) end
            end
        end
    else s.patrols=s.patrols+1 end
end
local function recycle(s,t)
    local pending=s.pending
    if t<s.next_remove or not pending and not s.patrol_job then return end
    s.pending=nil;s.next_remove=t+1
    if not s.patrol_job and pending.meta.group then
        local group=pending.meta.group
        if t<s.next_patrol or not group_ready(group,t) then return end
        local job={group=group,origin=pending.meta.origin,side_id=pending.meta.side_id,
            list={},members={},removed={},breeds={},index=1}
        for _,unit in ipairs(group.members) do job.list[#job.list+1]=unit;job.members[unit]=true end
        s.patrol_job=job;s.next_patrol=t+20
    end
    local job=s.patrol_job
    if job then
        if not group_ready(job.group,t,job) then finish_patrol(s,t,true);return end
        local unit=job.list[job.index]
        local ext=extension(unit,"perception_system")
        pending={unit=unit,ext=ext,meta=ext and ext._hcm_straggler,at=t}
    end
    local unit,ext,meta=pending.unit,pending.ext,pending.meta
    if t-pending.at>2 or not meta or not meta.since or t-meta.since<QUIET_TIME then return end
    local breed=basic(ext,unit,meta)
    local players=breed and behind_team(ext,unit,meta)
    if not players or not ext.immediate_line_of_sight_check then
        reset_candidate(meta);if job then finish_patrol(s,t,true) end;return
    end
    for _,player in ipairs(players) do
        if HEALTH_ALIVE[player] then
            s.los=s.los+1
            if ext:immediate_line_of_sight_check(player) then
                reset_candidate(meta);if job then finish_patrol(s,t,true) end;return
            end
        end
    end
    local manager=Managers.state.minion_spawn
    manager:despawn_minion(unit)
    if manager._spawned_minions_index_lookup[unit] then return end
    s.removed=s.removed+1
    ext._hcm_straggler=nil
    if meta.record then
        -- Keep active until native dead-unit bookkeeping removes the record.
        meta.record._hcm_retired=true;meta.record.active=true
        meta.owner._roamer_lookup[unit]=nil
        if not job then add_credit(s,{breed=breed.name,side_id=meta.side_id},t) end
    end
    if job then
        job.removed[unit]=true;job.breeds[#job.breeds+1]=breed.name;job.index=job.index+1
        if job.index>#job.list then finish_patrol(s,t,false) end
    end
end
local function replenish(s,pacing,t)
    if t<s.next_spawn or #s.credits==0 then return end
    s.next_spawn=t+SPAWN_INTERVAL
    while s.credits[1] and s.credits[1].expires<t do
        local expired=table.remove(s.credits,1)
        local count=expired.breeds and #expired.breeds or 1
        s.discarded=s.discarded+count;s.credit_units=s.credit_units-count
    end
    local credit=s.credits[1]
    if not credit or not pacing:spawn_type_enabled(credit.kind or "roamers") then return end
    local count=credit.breeds and #credit.breeds or 1
    local manager=Managers.state.minion_spawn
    -- Native admission checks use '>'; leave headroom for other spawners.
    local capacity=math.floor(145*mod.template_runtime.config().coarse.combat_tolerance+0.5)
    if manager._spawn_queue_size>=16 or manager:total_allocated_num_enemies()+count>capacity-4 then return end
    local main=Managers.state.main_path
    if not main or not main:is_main_path_ready() then return end
    local target=main:ahead_unit(pacing._target_side_id)
    local position=target and POSITION_LOOKUP[target]
    local side=Managers.state.extension:system("side_system"):get_side(credit.side_id)
    local nav_points=main:nav_spawn_points()
    if not position or not side or not nav_points then return end
    local groups=GwNavSpawnPoints.get_count(nav_points)
    if groups<1 then return end
    s.positions=s.positions+1
    local target_distance=main:travel_distance_from_position(position,true)
    if not target_distance then return end
    local positions={}
    if credit.breeds then
        local candidates,num=SpawnPoints.get_occluded_positions(pacing._nav_world,nav_points,position,
            side.valid_enemy_player_units_positions,4,groups,30,90,nil,true)
        for i=1,math.min(num or 0,128) do
            local candidate=candidates[i]
            local progress=main:travel_distance_from_position(candidate,true)
            local distinct=true
            for _,existing in ipairs(positions) do
                if Vector3.distance_squared(candidate,existing)<1 then distinct=false;break end
            end
            if distinct and progress and progress>=target_distance then positions[#positions+1]=candidate end
            if #positions==count then break end
        end
    else
        local hidden=SpawnPoints.get_random_occluded_position(pacing._nav_world,nav_points,position,side,4,groups,30,90,nil,true)
        local progress=hidden and main:travel_distance_from_position(hidden,true)
        if progress and progress>=target_distance then positions[1]=hidden end
    end
    if #positions<count then return end
    local group_id
    if credit.breeds then
        local system=Managers.state.extension:system("group_system")
        group_id=system:generate_group_id()
        system:group_from_id(group_id)._hcm_recycling={kind=credit.kind,replacement=true}
    end
    for i=1,count do
        local params=manager:queue_minion_to_spawn(credit.breeds and credit.breeds[i] or credit.breed,
            positions[i],Quaternion.identity(),credit.side_id)
        params.spawn_source="hcm_redeployed"
        params.optional_aggro_state="aggroed"
        params.optional_target_unit=target
        params.optional_group_id=group_id
        params.optional_health_modifier=credit.health
    end
    table.remove(s.credits,1);s.queued=s.queued+count;s.credit_units=s.credit_units-count
end
mod.update_straggler_recycling=function(pacing,t)
    if not state or not mod.has_local_gameplay_authority() then return end
    recycle(state,t)
    replenish(state,pacing,t)
end
mod.finish_straggler_recycling=function()
    if state then
        local s=state
        if s.patrol_job and not s.patrol_job.origin.replacement then
            s.discarded=s.discarded+#s.patrol_job.breeds
        end
        mod:info("Rear recycling receipt: removed %d; credits %d; queued %d; created %d; pending %d; discarded %d; LOS queries %d; spawn-position queries %d.",
            s.removed,s.credited,s.queued,s.created,s.credit_units,s.discarded,s.los,s.positions)
        if s.patrols>0 or s.interrupted>0 then
            mod:info("Rear patrol receipt: completed groups %d; interrupted groups %d.",s.patrols,s.interrupted)
        end
    end
    state=nil;patrol_context=nil
end
return true
