-- Finite overflow from the route plan. Retry real, hidden navigation positions
-- in later waves; do not manufacture positions or discard unavailable quotas.
local mod=get_mod("HavocConditionManager")
local Monster=require("scripts/managers/pacing/monster_pacing/monster_pacing")
local SpawnPoints=require("scripts/managers/main_path/utilities/spawn_point_queries")
local M={}
local INTERVAL,RETRY,MAX_MONSTERS,MAX_PATROLS=20,2,3,2
function M.plan(self,monsters,patrols)
    self._hcm_encounter_reserve=nil
    if monsters>0 or patrols>0 then
        self._hcm_encounter_reserve={monsters=monsters,patrols=patrols,initial_monsters=monsters,initial_patrols=patrols,groups={},next_check=0,lines=0,blocked={}}
    end
end
local function blocked(reserve,reason)
    reserve.blocked[reason]=(reserve.blocked[reason] or 0)+1
end
local function receipt(reserve,status)
    local b=reserve.blocked
    mod:info("Encounter reserve %s: served monsters %d, elite patrols %d; remaining monsters %d, elite patrols %d; blocked checks paused %d, target %d, route %d, capacity %d, position %d, spawn %d.",
        status,reserve.initial_monsters-reserve.monsters,reserve.initial_patrols-reserve.patrols,reserve.monsters,reserve.patrols,
        b.paused or 0,b.target or 0,b.route or 0,b.capacity or 0,b.position or 0,b.spawn or 0)
end
local function active_monsters(self)
    local count=0
    local breeds=mod.template_registry.breeds
    for _,record in ipairs(self._alive_monsters or {}) do
        local breed=breeds[record.breed_name]
        local tags=breed and breed.tags or {}
        if HEALTH_ALIVE[record.spawned_unit] and tags.monster and not tags.captain then count=count+1 end
    end
    return count
end
local function active_patrols(reserve,system)
    for i=#reserve.groups,1,-1 do
        local group=system:group_from_id(reserve.groups[i])
        if not group or #group.members==0 then table.remove(reserve.groups,i) end
    end
    return #reserve.groups
end
local function no_loot() end
local function spawn_patrol(self,reserve,position,target_position,side_id,group_system)
    local settings=self._template.boss_patrols
    local record={breed_list=settings.breed_lists,spawn_position=Vector3Box(position),sound_events=settings.sound_events}
    -- The native timed branch accepts an explicit hidden position. An adapter
    -- keeps the real manager in route mode and prevents expedition-only loot.
    local adapter=setmetatable({_pacing_type="timer_based",_currently_spawned_by_timer={boss_patrols=reserve.groups},
        _expedition_setup_monster_loot=no_loot,_hcm_recyclable_patrol=true},{__index=self})
    local before=#reserve.groups
    self._spawn_boss_patrol(adapter,record,target_position,side_id)
    local id=reserve.groups[before+1]
    local group=id and group_system:group_from_id(id)
    if group and #group.members>0 then return true end
    if id then reserve.groups[before+1]=nil end
    return false
end
local function replenish(self,reserve,t,side_id,target_side_id)
    reserve.next_check=t+RETRY
    if not reserve.next_at then reserve.next_at=t+INTERVAL;return end
    if t<reserve.next_at then return end
    if not Managers.state.pacing:spawn_type_enabled("monsters") then return blocked(reserve,"paused") end
    local main=Managers.state.main_path
    local target,distance=main:ahead_unit(target_side_id)
    local target_position=target and POSITION_LOOKUP[target]
    if not target_position or not distance then return blocked(reserve,"target") end
    -- Let an already-due route encounter use this update first.
    for _,record in ipairs(self._monsters or {}) do if record.travel_distance<=distance then return blocked(reserve,"route") end end
    for _,record in ipairs(self._boss_patrols or {}) do if record.travel_distance<=distance then return blocked(reserve,"route") end end
    local group_system=Managers.state.extension:system("group_system")
    local monster_ready=reserve.monsters>0 and active_monsters(self)<MAX_MONSTERS
    local patrol_ready=reserve.patrols>0 and active_patrols(reserve,group_system)<MAX_PATROLS
    if not monster_ready and not patrol_ready then return blocked(reserve,"capacity") end
    -- Weighted finish time: a large boss backlog cannot starve patrols.
    local choose_monster=monster_ready and (not patrol_ready or
        (reserve.initial_monsters-reserve.monsters+1)/reserve.initial_monsters<=
        (reserve.initial_patrols-reserve.patrols+1)/reserve.initial_patrols)
    -- Even a highly unequal custom quota gives a waiting, ready class a turn
    -- after at most three successful admissions of the other class.
    if monster_ready and patrol_ready and (reserve.run or 0)>=3 and reserve.last_monster==choose_monster then
        choose_monster=not choose_monster
    end
    local side=Managers.state.extension:system("side_system"):get_side(side_id)
    local position=SpawnPoints.get_random_occluded_position(self._nav_world,main:nav_spawn_points(),target_position,side,10,1,30,100)
    if not position then return blocked(reserve,"position") end
    local function attempt(monster)
        local success
        if monster then
            local template=self._template
            local breeds=template.breed_names.monsters
            local breed=breeds[math.random(#breeds)]
            local record={travel_distance=distance,breed_name=breed,position=Vector3Box(position),spawn_type="monsters",
                stinger=template.spawn_stingers and template.spawn_stingers[breed],
                despawn_distance_when_passive=template.despawn_distance_when_passive and template.despawn_distance_when_passive[breed]}
            self:_spawn_monster(record,target,side_id)
            success=record.spawned_unit~=nil
            if success then reserve.monsters=reserve.monsters-1 end
        else
            success=spawn_patrol(self,reserve,position,target_position,side_id,group_system)
            if success then reserve.patrols=reserve.patrols-1 end
        end
        return success
    end
    local success=attempt(choose_monster)
    if not success and (choose_monster and patrol_ready or not choose_monster and monster_ready) then
        choose_monster=not choose_monster;success=attempt(choose_monster)
    end
    if success then
        reserve.next_at=t+INTERVAL
        reserve.run=reserve.last_monster==choose_monster and (reserve.run or 0)+1 or 1
        reserve.last_monster=choose_monster
        if reserve.lines<64 then
            reserve.lines=reserve.lines+1
            mod:info("Encounter reserve spawned: %s; remaining monsters %d; elite patrols %d.",choose_monster and "monster" or "elite patrol",reserve.monsters,reserve.patrols)
        end
    else blocked(reserve,"spawn") end
end
mod:hook(Monster,"update",function(fn,self,dt,t,side_id,target_side_id)
    local reserve=self._hcm_encounter_reserve
    if reserve and not self._disabled and mod.has_local_gameplay_authority() and t>=reserve.next_check then
        if reserve.monsters==0 and reserve.patrols==0 then receipt(reserve,"completed");self._hcm_encounter_reserve=nil
        else replenish(self,reserve,t,side_id,target_side_id) end
    end
    return fn(self,dt,t,side_id,target_side_id)
end)
mod:hook_safe(Monster,"destroy",function(self)
    local reserve=self._hcm_encounter_reserve
    if reserve then receipt(reserve,"at mission end") end
    self._hcm_encounter_reserve=nil
end)
return M
