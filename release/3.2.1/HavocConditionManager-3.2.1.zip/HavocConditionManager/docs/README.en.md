# Havoc Condition Manager

Choose SoloPlay mission conditions and adjust enemy pacing. HCM provides broad controls; the optional Havoc Enemy Director edits individual fields in the same game templates. Realms sessions use the local host's settings.

## Conditions and mission setup

- Import the current SoloPlay condition list and group eligible entries as Havoc, Auric/Maelstrom, events and general conditions.
- Add or remove conditions without a fixed slot count. A shared native mutator loads once even when several selected conditions include it.
- Choose mission, faction, difficulty and environment in the mission page. An unsupported map/environment pair falls back to Default.
- Apply the selected native pickup, health-station and hazard settings. Native replacement rules still govern conflicting effects.

Available entries depend on the installed game and SoloPlay. HCM supplies no separate Havoc or Maelstrom condition definitions.

## Overall tuning

Open HCM in Mod Options and select Overall tuning. The main page shows the overall intensity slider and a short summary of linked values. The 18 individual multipliers are folded into Advanced settings by default. Click values to type; hover titles for details.

Intensity offers coordinated levels from 1 to 10. Higher levels add follow-up waves, elite patrols and specialist replenishment. Level 1 uses baseline values. The level is not a measured multiplier for enemy count or final difficulty.

- Level 5: ordinary horde waves 3×, enemies per wave 1.15× and trigger frequency 1.6×; specialist slots and replenishment frequency each 2×; patrol and map monster requests each 3×.
- Level 10: ordinary horde waves 6×, enemies per wave 1.35× and trigger frequency 2.25×; specialist slots 3× and replenishment frequency 3.25×; patrol requests 6× and map monster requests 5×.
- Higher levels also raise tactic and specialist-surge allowances, modestly increase route population, camps, event budgets and trickle frequency, and shorten recovery. Trickle wave size, condition encounter counts and the escalation curve stay at baseline.

Wave spacing, same-breed limits, map sections and concurrent-enemy limits remain in effect. Patrol and monster settings scale planned requests; available map locations may prevent the full count. Coordinated tactics retain their own wave plans.

Selecting a level replaces all 18 HCM values. Advanced settings provides six groups for individual edits up to 10×; configurations outside a profile appear as Custom. HED field overrides remain. Upgrades preserve saved values: select a level again to apply the revised profile. Changes save automatically and apply next mission.

With tuning active, due spawners run across successive updates while retaining their queues, order and completion callbacks. Ordinary and coordinated hordes defer their next wave while the central queue is congested. Temporary pacing refusals preserve unspawned map encounters. Repeated Buff-capacity warnings are summarized by count; capacity and overflow behavior remain unchanged.

## Fine editing and saved settings

Havoc Enemy Director adds Detailed tuning. HCM first supplies broad changes; a HED field override then sets that field's exact value. Native difficulty and condition modifiers can still change the final result. Mission combat-node budgets are a specific case: HCM's event-budget multiplier scales the final budget and its native cap after the node's base values and native modifiers.

Values save automatically and apply when the next mission starts. A running mission retains its starting configuration. DMF switches apply immediately in the hub and are deferred during a mission. Disabling HCM restores SoloPlay's menu and suspends HED for later missions.

The first use imports valid native IDs from the previous HCM selection. Retired condition aliases are omitted; the original saved value is retained. Old category multipliers and custom-generator settings are not converted into native template edits. Start from the new defaults and configure the controls before your next mission.

English, Simplified Chinese and Traditional Chinese follow the game language. Native identifiers remain visible where needed to distinguish exact templates.

## Requirements

Darktide Mod Loader, Darktide Mod Framework and SoloPlay are required. Realms is optional for co-op. Havoc Enemy Director is optional. Other mods replacing the same native templates or scheduling methods may conflict.

## Vortex installation

- Close the game and install the requirements. Import this ZIP with Install From File, enable it and select Deploy Mods.
- Enable HavocConditionManager in Load Order after SoloPlay. Place the optional HavocEnemyDirector after HavocConditionManager.
- Restart the game and open Havoc Condition Manager in Mod Options.

## Manual installation

- Close the game. When upgrading, remove the previous HavocConditionManager installation folder before extracting the new ZIP; saved settings are stored separately.
- Extract the ZIP into Darktide/mods, producing mods/HavocConditionManager.
- Add HavocConditionManager on its own line after SoloPlay in mods/mod_load_order.txt. Place the optional HavocEnemyDirector after it.
- Restart the game and open HCM in Mod Options.

## Credits

SoloPlay and the original UI foundation: deluxghost. Native game systems and assets: Fatshark. Game-source reference: Aussiemon/Darktide-Source-Code.
